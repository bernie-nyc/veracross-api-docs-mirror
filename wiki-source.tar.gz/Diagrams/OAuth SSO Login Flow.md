> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Diagrams / OAuth SSO Login Flow · [source site](https://api-docs.veracross.com/)

---


# OAuth SSO Login Flow


Diagram: OAuth SSO Login Flow

Veracross can act as an Identity Provider (IDP) for SSO integrations.

This diagram shows how the OAuth 2.0 SSO process works internally to log users in to vendor sites. Visit [Creating an SSO Integration](../Guides/Creating%20an%20SSO%20Integration.md) for details.

<!--
focus: false
-->
![OAuth SSO Login Flow](https://assets.veracross.com/_documentation/api/images/vc-oauth-sso-login-flow.png)


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
