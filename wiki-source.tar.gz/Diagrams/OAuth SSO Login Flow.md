> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Diagrams / OAuth SSO Login Flow · [source site](https://api-docs.veracross.com/)

---


# OAuth SSO Login Flow


Diagram: OAuth SSO Login Flow

Veracross can act as an Identity Provider (IDP) for SSO integrations.

This diagram shows how the OAuth 2.0 SSO process works internally to log users in to vendor sites. Visit [Creating an SSO Integration](Creating-an-SSO-Integration) for details.

<!--
focus: false
-->
![OAuth SSO Login Flow](https://assets.veracross.com/_documentation/api/images/vc-oauth-sso-login-flow.png)


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
