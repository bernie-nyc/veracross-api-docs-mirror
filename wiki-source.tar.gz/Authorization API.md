> [Home](Home) · [Concepts](Concepts/General%20Principles) · [Guides](Guides/Making%20a%20Data%20API%20Request) · [Diagrams](Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](Changelog/Data%20API) · [Data API](Data%20API) · [Authorization API](Authorization%20API) · [Files API](Files%20API)
>
> Authorization API · [source site](https://api-docs.veracross.com/)

---


# Overview: Authorization API


This service documents **9** operations/schemas across **3** groups.


### OAuth


- [Create Access Token](Authorization%20API/Create%20Access%20Token) `POST`  
- [Token Introspection](Authorization%20API/Token%20Introspection) `POST`  
- [Revoke Token](Authorization%20API/Revoke%20Token) `POST`  
- [Authorize](Authorization%20API/Authorize) `GET`  
- [User Info](Authorization%20API/User%20Info) `GET`  


### OIDC


- [JSON Web Key Set (JWKS)](Authorization%20API/JSON%20Web%20Key%20Set%20JWKS) `GET`  
- [OpenID Provider Configuration](Authorization%20API/OpenID%20Provider%20Configuration) `GET`  


### Schemas


- [ErrorResponse](Authorization%20API/ErrorResponse)  
- [EmptyObject](Authorization%20API/EmptyObject)  


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
