> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API · [source site](https://api-docs.veracross.com/)

---


# Overview: Authorization API


This service documents **9** operations/schemas across **3** groups.


### OAuth


- [Create Access Token](Create-Access-Token) `POST`  
- [Token Introspection](Token-Introspection) `POST`  
- [Revoke Token](Revoke-Token) `POST`  
- [Authorize](Authorize) `GET`  
- [User Info](User-Info) `GET`  


### OIDC


- [JSON Web Key Set (JWKS)](JSON-Web-Key-Set-JWKS) `GET`  
- [OpenID Provider Configuration](OpenID-Provider-Configuration) `GET`  


### Schemas


- [ErrorResponse](ErrorResponse)  
- [EmptyObject](EmptyObject)  


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
