> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Authorization API / OAuth / Create Access Token · [source site](https://api-docs.veracross.com/)

---


# Create Access Token


## POST `/oauth/token`


Create Access Token


All requests to the Data API must be made with an access token. Review [Access Tokens](../Concepts/Access%20Tokens.md) for additional details.

#### Endpoint applies to:

| Grant Type | Applicable |
|------------|------------|
| Client Credentials | ✅ |
| Authorization Code | ✅ |
| Refresh Token      | ✅ |

#### Related links
- https://tools.ietf.org/html/rfc6749#section-3.2
- https://www.oauth.com/oauth2-servers/accessing-data/obtaining-an-access-token/
- https://www.oauth.com/oauth2-servers/making-authenticated-requests/refreshing-an-access-token/


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `Content-Type` | string | yes | Needs to be `application/x-www-form-urlencoded` |


### Request body


**Content type:** `application/x-www-form-urlencoded`


| Field | Type | Required | Description |
|---|---|---|---|
| `grant_type` | string <small>enum</small>: `"client_credentials"`, `"authorization_code"`, `"refresh_token"` | yes |  |
| `client_id` | string | yes |  |
| `client_secret` | string | yes | required for all grant types. Treat the client_secret as confidential. |
| `scope` | string |  | list of scopes for this access token |
| `code` | string |  | required only for authorization_code as grant_type |
| `redirect_uri` | string |  | required only for authorization_code as grant_type |

Example:

```json
{
  "id": "6f1d3d23c7868",
  "key": "Client Credentials",
  "value": {
    "grant_type": "client_credentials",
    "client_id": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4c",
    "client_secret": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "scope": "example.object:list another.thing:create"
  }
}
```


Example:

```json
{
  "id": "454b16829bbc0",
  "key": "Authorization Code",
  "value": {
    "grant_type": "authorization_code",
    "client_id": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4c",
    "client_secret": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "scope": "sso",
    "code": "c0d3c0d3c0d3c0d3c0d3c0d3c0d3c0d3"
  }
}
```


Example:

```json
{
  "id": "e129778a9b0ec",
  "key": "Refresh Token",
  "value": {
    "grant_type": "refresh_token",
    "client_id": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4c",
    "client_secret": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "refresh_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv"
  }
}
```


### Responses


**200** — Success



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `access_token` | string | yes |  |
| `created_at` | number | yes |  |
| `expires_in` | number | yes |  |
| `scope` | string | yes |  |
| `refresh_token` | string |  |  |
| `token_type` | string | yes |  |
| `id_token` | string |  | JWT string returned only with the Authorization Code grant type when the `openid` scope is requested. The JWT contains the user info (equivalent to the User Info endpoint). The JWT's signature may be verified using the public key provided by the JWKS endpoint. |

Example:

```json
{
  "id": "b075e6b56c23c",
  "key": "Client Credentials",
  "value": {
    "access_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "created_at": 1599229410,
    "expires_in": 3600,
    "scope": "example.object:list another.thing:create",
    "token_type": "Bearer"
  }
}
```


Example:

```json
{
  "id": "7d9a3b99f86bb",
  "key": "Authorization Code with `sso` scope",
  "value": {
    "access_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "created_at": 1599229410,
    "expires_in": 3600,
    "refresh_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "scope": "sso example.object:list another.thing:create",
    "token_type": "Bearer"
  }
}
```


Example:

```json
{
  "id": "18b2d9abd3c97",
  "key": "Authorization Code with `openid` scope",
  "value": {
    "access_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "created_at": 1599229410,
    "expires_in": 3600,
    "refresh_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "scope": "openid example.object:list another.thing:create",
    "id_token": "JwT0k3nJwT0k3nJwT0k3n.JwT0k3nJwT0k3nJwT0k3nJwT0k3nJwT0k3nJwT0k3n.JwT0k3nJwT0k3nJwT0k3n",
    "token_type": "Bearer"
  }
}
```


Example:

```json
{
  "id": "1433bb54f23e2",
  "key": "Refresh Token",
  "value": {
    "access_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "created_at": 1599229410,
    "expires_in": 3600,
    "refresh_token": "v3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv3r4cr0ssv",
    "scope": "example.object:list another.thing:create",
    "token_type": "Bearer"
  }
}
```


**400** — Bad Request



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | An error code |
| `error_description` | string | yes | The description of the error |
| `error_id` | string |  | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

Example:

```json
{
  "id": "0e215d143626c",
  "key": "Error Example",
  "value": {
    "error": "invalid_request",
    "error_description": "Missing required parameter: grant_type.",
    "error_id": "896204e2-89e9-46c9-2fd0-ef74df63d513"
  }
}
```


**401** — Unauthorized



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | An error code |
| `error_description` | string | yes | The description of the error |
| `error_id` | string |  | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

Example:

```json
{
  "id": "2c699c8b8d9aa",
  "key": "Error Example",
  "value": {
    "error": "invalid_client",
    "error_description": "The requested client id is unknown or unauthorized.",
    "error_id": "896204e2-89e9-46c9-2fd0-ef74df63d513"
  },
  "summary": "Invalid Client"
}
```


**415** — Unsupported media type. This happens when the requests lacks the header `application/x-www-form-urlencoded`.



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|

Example:

```json
{
  "id": "3bdc8c6994182",
  "key": "UnsupportedMediaType",
  "value": {}
}
```


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
