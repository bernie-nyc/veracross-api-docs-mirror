> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API / OAuth / Authorize · [source site](https://api-docs.veracross.com/)

---


# Authorize


## GET `/oauth/authorize`


Authorize


This endpoint starts the OAuth SSO flow. The response is an HTML page intended for humans (in contrast to other endpoints, which are intended for servers). Users can log in to a vendor site with their existing Veracross account.

<!--
focus: false
-->
![A Veracross login page](https://assets.veracross.com/_documentation/api/images/vc-login-page.png)

As a vendor, you need to formulate this URL with the proper parameters:
1. The `client_id` string that identifies your site as a Veracross OAuth Application.
2. One of the already registered `redirect_uri` that Veracross will redirect users to upon successful login (remember, this value should be URL encoded in the request).
3. `response_type=code`, which means that upon successful login, Veracross systems will also give you an **authorization code** that you will use to exchange for an **access token** to use with subsequent requests.
4. The `scope`, which specifies a list of scopes, separated by spaces, for the scopes for which you want to authorize the user, for example `scope = sso`.

> Note: Using SSO requires having an OAuth Application [registered at each school](https://community.veracross.com/s/article/Creating-an-OAuth-Application-School-Workflow). Vendors must provide the `redirect_uri`s and `scope`s they require, and will receive the corresponding OAuth `client_id` and `client_secret` values.

Unlike most public OAuth implementations (eg, "Log In with Facebook", "Log In with Google", etc), Veracross users won't see a separate "approval" screen when logging in. This is intentional; at Veracross, SSO to a vendor site is pre-approved with the set up of the OAuth Application by an administrator, and no separate approval from end users is necessary.

#### Endpoint applies to:

| Grant Type | Applicable |
|------------|------------|
| Client Credentials | ❌ |
| Authorization Code | ✅ |
| Refresh Token      | ❌ |

#### Related links:
- https://tools.ietf.org/html/rfc6749#section-3.1
- https://www.oauth.com/oauth2-servers/accessing-data/authorization-request/


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `client_id` | string | yes | This is the client_id from your OAuth Application. It will be different for each school that you work with. |
| `redirect_uri` | string | yes | Veracross will redirect to this URI upon successful login. It needs to be URL encoded, HTTPS, and registered on your OAuth Application.  It redirects with the `code` parameter which will be exchanged for the `access_token`. |
| `response_type` | string | yes | Needs to be `code` |
| `scope` | string | yes | List of requested scopes (separated by spaces). To complete SSO, the `sso` scope must be requested. All requested scopes must already be enabled by the school on your OAuth Application. |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `Content-Type` | string | yes | Needs to be `application/x-www-form-urlencoded` |


### Responses


**200** — Responds HTML with Veracross login form if the browser isn't authorized yet. Otherwise it goes directly to the `redirect_uri`



---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
