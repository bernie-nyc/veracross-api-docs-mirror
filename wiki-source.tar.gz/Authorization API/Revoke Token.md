> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API / OAuth / Revoke Token · [source site](https://api-docs.veracross.com/)

---


# Revoke Token


## POST `/oauth/revoke`


Revoke Token


Post with client credentials to revoke an access token. The authorization server responds with HTTP status code 200 if the token has been revoked successfully or if the client submitted an invalid token.

<!-- theme: warning -->
> Note: per the OAuth spec, attempting to revoke an invalid token has no effect.

The content of the response body should be ignored by the client as all necessary information is conveyed in the response code.

A revoked token can no longer be used for any other endpoint. The response codes/bodies may vary depending on the endpoint. For example, Token Info (`GET /oauth/token/info`) returns `401 Unauthorized`, whereas Token Introspection (`POST /oauth/introspect`) still returns `200 OK`, but `active: false` in the body.

#### Endpoint applies to:
| Grant Type | Applicable |
|------------|------------|
| Client Credentials | ✅ |
| Authorization Code | ✅ |
| Refresh Token      | ✅ |

#### Related links
- https://tools.ietf.org/html/rfc7009
- https://www.oauth.com/oauth2-servers/listing-authorizations/revoking-access/
- https://oauth.net/2/token-revocation/


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `Content-Type` | string | yes | Needs to be `application/x-www-form-urlencoded` |


### Request body


**Content type:** `application/x-www-form-urlencoded`


| Field | Type | Required | Description |
|---|---|---|---|
| `client_id` | string | yes |  |
| `client_secret` | string | yes |  |
| `token` | string | yes |  |

### Responses


**200** — OK



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|

Example:

```json
{
  "id": "380f634c43773",
  "key": "Success",
  "value": {}
}
```


**401** — Unauthorized



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | An error code |
| `error_description` | string | yes | The description of the error |
| `error_id` | string |  | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

Example:

```json
{
  "id": "2c699c8b8d9aa",
  "key": "Error Example",
  "value": {
    "error": "invalid_client",
    "error_description": "The requested client id is unknown or unauthorized.",
    "error_id": "896204e2-89e9-46c9-2fd0-ef74df63d513"
  },
  "summary": "Invalid Client"
}
```


**415** — Unsupported media type. This happens when the requests lacks the header `application/x-www-form-urlencoded`.



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|

Example:

```json
{
  "id": "3bdc8c6994182",
  "key": "UnsupportedMediaType",
  "value": {}
}
```


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
