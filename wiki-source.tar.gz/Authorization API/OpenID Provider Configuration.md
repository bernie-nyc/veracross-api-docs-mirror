> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Authorization API / OIDC / OpenID Provider Configuration · [source site](https://api-docs.veracross.com/)

---


# OpenID Provider Configuration


## GET `/.well-known/openid-configuration`


OpenID Provider Configuration


The OpenID Provider Configuration endpoint provides metadata about the OpenID Provider (OP). This metadata includes information such as the issuer identifier, authorization endpoint, token endpoint, userinfo endpoint, and supported scopes and claims.

Clients can use this metadata to dynamically configure themselves to interact with the OP without requiring manual configuration.

#### Related links
- https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderConfigurationRequest
- https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderMetadata


### Responses


**200** — OK



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `issuer` | string | yes | Issuer URL |
| `authorization_endpoint` | string | yes | Authorization endpoint URL |
| `token_endpoint` | string | yes | Token endpoint URL |
| `revocation_endpoint` | string |  | Revocation endpoint URL |
| `introspection_endpoint` | string |  | Introspection endpoint URL |
| `userinfo_endpoint` | string |  | User Info endpoint URL |
| `jwks_uri` | string | yes | JWKS endpoint URL |
| `scopes_supported` | array<string> |  | List of supported scopes (this might not be an exhaustive list) |
| `response_types_supported` | array<string> | yes | List of supported OAuth2 `response_type` values |
| `response_modes_supported` | array<string> |  | List of supported Oauth2 `response_mode` values |
| `grant_types_supported` | array<string> |  | List of supported OAuth2 `grant_type` values |
| `token_endpoint_auth_methods_supported` | array<string> |  | List of supported OAuth2 Client Authentication methods in the token endpoint |
| `subject_types_supported` | array<string> | yes | List of supported Subject Identifier types |
| `id_token_signing_alg_values_supported` | array<string> | yes | List of supported JWS signing algorithms (`alg` values) for the ID token |
| `claim_types_supported` | array<string> |  | List of supported Claim Types |
| `claims_supported` | array<string> |  | List of supported Claim Names we MAY be able to supply values for (this might not be an exhaustive list) |

Example:

```json
{
  "id": "621dda571ffd6",
  "key": "Success",
  "value": {
    "issuer": "http://accounts.veracross.com/your-school",
    "authorization_endpoint": "http://accounts.veracross.com/your-school/oauth/authorize",
    "token_endpoint": "http://accounts.veracross.com/your-school/oauth/token",
    "revocation_endpoint": "http://accounts.veracross.com/your-school/oauth/revoke",
    "introspection_endpoint": "http://accounts.veracross.com/your-school/oauth/instrospect",
    "userinfo_endpoint": "http://accounts.veracross.com/your-school/oauth/userinfo",
    "jwks_uri": "http://accounts.veracross.com/your-school/oauth/discovery/keys",
    "scopes_supported": [
      "openid"
    ],
    "response_types_supported": [
      "code"
    ],
    "response_modes_supported": [
      "query",
      "fragment",
      "form_post"
    ],
    "grant_types_supported": [
      "authorization_code",
      "client_credentials",
      "refresh_token"
    ],
    "token_endpoint_auth_methods_supported": [
      "client_secret_post"
    ],
    "subject_types_supported": [
      "public"
    ],
    "id_token_signing_alg_values_supported": [
      "RS256"
    ],
    "claim_types_supported": [
      "normal"
    ],
    "claims_supported": [
      "iss",
      "sub",
      "aud",
      "exp",
      "iat",
      "preferred_username",
      "email",
      "roles"
    ]
  }
}
```


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
