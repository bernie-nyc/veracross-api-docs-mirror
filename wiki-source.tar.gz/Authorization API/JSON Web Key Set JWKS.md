> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Authorization API / OIDC / JSON Web Key Set (JWKS) · [source site](https://api-docs.veracross.com/)

---


# JSON Web Key Set (JWKS)


## GET `/oauth/discovery/keys`


JSON Web Key Set (JWKS)


The JSON Web Key Set (JWKS) endpoint returns the public keys used to verify JSON Web Tokens (JWTs) issued by the authorization server.
This endpoint is commonly used in OpenID Connect 1.0 (OIDC) flows to verify the authenticity and integrity of ID tokens.

#### Related links
- https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderMetadata
- https://www.rfc-editor.org/rfc/rfc7517.html
- https://datatracker.ietf.org/doc/html/rfc7518
- https://openid.net/specs/openid-connect-core-1_0.html#AuthorizationExamples


### Responses


**200** — OK



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `keys` | array<object> | yes |  |

<details><summary><code>keys</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `kty` | string | yes | Key type parameter identifies the cryptographic algorithm family used with the key, such as "RSA" or "EC" |
| `n` | string |  | Modulus parameter of the RSA public key |
| `e` | string |  | Exponent parameter of the RSA public key |
| `kid` | string | yes | Key ID parameter is used to match a specific key. It is typically used to identify the key in a set of keys |
| `use` | string <small>enum</small>: `"sig"`, `"enc"` | yes | Intended use of the public key, such as "sig" for signature or "enc" for encryption |
| `alg` | string | yes | Algorithm intended for use with the key, such as "RS256" for RSA SHA-256 |

</details>

Example:

```json
{
  "id": "cd932ecb3779a",
  "key": "Success",
  "value": {
    "keys": [
      {
        "kty": "RSA",
        "n": "y0ur_modulus_h3r3",
        "e": "AQAB",
        "kid": "y0ur_key_id_h3r3",
        "use": "sig",
        "alg": "RS256"
      }
    ]
  }
}
```


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
