> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API / Schemas / EmptyObject · [source site](https://api-docs.veracross.com/)

---


# EmptyObject


Schema definition:


| Field | Type | Required | Description |
|---|---|---|---|

<details><summary>Raw JSON Schema</summary>

```json
{
  "type": "object",
  "properties": {},
  "$schema": "http://json-schema.org/draft-07/schema#"
}
```

</details>


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
