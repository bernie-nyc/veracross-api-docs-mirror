> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Authorization API / Schemas / EmptyObject · [source site](https://api-docs.veracross.com/)

---


# EmptyObject


Schema definition:


| Field | Type | Required | Description |
|---|---|---|---|

<details><summary>Raw JSON Schema</summary>

```json
{
  "type": "object",
  "properties": {},
  "$schema": "http://json-schema.org/draft-07/schema#"
}
```

</details>


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
