> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API / OAuth / User Info · [source site](https://api-docs.veracross.com/)

---


# User Info


## GET `/oauth/userinfo`


User Info


The access token is used to retrieve info about the user that has logged in, such as their Veracross Account ID and username.

> Note: `sub` is the internal account id, and uniquely identifies a user at a school. It must be combined with the school route to become globally unique. For example, different users at different schools might have the same `sub` value. Also note that schools may configure their own format for `preferred_username`, so it should only be used for display purposes (eg, some schools use email, some schools use other id's, etc)

#### Endpoint applies to:

| Grant Type | Applicable |
|------------|------------|
| Client Credentials | ❌ |
| Authorization Code | ✅ |
| Refresh Token      | ❌ |

#### Related links
- https://www.oauth.com/oauth2-servers/signing-in-with-google/verifying-the-user-info/
- https://openid.net/specs/openid-connect-core-1_0.html#UserInfo
- https://community.veracross.com/s/article/Person-Role-Definitions


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `Authorization` | string | yes | The access token |
| `Content-Type` | string | yes | Needs to be `application/x-www-form-urlencoded` |


### Responses


**200** — OK



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `sub` | string | yes |  |
| `preferred_username` | string | yes |  |
| `email` | ['string', 'null'] |  |  |
| `roles` | ['array', 'null'] |  |  |

Example:

```json
{
  "id": "ae40734a5f613",
  "key": "Success",
  "value": {
    "sub": "1234",
    "preferred_username": "john.doe",
    "email": "john.doe@example.com",
    "roles": [
      "Parent",
      "Coach",
      "Staff",
      "Faculty",
      "Donor"
    ]
  }
}
```


**401** — Unauthorized



Content type: `application/json`


Example:

```json
{
  "id": "e630c5ed3dd60",
  "key": "Unauthorized",
  "value": ""
}
```


**403** — Forbidden. This happens when the access token lacks a required scope.



**404** — Not Found. There was no user associated with the provided access token. This can happen if the request uses an access token created with the Client Credentials grant type; since those exist apart from an individual user identity, there's no user info that can be provided. User info requests should only be made with Authorization Code access tokens.



**415** — Unsupported media type. This happens when the requests lacks the header `application/x-www-form-urlencoded`.



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|

Example:

```json
{
  "id": "3bdc8c6994182",
  "key": "UnsupportedMediaType",
  "value": {}
}
```


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
