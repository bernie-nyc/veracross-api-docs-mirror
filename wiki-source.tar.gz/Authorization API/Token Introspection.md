> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API / OAuth / Token Introspection · [source site](https://api-docs.veracross.com/)

---


# Token Introspection


## POST `/oauth/introspect`


Token Introspection


The Token Introspection extension defines a mechanism for resource servers to obtain information about access tokens. With this spec, resource servers can check the validity of access tokens, and find out other information such as which user and which scopes are associated with the token.

#### Endpoint applies to:

| Grant Type | Applicable |
|------------|------------|
| Client Credentials | ✅ |
| Authorization Code | ✅ |
| Refresh Token      | ✅ |

#### Related links
- https://tools.ietf.org/html/rfc7662
- https://www.oauth.com/oauth2-servers/token-introspection-endpoint/
- https://oauth.net/2/token-introspection/


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `Content-Type` | string | yes | Needs to be `application/x-www-form-urlencoded` |


### Request body


**Content type:** `application/x-www-form-urlencoded`


| Field | Type | Required | Description |
|---|---|---|---|
| `client_id` | string | yes |  |
| `client_secret` | string | yes |  |
| `token` | string | yes |  |

### Responses


**200** — OK



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `active` | boolean | yes |  |
| `scope` | string |  |  |
| `client_id` | ['string', 'null'] |  | null when used on token issued with authorization_code as grant_type |
| `token_type` | string |  |  |
| `exp` | integer |  |  |
| `iat` | integer |  |  |

Example:

```json
{
  "id": "36ffda3db6053",
  "key": "With valid access token",
  "value": {
    "active": true,
    "scope": "example.object:list another.thing:create",
    "client_id": null,
    "token_type": "Bearer",
    "exp": 1600821466,
    "iat": 1600817866
  }
}
```


Example:

```json
{
  "id": "f6a1f9aa1ef9f",
  "key": "With invalid token",
  "value": {
    "active": false
  }
}
```


**401** — Unauthorized



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | An error code |
| `error_description` | string | yes | The description of the error |
| `error_id` | string |  | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

Example:

```json
{
  "id": "2c699c8b8d9aa",
  "key": "Error Example",
  "value": {
    "error": "invalid_client",
    "error_description": "The requested client id is unknown or unauthorized.",
    "error_id": "896204e2-89e9-46c9-2fd0-ef74df63d513"
  },
  "summary": "Invalid Client"
}
```


**415** — Unsupported media type. This happens when the requests lacks the header `application/x-www-form-urlencoded`.



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|

Example:

```json
{
  "id": "3bdc8c6994182",
  "key": "UnsupportedMediaType",
  "value": {}
}
```


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
