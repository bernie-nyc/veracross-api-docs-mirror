> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Authorization API / Schemas / ErrorResponse · [source site](https://api-docs.veracross.com/)

---


# ErrorResponse


Schema definition:


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | An error code |
| `error_description` | string | yes | The description of the error |
| `error_id` | string |  | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

<details><summary>Raw JSON Schema</summary>

```json
{
  "type": "object",
  "properties": {
    "error": {
      "type": "string",
      "description": "An error code"
    },
    "error_description": {
      "type": "string",
      "description": "The description of the error"
    },
    "error_id": {
      "type": "string",
      "description": "A unique ID for this specific error. Please provide this error id when you ask for help with an error."
    }
  },
  "required": [
    "error",
    "error_description"
  ],
  "$schema": "http://json-schema.org/draft-07/schema#"
}
```

</details>


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
