> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Authorization API / Schemas / ErrorResponse · [source site](https://api-docs.veracross.com/)

---


# ErrorResponse


Schema definition:


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | An error code |
| `error_description` | string | yes | The description of the error |
| `error_id` | string |  | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

<details><summary>Raw JSON Schema</summary>

```json
{
  "type": "object",
  "properties": {
    "error": {
      "type": "string",
      "description": "An error code"
    },
    "error_description": {
      "type": "string",
      "description": "The description of the error"
    },
    "error_id": {
      "type": "string",
      "description": "A unique ID for this specific error. Please provide this error id when you ask for help with an error."
    }
  },
  "required": [
    "error",
    "error_description"
  ],
  "$schema": "http://json-schema.org/draft-07/schema#"
}
```

</details>


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
