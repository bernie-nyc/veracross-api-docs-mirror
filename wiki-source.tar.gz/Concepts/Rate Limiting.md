> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Concepts / Rate Limiting · [source site](https://api-docs.veracross.com/)

---


# Rate Limiting


Rate Limiting

All requests to the Data API are subject to rate limiting. The basis of the limit is the Access Tokens.

Each Access Token is limited to 300 requests every 3 minutes from the first request. Every 3 minutes, the limit will reset. When the rate limit is exceeded, an HTTP `429 Too many requests` response will be issued, see [Errors](Errors.md) for more details.

### Response Headers

Each response from the Data API will include rate limiting headers. You can use these headers to avoid exceeding the allotted request capacity.

| Response Header | Description |
|--------------------|--------------|
| `X-Rate-Limit-Limit` | The maximum number of requests per limit period. |
| `X-Rate-Limit-Remaining` | The number of requests remaining in the current limiting period. |
| `X-Rate-Limit-Reset` | The timestamp when the current limiting period resets. |


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
