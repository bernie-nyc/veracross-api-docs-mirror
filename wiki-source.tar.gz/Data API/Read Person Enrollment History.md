> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Person Enrollment History / Read Person Enrollment History · [source site](https://api-docs.veracross.com/)

---


# Read Person Enrollment History


## GET `/person_enrollment_history/{id}`


Read Person Enrollment History


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | PEH ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | PEH ID |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `school_year` | integer | yes | School Year Enrolled  From the Enrollment History table, which contains one or more records for every year the student was enrolled.  (Note the Enrollment History table does not get populated for the current year until after the first day of school.) |
| `grading_period_id` | integer | yes | Grading Period Enrolled |
| `grade_level_id` | integer | yes | Grade Level Enrolled At |
| `campus_id` | integer | yes | Campus |
| `resident_status_id` | integer | yes | Resident Status |
| `student_group_id` | integer | yes | Student Group |
| `status_id` | integer | yes | Status: Partial Year  Indicates whether this Enrollment History record represents a mid-year enroll, an early withdrawal, or a return after missing the prior grading-period |
| `date_enrolled` | string | yes | Date Enrolled |
| `date_withdrawn` | string | yes | Date Withdrawn |
| `withdraw_reason_id` | integer | yes | Withdraw Reason |
| `is_first_year_enrolled` | boolean <small>read-only</small> | yes | First Year  Indicates whether this is the first year the student was enrolled |
| `is_last_year_enrolled` | boolean <small>read-only</small> | yes | Last Year  Indicates whether this is the last year the student was enrolled |
| `notes` | string <small>max 300</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
