> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Rubric Scales - Levels / Create Academics: Rubric Scales - Levels · [source site](https://api-docs.veracross.com/)

---


# Create Academics: Rubric Scales - Levels


## POST `/academics/rubric_scale_levels`


Create Academics: Rubric Scales - Levels


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | ID |
| `description` | string <small>max 500</small> | yes | Description |
| `abbreviation` | string <small>max 35</small> | yes | Abbreviation |
| `numeric_value` | number |  | Numeric Value |
| `notes` | string |  | Notes |
| `sort_key` | integer |  | Sort Key |
| `scale_id` | integer | yes | Scale |
| `scale_description` | string <small>max 200</small> | yes | Description |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
