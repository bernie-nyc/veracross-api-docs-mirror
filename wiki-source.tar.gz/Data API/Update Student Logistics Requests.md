> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Student Logistics Requests / Update Student Logistics Requests · [source site](https://api-docs.veracross.com/)

---


# Update Student Logistics Requests


## PATCH `/student_logistics_requests/{id}`


Update Student Logistics Requests


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Student Logistics Request ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Student Logistics Request ID |
| `student_id` | integer |  | Student ID |
| `student_name` | string <small>read-only</small> |  | Student |
| `requestor_id` | integer |  | Requestor ID |
| `requestor_name` | string <small>read-only</small> |  | Requestor |
| `date` | string |  | Request Date |
| `status` | integer |  | Request Status |
| `category` | string |  | Request Category |
| `reason` | string |  | Request Reason |
| `notes` | string <small>max 1000</small> |  | Request Notes |
| `attendance_start_date` | string |  | Attendance Start Date |
| `attendance_time` | string |  | Attendance Time |
| `attendance_end_date` | string |  | Attendance End Date |
| `attendance_return_time` | string |  | Attendance Return Time |
| `attendance_type` | integer |  | Attendance Type |
| `transportation_method` | string |  | Transportation Method |
| `am_pm` | integer |  | AM/PM |
| `bus_stop` | integer |  | Bus Stop |
| `bus_route` | string |  | Bus Route |
| `response_notes` | string <small>max 1000</small> |  | Response Notes |
| `internal_notes` | string <small>max 1000</small> |  | Internal Notes |
| `extended_care_type` | string <small>max 20</small> |  | Extended Care Type |
| `extended_care_arrival_time` | string |  | Extended Care Arrival Time |
| `extended_care_leave_time` | string |  | Extended Care Leave Time |
| `internal_class_id` | integer |  | Drop In Class Internal ID  Internal only for API use |
| `posted` | boolean |  | Posted |
| `send_notification` | boolean |  | Send Notification?  When set, this will send notifications to staff members as configured. |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |
| `last_modified_user` | string <small>read-only</small> |  | Last Modified User |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
