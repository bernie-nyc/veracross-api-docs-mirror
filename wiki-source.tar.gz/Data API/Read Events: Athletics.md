> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Events: Athletics / Read Events: Athletics · [source site](https://api-docs.veracross.com/)

---


# Read Events: Athletics


## GET `/events/athletics/{event_id}`


Read Events: Athletics


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `event_id` | integer | yes | Event ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Event ID |
| `event_type_id` | integer | yes | Event Type |
| `event_type_description` | string <small>read-only</small> | yes | Event Type Description |
| `description` | string <small>max 200</small> | yes | Description |
| `school_level_id` | integer | yes | School Level  The school level associated with this event.    Within the context of parent/teacher conferences, this field is used in conjunction with the Grade Level field to determine who is eligible to sign up for a conference. Example: if School Level = Upper School and Grade Level = Grade 8, any parent of a student in Upper School OR Grade 8 is eligible to sign up for the conference slot. |
| `school_level_description` | string <small>read-only</small> | yes | School Level Description |
| `internal_team_id` | integer | yes | Internal Group ID |
| `internal_class_id` | integer <small>read-only</small> | yes | Internal Class ID |
| `team_description` | string <small>read-only</small> | yes | Primary Group Name |
| `athletic_opponent` | string | yes | Opponent |
| `game_type_id` | integer | yes | Game Type |
| `game_type_description` | string <small>read-only</small> | yes | Game Type Description |
| `home_away_id` | integer | yes | Home/Away |
| `home_away_description` | string <small>read-only</small> | yes | Home/Away Description |
| `out_of_conference` | boolean | yes | Out Of Conference |
| `make_up` | boolean | yes | Make-Up |
| `destination_organization` | string <small>read-only</small> | yes | Destination Organization  The external Organization where this event will be located.  For athletic events, should only be specified if different from the Opponent field. |
| `destination_organization_id` | integer | yes | Destination Organization ID  The external Organization where this event will be located.  For athletic events, should only be specified if different from the Opponent field. |
| `location` | string <small>read-only</small> | yes | Internal Location Resource Description  The description of the internal resource for this event. |
| `depart_from` | string <small>max 50</small> | yes | Depart From |
| `class_departure_time` | string <small>max 8</small> | yes | Class Departure Time |
| `campus_departure_time` | string <small>max 8</small> | yes | Campus Departure Time |
| `transportation_id` | integer | yes | Transportation |
| `transportation_description` | string <small>read-only</small> | yes | Transportation Description |
| `transportation_resource` | string <small>read-only</small> | yes | Transportation Resource |
| `transportation_resource_id` | integer | yes | Transportation Resource ID |
| `google_map` | string <small>read-only</small> | yes | Map |
| `google_directions_from_school` | string <small>read-only</small> | yes | Directions from School |
| `event_status_id` | integer | yes | Event Status |
| `event_status_description` | string <small>read-only</small> | yes | Event Status Description |
| `start_date` | string | yes | Start Date |
| `end_date` | string <small>max 10</small> | yes | End Date |
| `start_time` | string <small>max 8</small> | yes | Start Time |
| `end_time` | string <small>max 8</small> | yes | End Time |
| `venue_departure_time` | string <small>max 8</small> | yes | Venue Departure Time |
| `campus_return_time` | string <small>max 8</small> | yes | Campus Return Time |
| `notes` | string <small>max 1000</small> | yes | Notes |
| `game_outcome_id` | integer | yes | Game Outcome |
| `game_outcome_description` | string <small>read-only</small> | yes | Game Outcome Description |
| `game_score_us` | number | yes | Score - Us |
| `game_score_opponent` | number | yes | Score - Opponent |
| `placement_id` | integer | yes | Game Placement |
| `placement_description` | string <small>read-only</small> | yes | Game Placement Description |
| `overtime` | boolean | yes | Overtime |
| `summary` | string <small>max 1500</small> | yes | Summary |
| `update_date` | string | yes | Update Date |
| `public` | boolean | yes | Display On Public Calendar |
| `series_template` | boolean | yes | Series Master Event  If selected, individual events will be created for each day that the event takes place |
| `daily_attendance_status` | integer | yes | Daily Attendance Status  The daily attendance status that will be used for students who participate in this event. This value will be applied to daily attendance for all the students affected by this event. Leaving this value set as &quot;none specified&quot; will leave the daily attendance status as &quot;Present&quot; for all the students. |
| `class_attendance_status` | integer | yes | Class Attendance Status  The class attendance status that will be used for students who participate in this event. This value will be applied to class attendance for all the classes affected by this event between Class Departure Time and Campus Return Time. |
| `attendance_taken` | integer | yes | Attendance Taken |
| `display_on_parent_calendar` | boolean | yes | Display On Parent Calendar |
| `display_on_student_calendar` | boolean | yes | Display On Student Calendar |
| `display_on_staff_faculty_calendar` | boolean | yes | Display On Staff/Faculty Calendar |
| `display_on_alumni_calendar` | boolean | yes | Display On Alumni Calendar |
| `display_on_group_members_calendar` | boolean | yes | Display On Group Members Calendar |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
