> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Classes / Read Academics: Classes · [source site](https://api-docs.veracross.com/)

---


# Read Academics: Classes


## GET `/academics/classes/{id}`


Read Academics: Classes


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Internal Class ID |
| `class_id` | string <small>max 20</small> | yes | Class ID  Class ID associated with this class. School-defined value. Must be unique in the school year. Special characters, punctuation, and spaces are not sufficient for uniqueness.     Example: GYM 1 and GYM: 1 are not unique. GYM 1a and GYM 1b are unique. |
| `description` | string <small>max 80</small> | yes | Description |
| `status` | integer | yes | Status  Status of the class (active, future, etc.) |
| `school_year` | integer | yes | School Year |
| `begin_date` | string | yes | Begin Date |
| `end_date` | string | yes | End Date |
| `primary_grade_level_id` | integer | yes | Primary Grade Level ID |
| `school_level` | integer | yes | School Level |
| `internal_course_id` | integer | yes | Course ID |
| `primary_teacher_id` | integer | yes | Teacher ID |
| `room_id` | integer | yes | Room ID |
| `virtual_meeting_url` | string <small>max 2000</small> | yes | Virtual Meeting URL  To toggle the display of this field in the daily student/faculty schedule, update the configuration on the Website Configuration tab. |
| `subject_id` | integer | yes | Subject |
| `department_id` | integer <small>read-only</small> | yes | ID |
| `internal_group_id` | integer | yes | System Group ID |
| `parent_portal_visibility` | integer | yes | Parent Portal Visibility  Indicates whether this class will display on the Parent Portal |
| `parent_portal_assignment_display` | integer | yes | Parent Portal Assignment Display  Indicates whether assigments and assignment grades display on the Parent Portal |
| `student_portal_visibility` | integer | yes | Student Portal Visibility  Indicates whether this class will display on the Student Portal |
| `student_portal_assignment_display` | integer | yes | Student Portal Assignment Display  Indicates whether assigments and assignment grades display on the Student Portal |
| `track_class_attendance` | boolean | yes | Track Class Attendance  Indicates whether to maintain Class-level attendance for this class in addition to Daily attendance |
| `trigger_imperfect_attendance` | boolean | yes | Trigger Imperfect Attendance  When selected, if a student&#39;s attendance status for this class is in conflict with their daily attendance status, the Daily Attendance status will be updated to &quot;Imperfect Class Attendance&quot;. The most common reason to deselect this field is if this class is an after school activity or athletic team whose attendance isn&#39;t relevant to Daily Attendance. (This option only matters if &quot;Track Attendance&quot; is selected.) |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
