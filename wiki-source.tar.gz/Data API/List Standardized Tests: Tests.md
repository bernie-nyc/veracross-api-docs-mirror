> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Standardized Tests: Tests / List Standardized Tests: Tests · [source site](https://api-docs.veracross.com/)

---


# List Standardized Tests: Tests


## GET `/standardized_tests/tests`


List Standardized Tests: Tests


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer |  | Person ID |
| `test_type` | integer |  | Test Type  E.g., PSAT, SAT, ACT, TOEFL |
| `test_year` | integer |  | Test Year  The year the test was taken, entered manually if the exact date is not known. |
| `test_date` | string |  | Test Date  The date the test was taken |
| `grade_level` | integer |  | Grade Level  The grade level of the student at the time of taking the test |
| `course` | integer |  | Course ID |
| `class_enrollment` | string |  | Class Enrollment |
| `include_in_summary` | boolean |  | Include In Summary |
| `created_date` | string |  | Input Date |
| `last_modified_date` | string |  | Update Date |
| `on_or_after_last_modified_date` | string |  | Update Date |
| `on_or_after_created_date` | string |  | Input Date |
| `on_or_before_last_modified_date` | string |  | Update Date |
| `on_or_before_created_date` | string |  | Input Date |
| `on_or_after_test_date` | string |  | Test Date  The date the test was taken |
| `on_or_before_test_date` | string |  | Test Date  The date the test was taken |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person Standardized Test ID |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `test_type` | integer | yes | Test Type  E.g., PSAT, SAT, ACT, TOEFL |
| `test_type_description` | string <small>max 50</small> <small>read-only</small> | yes | Description (read-only) |
| `test_year` | integer | yes | Test Year  The year the test was taken, entered manually if the exact date is not known. |
| `test_date` | string | yes | Test Date  The date the test was taken |
| `grade_level` | integer | yes | Grade Level  The grade level of the student at the time of taking the test |
| `course` | integer | yes | Course ID |
| `class_enrollment` | string | yes | Class Enrollment |
| `test_administered_by` | string <small>max 200</small> | yes | Test Administered By |
| `notes` | string | yes | Notes |
| `include_in_summary` | boolean | yes | Include In Summary |
| `created_date` | string | yes | Input Date |
| `last_modified_date` | string | yes | Update Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
