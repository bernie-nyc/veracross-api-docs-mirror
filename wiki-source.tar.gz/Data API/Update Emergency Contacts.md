> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Emergency Contacts / Update Emergency Contacts · [source site](https://api-docs.veracross.com/)

---


# Update Emergency Contacts


## PATCH `/emergency_contacts/{id}`


Update Emergency Contacts


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Person ID |
| `person_id` | integer |  | Person ID |
| `student_id` | integer |  | Student ID |
| `first_name` | string <small>max 50</small> |  | First Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> |  | Last Name |
| `nick_name` | string <small>max 50</small> |  | Nick Name |
| `relationship` | integer |  | Relationship  The relationship this emergency contact has to the student |
| `legal_custody` | boolean |  | Legal Custody |
| `pick_up` | boolean |  | Pick Up |
| `medical_notification` | boolean |  | Medical Notification |
| `email_1` | string <small>max 100</small> |  | Email 1 |
| `email_2` | string <small>max 100</small> |  | Email 2 |
| `home_phone` | string <small>max 30</small> |  | Home Phone |
| `mobile_phone` | string <small>max 30</small> |  | Mobile Phone |
| `business_phone` | string <small>max 30</small> |  | Business Phone |
| `address_1` | string <small>max 200</small> |  | Address 1 |
| `address_2` | string <small>max 200</small> |  | Address 2 |
| `city` | string <small>max 50</small> |  | City |
| `state_province` | string <small>max 50</small> |  | State Province |
| `postal_code` | string <small>max 20</small> |  | Postal Code |
| `country` | integer |  | Country |
| `notes` | string <small>max 1000</small> |  | Notes |
| `last_modified_date` | string |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
