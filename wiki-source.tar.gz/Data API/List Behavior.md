> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Behavior / List Behavior · [source site](https://api-docs.veracross.com/)

---


# List Behavior


## GET `/behavior`


List Behavior


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `on_or_after_incident_date` | string |  | Incident Date |
| `on_or_before_incident_date` | string |  | Incident Date |
| `incident_type` | integer |  | Incident Type |
| `student_id` | integer |  | Student ID |
| `reporting_person_id` | integer |  | Reporting Person ID |
| `assigned_to_person_id` | integer |  | Assigned To Person ID |
| `internal_class_id` | integer |  | Class ID |
| `status` | integer |  | Status |
| `outcome_type` | integer |  | Outcome Type |
| `school_year` | integer |  | School Year |
| `grading_period` | integer |  | Grading Period |
| `on_or_before_last_modified_date` | string |  | Update Date |
| `on_or_after_last_modified_date` | string |  | Update Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Behavior ID |
| `incident_date` | string | yes | Incident Date |
| `on_or_before_incident_date` | string | yes | Incident Date |
| `on_or_after_incident_date` | string | yes | Incident Date |
| `incident_type` | integer | yes | Incident Type |
| `student_id` | integer | yes | Student ID |
| `reporting_person_id` | integer | yes | Reporting Person ID |
| `assigned_to_person_id` | integer | yes | Assigned To Person ID |
| `internal_class_id` | integer | yes | Class ID |
| `class_name` | string <small>max 80</small> | yes | Description |
| `incident_notes` | string | yes | Incident Notes  Incident notes are for internal use and not visible to parents or students unless included in the email notification template.&#39; Email Template merge variable: {incident_notes} |
| `behavior_points` | integer <small>read-only</small> | yes | Behavior Points |
| `status` | integer | yes | Status |
| `status_date` | string | yes | Status Date |
| `outcome_type` | integer | yes | Outcome Type |
| `outcome_date` | string | yes | Outcome Date |
| `outcome_notes` | string | yes | Outcome Notes  Outcome notes are for internal use and not visible to parents or students unless included in the email notification template. Email Template merge variable: {outcome_notes} |
| `follow_up_status` | integer | yes | Follow Up Status |
| `follow_up_status_date` | string | yes | Follow Up Status Date |
| `last_modified_date` | string | yes | Update Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
