> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Applicants / Update Admission: Applicants · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Applicants


## PATCH `/admission/applicants/{applicant_id}`


Update Admission: Applicants


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `applicant_id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer |  | Household ID |
| `applicant_id` | integer <small>read-only</small> |  | Person ID |
| `name_prefix` | integer |  | Name Prefix |
| `first_name` | string <small>max 50</small> |  | First Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> |  | Last Name |
| `name_suffix` | integer |  | Name Suffix |
| `nick_name` | string <small>max 50</small> |  | Preferred Name |
| `gender` | integer |  | Gender |
| `pronouns` | integer |  | Pronouns |
| `ethnicity` | integer |  | Ethnicity (deprecated)  Information on handling Special Category data is available at https://www.veracross.com/privacy-policy |
| `date_of_birth` | string |  | Birthday  Birthday in MMM DD YYYY format |
| `place_of_birth` | string <small>max 50</small> |  | Place of Birth |
| `email` | string <small>max 100</small> |  | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `mobile_phone` | string <small>max 30</small> |  | Mobile Phone |
| `current_grade` | integer |  | Current Grade |
| `roles` | string <small>read-only</small> |  | Roles  A list of all roles specified for this person.  Roles define this person&#39;s relationship to the school.  Can include &quot;virtual&quot; roles such as &quot;Relative of Alum&quot;. |
| `admissions_notes` | string <small>max 2000</small> |  | Admissions Notes  Notes that are specific to this individual (not the Application) for use by the Admissions department.  Cannot be seen by non-Admissions personnel. |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
