> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Applicants / List Admission: Applicants · [source site](https://api-docs.veracross.com/)

---


# List Admission: Applicants


## GET `/admission/applicants`


List Admission: Applicants


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `first_name` | string |  | First Name |
| `last_name` | string |  | Last Name |
| `date_of_birth` | string |  | Birthday  Birthday in MMM DD YYYY format |
| `email` | string |  | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `role` | integer |  | Role |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer | yes | Household ID |
| `applicant_id` | integer <small>read-only</small> | yes | Person ID |
| `name_prefix` | integer | yes | Name Prefix |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `name_suffix` | integer | yes | Name Suffix |
| `nick_name` | string <small>max 50</small> | yes | Preferred Name |
| `gender` | integer | yes | Gender |
| `pronouns` | integer | yes | Pronouns |
| `ethnicity` | integer | yes | Ethnicity (deprecated)  Information on handling Special Category data is available at https://www.veracross.com/privacy-policy |
| `date_of_birth` | string | yes | Birthday  Birthday in MMM DD YYYY format |
| `place_of_birth` | string <small>max 50</small> | yes | Place of Birth |
| `email` | string <small>max 100</small> | yes | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `mobile_phone` | string <small>max 30</small> | yes | Mobile Phone |
| `current_grade` | integer | yes | Current Grade |
| `roles` | string <small>read-only</small> | yes | Roles  A list of all roles specified for this person.  Roles define this person&#39;s relationship to the school.  Can include &quot;virtual&quot; roles such as &quot;Relative of Alum&quot;. |
| `admissions_notes` | string <small>max 2000</small> | yes | Admissions Notes  Notes that are specific to this individual (not the Application) for use by the Admissions department.  Cannot be seen by non-Admissions personnel. |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
