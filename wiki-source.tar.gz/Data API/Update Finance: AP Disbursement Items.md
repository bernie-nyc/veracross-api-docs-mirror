> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Disbursement Items / Update Finance: AP Disbursement Items · [source site](https://api-docs.veracross.com/)

---


# Update Finance: AP Disbursement Items


## PATCH `/finance/ap_disbursement_items/{id}`


Update Finance: AP Disbursement Items


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Disbursement Item ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `disbursement_item_id` | integer <small>read-only</small> |  | Disbursement Item ID |
| `disbursement_header_id` | integer |  | Disbursement Header ID |
| `disbursement_header` | string |  | Disbursement Header |
| `debit_gl_account` | string <small>read-only</small> |  | DR GL Account |
| `amount` | number |  | Amount  Amount of this transaction that has been posted to the general ledger. |
| `unapplied_amount` | number <small>read-only</small> |  | Unapplied Amount |
| `description` | string <small>max 80</small> |  | Description |
| `je_ref_id` | string <small>read-only</small> |  | JE Ref # - Read Only |
| `posted` | boolean <small>read-only</small> |  | Posted? - Read Only |
| `posting_date` | string <small>read-only</small> |  | Posting Date - Read Only |
| `cleared` | boolean |  | Cleared? |
| `ap_invoice_header` | string |  | AP Invoice |
| `ap_invoice_item` | string |  | AP Item |
| `input_date` | string <small>read-only</small> |  | Input Date (Local) |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |
| `ap_invoice_id` | integer |  | AP Invoice ID |
| `ap_invoice_item_id` | integer |  | AP Item ID |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
