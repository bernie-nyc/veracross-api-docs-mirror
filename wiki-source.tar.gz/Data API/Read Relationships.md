> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Relationships / Read Relationships · [source site](https://api-docs.veracross.com/)

---


# Read Relationships


## GET `/relationships/{id}`


Read Relationships


Deceased persons are included in the dataset by default, but may be filtered out via query parameter.


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person Person ID |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `related_person_id` | integer <small>read-only</small> | yes | Person ID |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `related_person_is_deceased` | boolean <small>read-only</small> | yes | Is Deceased? |
| `relationship` | integer | yes | Relationship  When background shading is available:  Orange: Immediate family, e.g. Husband, Wife, Father, Mother, Brother, Sister, Sibling, Domestic Partner  Yellow: Secondary family, e.g. Grandparents, Aunt/Uncle, Cousin  Manilla: In-Laws, Exes, Step-child, Step-parent, deceased spouse  Gray-Blue: &quot;Unspecified&quot; and &quot;Other&quot;  White: All others |
| `resident` | boolean <small>read-only</small> | yes | Resident  Indicates whether the related person lives in the same household |
| `custody_status` | string <small>read-only</small> | yes | API Custody Status |
| `legal_custody` | boolean | yes | Legal Custody  Indicates that the parent has legal custody of the child |
| `emergency` | boolean | yes | Emergency  Indicates that this is an emergency contact |
| `pick_up` | boolean | yes | Pick Up  Indicates that this is a pick-up contact |
| `parent_portal_access` | boolean | yes | Parent Portal Access  Gives this person parent portal access, regardless of legal custody settings |
| `profile_update_permission` | boolean | yes | Profile Update Permission  When selected, allows parent/guardians to update regarding the related candidate/student on the Household Profile Update form |
| `receive_general_correspondence` | boolean | yes | Receive General Correspondence  Indicates this person receives general correspondence. Used for any person who should receive general correspondence for this student, regardless of resident status. |
| `receive_report_cards` | boolean | yes | Receive Report Cards  Indicates this person receives report-cards. Reserved for Non-Resident people who are related to the student. |
| `receive_invoices` | boolean | yes | Receive Invoices  Axiom Student Billing Schools, this field is only used to indicate that a non-resident parent should see autopay requirements on their parent portal experience. However, for all other recipient management, recipients are managed at the Billing Account level for Axiom Student Billing Schools. |
| `receive_other` | boolean | yes | Receive Other  Indicates this person receives other school-defined correspondence |
| `medical_notification` | boolean | yes | Medical Notification  Indicates that this is a medical authorization contact |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
