> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Standardized Tests: Score Types / List Standardized Tests: Score Types · [source site](https://api-docs.veracross.com/)

---


# List Standardized Tests: Score Types


## GET `/standardized_tests/score_types`


List Standardized Tests: Score Types


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `test_type` | integer |  | Test Type |
| `data_type` | integer |  | Data Type |
| `primary_score` | boolean |  | Primary Score |
| `secondary_score` | boolean |  | Secondary Score |
| `tertiary_score` | boolean |  | Tertiary Score |
| `enabled` | boolean |  | Enabled |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `description` | string <small>max 50</small> | yes | Description |
| `override_description` | string <small>max 50</small> | yes | Override Description |
| `test_type` | integer | yes | Test Type |
| `data_type` | integer | yes | Data Type |
| `primary_score` | boolean | yes | Primary Score |
| `secondary_score` | boolean | yes | Secondary Score |
| `tertiary_score` | boolean | yes | Tertiary Score |
| `enabled` | boolean | yes | Enabled |
| `sort_key` | integer | yes | Sort Key |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
