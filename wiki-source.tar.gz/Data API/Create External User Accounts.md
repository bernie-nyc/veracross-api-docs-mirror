> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / External User Accounts / Create External User Accounts · [source site](https://api-docs.veracross.com/)

---


# Create External User Accounts


## POST `/external_user_accounts`


Create External User Accounts


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `external_account_id` | integer <small>read-only</small> |  | External Account ID |
| `type` | integer | yes | Type |
| `external_username` | string <small>max 255</small> | yes | Username |
| `status` | integer |  | Status |
| `person_fk` | integer | yes | Person ID |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
