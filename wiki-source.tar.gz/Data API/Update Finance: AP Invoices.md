> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Invoices / Update Finance: AP Invoices · [source site](https://api-docs.veracross.com/)

---


# Update Finance: AP Invoices


## PATCH `/finance/ap_invoices/{id}`


Update Finance: AP Invoices


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | AP Header ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | integer <small>read-only</small> |  | AP Header ID |
| `invoice_number` | string <small>max 30</small> |  | Invoice Number |
| `vendor` | string |  | Vendor |
| `vendor_id` | integer |  | Vendor ID |
| `invoice_date` | string |  | Invoice Date |
| `due_date` | string |  | Due Date |
| `posting_date` | string <small>read-only</small> |  | Posting Date - Read Only |
| `description` | string <small>max 80</small> |  | Description |
| `ap_gl_account` | string <small>read-only</small> |  | AP GL Account |
| `ap_gl_account_id` | integer |  | AP GL Account ID |
| `ap_gl_cost_center` | integer <small>read-only</small> |  | AP GL Cost Center - Read Only |
| `gross_amount` | number <small>read-only</small> |  | Gross Amount - Read Only |
| `as_posted_amount` | number <small>read-only</small> |  | As Posted Amount - Read Only |
| `net_amount_paid` | number <small>read-only</small> |  | Net Amount Paid - Read Only |
| `unpaid_amount` | number <small>read-only</small> |  | Unpaid Amount |
| `fiscal_year` | integer <small>read-only</small> |  | Fiscal Year - Read Only |
| `fiscal_period` | integer <small>read-only</small> |  | Fiscal Period - Read Only |
| `approval_person` | string <small>read-only</small> |  | Approval Person  Person who must approve this expense prior to its posting and payment |
| `approval_person_id` | integer |  | Approval Person ID |
| `cancelled` | boolean |  | Cancel?  This option cancels the entire invoice. |
| `posted` | boolean |  | Posted? |
| `do_not_pay` | boolean |  | Do Not Pay? |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |
| `tax_type` | string <small>read-only</small> |  | Tax Type ID for AP Invoices |
| `inclusive_exclusive` | string <small>read-only</small> |  | Inclusive/Exclusive for AP Invoices |
| `total_tax` | number |  | Total Tax |
| `input_date` | string |  | Input Date |
| `external_po_number` | string <small>max 60</small> |  | External PO Number |
| `external_po_url` | string <small>max 500</small> |  | External PO Url |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
