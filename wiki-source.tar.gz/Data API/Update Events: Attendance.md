> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Events: Attendance / Update Events: Attendance · [source site](https://api-docs.veracross.com/)

---


# Update Events: Attendance


## PATCH `/events/event_attendance/{id}`


Update Events: Attendance


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Individual Event ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Individual Event ID |
| `person_id` | integer |  | Person |
| `full_name` | string <small>read-only</small> |  | Full Name  The full name of an individual in the school-defined format, often &lt;last name&gt;, &lt;first name&gt; |
| `group_event_id` | integer |  | Group Event ID |
| `attendance_status` | integer |  | Attendance Status |
| `tag` | string <small>max 30</small> |  | Tag  Use to place event invitees into sub-groups, for example table-assignments |
| `score` | integer |  | Score |
| `event_type` | integer |  | Event Type  Event Type |
| `notes` | string |  | Notes  Used for various purposes depending on the event type.   For Inquiry events added by the system (which are added if a person has the prospect Role but no inquiry yet), Veracross will add the note &quot;(date approximate)&quot;. |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
