> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Resource Reservations: Resources / List Resource Reservations: Resources · [source site](https://api-docs.veracross.com/)

---


# List Resource Reservations: Resources


## GET `/resource_reservations/resources`


List Resource Reservations: Resources


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `resource_type` | integer |  | Resource Type |
| `campus_id` | integer |  | ID |
| `building_id` | integer |  | ID |
| `school_level_id` | integer |  | ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `resource_id` | integer <small>read-only</small> | yes | Resource ID |
| `description` | string <small>max 100</small> | yes | Description |
| `abbreviation` | string <small>max 20</small> | yes | Abbreviation |
| `resource_type` | integer | yes | Resource Type |
| `campus_id` | integer | yes | Campus |
| `campus_description` | string <small>max 50</small> | yes | Description |
| `building_id` | integer | yes | Building |
| `building_description` | string <small>max 100</small> | yes | Description |
| `school_level_id` | integer | yes | School Level |
| `school_level_description` | string <small>max 50</small> | yes | Description |
| `responsible_person_id` | string | yes | Responsible Person ID |
| `responsible_person_name` | string <small>read-only</small> | yes | Full Name  The full name of an individual in the school-defined format, often &lt;last name&gt;, &lt;first name&gt; |
| `allow_simultaneous_reservations` | integer | yes | Allow Simultaneous Reservations |
| `capacity` | integer | yes | Capacity  The amount of reservations that can occur at the same time. |
| `hourly_cost` | integer | yes | Hourly Cost |
| `reservation_approval_required` | boolean | yes | Reservation Approval Required |
| `set_up_time_required_in_mins` | integer | yes | Set-Up Time Required  The setup time in minutes required for this resource |
| `tear_down_time_required_in_mins` | integer | yes | Tear-Down Time Required  The tear-down time in minutes required for this resource |
| `used_by_athletics` | boolean | yes | Used By Athletics |
| `include_on_portals` | boolean | yes | Include on Portals |
| `notes` | string <small>max 1000</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
