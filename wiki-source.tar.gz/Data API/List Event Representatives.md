> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Event Representatives / List Event Representatives · [source site](https://api-docs.veracross.com/)

---


# List Event Representatives


## GET `/event_representatives`


List Event Representatives


The event representatives endpoint returns the following person IDs related to each group event record. Its default parameters are to return group events starting today.

1. Contact Person - the contact person on the group event.
2. Primary Representative - teachers/coaches who are associated with the class/team (via class permission records) which is the primary group associated with the event.
3. Primary Representative View Attendance - whether the teacher/coach that is a primary representative is able to view daily attendance records on the associated class/team.

It is possible for a person to be both a contact person and primary representative for a group event and will be denoted as such.


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `group_event_id` | integer |  | Event ID |
| `person_id` | integer |  | Person ID |
| `on_or_before_start_date` | string |  | Start Date |
| `on_or_after_start_date` | string |  | Start Date |
| `on_or_before_end_date` | string |  | End Date |
| `on_or_after_end_date` | string |  | End Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `group_event_id` | integer <small>read-only</small> | yes | Event ID |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `contact_person` | boolean | yes | Contact Person |
| `primary_representative` | boolean | yes | Primary Facstaff |
| `primary_representative_view_attendance` | boolean | yes | Primary Facstaff View Attendance |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
