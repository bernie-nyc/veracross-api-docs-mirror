> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Households / Update Households · [source site](https://api-docs.veracross.com/)

---


# Update Households


## PATCH `/households/{id}`


Update Households


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Household ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Household ID |
| `name` | string <small>max 50</small> |  | Name |
| `address_line_1` | string <small>read-only</small> |  | Address 1  Household Address 1 |
| `address_line_2` | string <small>read-only</small> |  | Address 2  Household Address 2 |
| `address_line_3` | string <small>read-only</small> |  | Address 3 |
| `city` | string <small>read-only</small> |  | City |
| `state_or_province` | string <small>read-only</small> |  | State |
| `zip` | string <small>read-only</small> |  | Postal Code |
| `country` | integer <small>read-only</small> |  | Country |
| `phone` | string <small>read-only</small> |  | Phone  Will be copied to the household members&#39; Home Phone fields overnight if (a) the member is a student or (b) the member&#39;s Home Phone is not already populated. |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |
| `active_address` | integer |  | Active Address  Used to designate the address to be used for mailings to this household. |
| `primary_address_line_1` | string <small>max 200</small> |  | Address 1 A |
| `primary_address_line_2` | string <small>max 200</small> |  | Address 2 A |
| `primary_address_line_3` | string <small>max 200</small> |  | Address 3 A |
| `primary_address_city` | string <small>max 50</small> |  | City A |
| `primary_address_state_or_province` | string <small>max 50</small> |  | State A |
| `primary_address_zip` | string <small>max 20</small> |  | Postal Code A |
| `primary_address_country` | integer |  | Country A |
| `primary_address_phone` | string <small>max 30</small> |  | Phone  Will be copied to the household members&#39; Home Phone fields overnight if (a) the member is a student or (b) the member&#39;s Home Phone is not already populated. |
| `secondary_address_1_line_1` | string <small>max 200</small> |  | Address 1 B |
| `secondary_address_1_line_2` | string <small>max 200</small> |  | Address 2 B |
| `secondary_address_1_line_3` | string <small>max 200</small> |  | Address 3 B |
| `secondary_address_1_city` | string <small>max 50</small> |  | City B |
| `secondary_address_1_state_or_province` | string <small>max 50</small> |  | State B |
| `secondary_address_1_zip` | string <small>max 20</small> |  | Postal Code B |
| `secondary_address_1_country` | integer |  | Country B |
| `secondary_address_1_phone` | string <small>max 30</small> |  | Phone B |
| `secondary_address_2_line_1` | string <small>max 200</small> |  | Address 1 C |
| `secondary_address_2_line_2` | string <small>max 200</small> |  | Address 2 C |
| `secondary_address_2_line_3` | string <small>max 200</small> |  | Address 3 C |
| `secondary_address_2_city` | string <small>max 50</small> |  | City C |
| `secondary_address_2_state_or_province` | string <small>max 50</small> |  | State C |
| `secondary_address_2_zip` | string <small>max 20</small> |  | Postal Code C |
| `secondary_address_2_country` | integer |  | Country C |
| `secondary_address_2_phone` | string <small>max 30</small> |  | Phone C |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
