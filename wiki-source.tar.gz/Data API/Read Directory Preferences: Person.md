> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Directory Preferences: Person / Read Directory Preferences: Person · [source site](https://api-docs.veracross.com/)

---


# Read Directory Preferences: Person


## GET `/directory/preferences/people/{id}`


Read Directory Preferences: Person


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Directory Type Preference ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person Directory Type Preference ID |
| `person_id` | integer | yes | Person ID |
| `person_name` | string <small>read-only</small> | yes | Person Name |
| `directory_type` | integer | yes | Directory Type |
| `status` | integer | yes | Status |
| `parents_display` | integer | yes | Parents Display Setting  “Legal Custody” means that the student displays in the in the household of the directory type for any parents with legal custody.    “All Parents” means that the student displays in the household of all parents irrespective of custody. |
| `photo_display` | integer | yes | Photo Display Setting |
| `mobile_phone_display` | integer | yes | Mobile Phone Display Setting |
| `email_1_display` | integer | yes | Email 1 Display Setting |
| `email_2_display` | integer | yes | Email 2 Display Setting |
| `business_phone_display` | integer | yes | Business Phone Display Setting |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
