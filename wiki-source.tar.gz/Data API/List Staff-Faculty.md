> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Staff/Faculty / List Staff/Faculty · [source site](https://api-docs.veracross.com/)

---


# List Staff/Faculty


## GET `/staff_faculty`


List Staff/Faculty


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer |  | Household ID |
| `faculty_type` | integer |  | Faculty Type |
| `employee_code` | integer |  | Employee Code |
| `campus` | integer |  | Campus |
| `role` | integer |  | Role |
| `on_or_before_date_hired` | string |  | Date Hired |
| `on_or_after_date_hired` | string |  | Date Hired |
| `on_or_before_date_terminated` | string |  | Date Terminated |
| `on_or_after_date_terminated` | string |  | Date Terminated |
| `school_level` | integer |  | School Level  Determined by the person&#39;s school level classification as set on their Classification tab. |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `name_prefix` | integer | yes | Name Prefix |
| `name_suffix` | integer | yes | Name Suffix |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `household_id` | integer <small>read-only</small> | yes | Household ID |
| `gender` | integer | yes | Gender |
| `faculty_type` | integer | yes | Faculty Type |
| `department` | integer | yes | Primary Department |
| `departments` | string <small>read-only</small> | yes | Departments (Long)  Shows the full name of each department. Based on person classification data and so can show multiple departments. |
| `school_levels` | string <small>read-only</small> | yes | School Levels (Long)  Will pull all active school level person classifications into a comma separated list. (note that active is not the same as Primary, the Active field can be pulled into a person classification query) |
| `job_title` | string <small>max 100</small> | yes | Job Title |
| `employee_code` | integer | yes | Employee Code |
| `date_hired` | string | yes | Date Hired |
| `date_terminated` | string | yes | Date Terminated |
| `campus` | integer | yes | Campus |
| `roles` | string <small>read-only</small> | yes | Staff/Faculty Roles  A list of all staff/faculty roles specified for this person. |
| `email_1` | string <small>max 100</small> | yes | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `username` | string <small>max 128</small> | yes | Username |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
