> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Person Accounts / Read Person Accounts · [source site](https://api-docs.veracross.com/)

---


# Read Person Accounts


## GET `/person_accounts/{id}`


Read Person Accounts


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID  A person record must exist before creating a user account for the person record. |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID  A person record must exist before creating a user account for the person record. |
| `username` | string <small>max 128</small> | yes | Username |
| `external_username` | string <small>max 255</small> | yes | External Username  The username in your external login provider. If you are not using an external provider, leave blank and the system will generate a username for the user based on username configuration set up in Axiom. |
| `account_type` | integer | yes | Account Type |
| `primary_portal` | string <small>max 200</small> | yes | Primary Portal |
| `status` | integer | yes | Account Status  For Veracross accounts without associated external accounts. |
| `security_roles` | string <small>read-only</small> | yes | Security Roles |
| `last_login_date` | string <small>read-only</small> | yes | Last Login Date  The last time this user successfully logged in to Veracross (excludes impersonated logins). |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
