> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Events: Athletics / Update Events: Athletics · [source site](https://api-docs.veracross.com/)

---


# Update Events: Athletics


## PATCH `/events/athletics/{event_id}`


Update Events: Athletics


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `event_id` | integer | yes | Event ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Event ID |
| `event_type_id` | integer |  | Event Type |
| `event_type_description` | string <small>read-only</small> |  | Event Type Description |
| `description` | string <small>max 200</small> |  | Description |
| `school_level_id` | integer |  | School Level  The school level associated with this event.    Within the context of parent/teacher conferences, this field is used in conjunction with the Grade Level field to determine who is eligible to sign up for a conference. Example: if School Level = Upper School and Grade Level = Grade 8, any parent of a student in Upper School OR Grade 8 is eligible to sign up for the conference slot. |
| `school_level_description` | string <small>read-only</small> |  | School Level Description |
| `internal_team_id` | integer |  | Internal Group ID |
| `internal_class_id` | integer <small>read-only</small> |  | Internal Class ID |
| `team_description` | string <small>read-only</small> |  | Primary Group Name |
| `athletic_opponent` | string |  | Opponent |
| `game_type_id` | integer |  | Game Type |
| `game_type_description` | string <small>read-only</small> |  | Game Type Description |
| `home_away_id` | integer |  | Home/Away |
| `home_away_description` | string <small>read-only</small> |  | Home/Away Description |
| `out_of_conference` | boolean |  | Out Of Conference |
| `make_up` | boolean |  | Make-Up |
| `destination_organization` | string <small>read-only</small> |  | Destination Organization  The external Organization where this event will be located.  For athletic events, should only be specified if different from the Opponent field. |
| `destination_organization_id` | integer |  | Destination Organization ID  The external Organization where this event will be located.  For athletic events, should only be specified if different from the Opponent field. |
| `location` | string <small>read-only</small> |  | Internal Location Resource Description  The description of the internal resource for this event. |
| `depart_from` | string <small>max 50</small> |  | Depart From |
| `class_departure_time` | string <small>max 8</small> |  | Class Departure Time |
| `campus_departure_time` | string <small>max 8</small> |  | Campus Departure Time |
| `transportation_id` | integer |  | Transportation |
| `transportation_description` | string <small>read-only</small> |  | Transportation Description |
| `transportation_resource` | string <small>read-only</small> |  | Transportation Resource |
| `transportation_resource_id` | integer |  | Transportation Resource ID |
| `google_map` | string <small>read-only</small> |  | Map |
| `google_directions_from_school` | string <small>read-only</small> |  | Directions from School |
| `event_status_id` | integer |  | Event Status |
| `event_status_description` | string <small>read-only</small> |  | Event Status Description |
| `start_date` | string |  | Start Date |
| `end_date` | string <small>max 10</small> |  | End Date |
| `start_time` | string <small>max 8</small> |  | Start Time |
| `end_time` | string <small>max 8</small> |  | End Time |
| `venue_departure_time` | string <small>max 8</small> |  | Venue Departure Time |
| `campus_return_time` | string <small>max 8</small> |  | Campus Return Time |
| `notes` | string <small>max 1000</small> |  | Notes |
| `game_outcome_id` | integer |  | Game Outcome |
| `game_outcome_description` | string <small>read-only</small> |  | Game Outcome Description |
| `game_score_us` | number |  | Score - Us |
| `game_score_opponent` | number |  | Score - Opponent |
| `placement_id` | integer |  | Game Placement |
| `placement_description` | string <small>read-only</small> |  | Game Placement Description |
| `overtime` | boolean |  | Overtime |
| `summary` | string <small>max 1500</small> |  | Summary |
| `update_date` | string |  | Update Date |
| `public` | boolean |  | Display On Public Calendar |
| `series_template` | boolean |  | Series Master Event  If selected, individual events will be created for each day that the event takes place |
| `daily_attendance_status` | integer |  | Daily Attendance Status  The daily attendance status that will be used for students who participate in this event. This value will be applied to daily attendance for all the students affected by this event. Leaving this value set as &quot;none specified&quot; will leave the daily attendance status as &quot;Present&quot; for all the students. |
| `class_attendance_status` | integer |  | Class Attendance Status  The class attendance status that will be used for students who participate in this event. This value will be applied to class attendance for all the classes affected by this event between Class Departure Time and Campus Return Time. |
| `attendance_taken` | integer |  | Attendance Taken |
| `display_on_parent_calendar` | boolean |  | Display On Parent Calendar |
| `display_on_student_calendar` | boolean |  | Display On Student Calendar |
| `display_on_staff_faculty_calendar` | boolean |  | Display On Staff/Faculty Calendar |
| `display_on_alumni_calendar` | boolean |  | Display On Alumni Calendar |
| `display_on_group_members_calendar` | boolean |  | Display On Group Members Calendar |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
