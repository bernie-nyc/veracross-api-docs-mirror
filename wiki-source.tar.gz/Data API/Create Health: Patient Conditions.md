> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Health: Patient Conditions / Create Health: Patient Conditions · [source site](https://api-docs.veracross.com/)

---


# Create Health: Patient Conditions


## POST `/health/patients/{patient_id}/conditions`


Create Health: Patient Conditions


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `patient_id` | string | yes | Patient |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Medical History ID |
| `description` | string <small>max 50</small> | yes | Description |
| `patient_id` | string <small>read-only</small> |  | Patient |
| `condition_code` | integer | yes | Condition Code |
| `new_condition_code_description` | string <small>max 50</small> | yes | Condition Code Description  When present during update, creates a new condition code with the specified description. |
| `intervention_code` | integer | yes | Intervention Code |
| `new_intervention_code_description` | string <small>max 50</small> | yes | Intervention Code Description  When present during update, creates a new intervention code with the specified description. |
| `begin_date` | string |  | Begin Date |
| `end_date` | string |  | End Date |
| `notes` | string <small>max 2000</small> |  | Notes |
| `critical` | boolean | yes | Critical |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
