> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Classes / Create Academics: Classes · [source site](https://api-docs.veracross.com/)

---


# Create Academics: Classes


## POST `/academics/classes`


Create Academics: Classes


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Internal Class ID |
| `class_id` | string <small>max 20</small> | yes | Class ID  Class ID associated with this class. School-defined value. Must be unique in the school year. Special characters, punctuation, and spaces are not sufficient for uniqueness.     Example: GYM 1 and GYM: 1 are not unique. GYM 1a and GYM 1b are unique. |
| `description` | string <small>max 80</small> | yes | Description |
| `status` | integer |  | Status  Status of the class (active, future, etc.) |
| `school_year` | integer |  | School Year |
| `begin_date` | string |  | Begin Date |
| `end_date` | string |  | End Date |
| `primary_grade_level_id` | integer |  | Primary Grade Level ID |
| `school_level` | integer |  | School Level |
| `internal_course_id` | integer | yes | Course ID |
| `primary_teacher_id` | integer |  | Teacher ID |
| `room_id` | integer |  | Room ID |
| `virtual_meeting_url` | string <small>max 2000</small> |  | Virtual Meeting URL  To toggle the display of this field in the daily student/faculty schedule, update the configuration on the Website Configuration tab. |
| `subject_id` | integer | yes | Subject |
| `department_id` | integer <small>read-only</small> |  | ID |
| `internal_group_id` | integer |  | System Group ID |
| `parent_portal_visibility` | integer |  | Parent Portal Visibility  Indicates whether this class will display on the Parent Portal |
| `parent_portal_assignment_display` | integer |  | Parent Portal Assignment Display  Indicates whether assigments and assignment grades display on the Parent Portal |
| `student_portal_visibility` | integer |  | Student Portal Visibility  Indicates whether this class will display on the Student Portal |
| `student_portal_assignment_display` | integer |  | Student Portal Assignment Display  Indicates whether assigments and assignment grades display on the Student Portal |
| `track_class_attendance` | boolean |  | Track Class Attendance  Indicates whether to maintain Class-level attendance for this class in addition to Daily attendance |
| `trigger_imperfect_attendance` | boolean |  | Trigger Imperfect Attendance  When selected, if a student&#39;s attendance status for this class is in conflict with their daily attendance status, the Daily Attendance status will be updated to &quot;Imperfect Class Attendance&quot;. The most common reason to deselect this field is if this class is an after school activity or athletic team whose attendance isn&#39;t relevant to Daily Attendance. (This option only matters if &quot;Track Attendance&quot; is selected.) |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
