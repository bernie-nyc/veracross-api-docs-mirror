> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Health: Patient Medications / List Health: Patient Medications · [source site](https://api-docs.veracross.com/)

---


# List Health: Patient Medications


## GET `/health/patients/{patient_id}/medications`


List Health: Patient Medications


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `patient_id` | integer | yes | Patient ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `medication` | integer |  | Medication GKC |
| `on_or_before_start_date` | string |  | Start Date |
| `on_or_after_start_date` | string |  | Start Date |
| `on_or_before_end_date` | string |  | End Date |
| `on_or_after_end_date` | string |  | End Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person/Medication ID  The internal Veracross ID number for this record with information on a specific information for a particular person. |
| `patient_id` | integer | yes | Patient ID |
| `medication` | integer | yes | Medication GKC |
| `start_date` | string | yes | Start Date |
| `end_date` | string | yes | End Date |
| `dosage_instruction` | string <small>max 2000</small> | yes | Dosage Instruction |
| `notes` | string <small>max 2000</small> | yes | Notes |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
