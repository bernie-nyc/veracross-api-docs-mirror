> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Transportation: Trips / Read Transportation: Trips · [source site](https://api-docs.veracross.com/)

---


# Read Transportation: Trips


## GET `/transportation/trips/{id}`


Read Transportation: Trips


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Trip ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person Trip ID |
| `date` | string | yes | Trip Date |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `person_name` | string <small>read-only</small> | yes | Person |
| `person_preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `transportation_method` | integer | yes | Transportation Method |
| `normal_transportation_method` | integer | yes | Normal Transportation Method  The transportation method normally used on this day by this person |
| `origination` | integer | yes | Origination |
| `origination_address` | string <small>max 120</small> | yes | Origination Address |
| `destination` | integer | yes | Destination |
| `destination_address` | string <small>max 120</small> | yes | Destination Address |
| `bus_route_id` | integer | yes | Bus Route |
| `normal_bus_route_id` | integer | yes | Normal Bus Route  The bus route normally taken on this day by this person |
| `bus_stop_id` | integer | yes | Bus Stop ID |
| `normal_bus_stop_id` | integer | yes | Normal Bus Stop |
| `stop_number` | integer | yes | Stop # |
| `rider_status` | integer <small>read-only</small> | yes | Rider Status |
| `scheduled_departure_time` | string | yes | Scheduled Departure Time |
| `alternate_departure_time` | string | yes | Alternate Departure Time |
| `scheduled_arrival_time` | string | yes | Scheduled Arrival Time |
| `alternate_arrival_time` | string | yes | Alternate Arrival Time |
| `traveling_with` | string <small>read-only</small> | yes | Traveling With  The student listed above is riding with the student listed in this field. |
| `after_school_class` | string <small>read-only</small> | yes | After School Class |
| `attendance_status` | integer <small>read-only</small> | yes | Attendance Status  The attendance status for the student on this date |
| `attendance_notes` | string <small>read-only</small> | yes | Attendance Notes |
| `fee` | number | yes | Fee |
| `fee_paid` | boolean | yes | Fee Paid |
| `notes` | string <small>max 1000</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
