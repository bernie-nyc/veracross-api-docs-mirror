> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Relatives / Update Admission: Relatives · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Relatives


## PATCH `/admission/relatives/{id}`


Update Admission: Relatives


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer |  | Household ID |
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `name_prefix` | integer |  | Name Prefix |
| `first_name` | string <small>max 50</small> |  | First Name |
| `nick_name` | string <small>max 50</small> |  | Preferred Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> |  | Last Name |
| `name_suffix` | integer |  | Name Suffix |
| `maiden_name` | string <small>max 50</small> |  | Maiden Name |
| `marital_status` | integer |  | Marital Status  This field is automatically populated if there is a separate record in the database for this person&#39;s spouse, and a relationship record. |
| `gender` | integer |  | Gender |
| `pronouns` | integer |  | Pronouns |
| `ethnicity` | integer |  | Ethnicity (deprecated)  Information on handling Special Category data is available at https://www.veracross.com/privacy-policy |
| `date_of_birth` | string |  | Birthday  Birthday in MMM DD YYYY format |
| `place_of_birth` | string <small>max 50</small> |  | Place of Birth |
| `date_of_death` | string |  | Date of Death |
| `email` | string <small>max 100</small> |  | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `mobile_phone` | string <small>max 30</small> |  | Mobile Phone |
| `work_phone` | string <small>max 30</small> |  | Business Phone |
| `graduation_year` | integer |  | Graduation Year |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
