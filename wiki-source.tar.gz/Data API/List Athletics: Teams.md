> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Athletics: Teams / List Athletics: Teams · [source site](https://api-docs.veracross.com/)

---


# List Athletics: Teams


## GET `/athletics/teams`


List Athletics: Teams


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_level` | integer |  | School Level |
| `campus_id` | integer |  | Campus |
| `internal_sport_id` | integer |  | Sport ID |
| `head_coach_id` | integer |  | Coach ID |
| `school_year` | integer |  | School Year |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer <small>read-only</small> | yes | Internal Class ID |
| `school_level` | integer | yes | School Level |
| `campus_id` | integer | yes | Campus |
| `internal_sport_id` | integer | yes | Sport ID |
| `team_id` | string <small>max 20</small> | yes | Team ID |
| `description` | string <small>max 80</small> | yes | Description |
| `sport_id` | integer | yes | Sport |
| `head_coach_id` | integer | yes | Coach ID |
| `assistant_coach_id` | integer | yes | Assistant Coach ID |
| `begin_date` | string | yes | Begin Date |
| `end_date` | string | yes | End Date |
| `overall_record` | string <small>read-only</small> | yes | Overall Record |
| `internal_team_id` | integer | yes | System Group ID |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
