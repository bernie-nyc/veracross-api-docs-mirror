> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Students / List Students · [source site](https://api-docs.veracross.com/)

---


# List Students


## GET `/students`


List Students


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer |  | Household ID |
| `homeroom` | integer |  | Homeroom |
| `homeroom_teacher_id` | integer |  | Homeroom Teacher ID |
| `advisor_id` | integer |  | Advisor ID |
| `campus_id` | integer |  | Campus |
| `role` | integer |  | Role |
| `on_or_after_last_modified_date` | string |  | Last Modified Date |
| `on_or_before_last_modified_date` | string |  | Last Modified Date |
| `on_or_before_entry_date` | string |  | Entry Date  This is the original date on which the student started school. Should be the first day of the school year for new students, or a date during the school year for mid-year enrollees. |
| `on_or_after_entry_date` | string |  | Entry Date  This is the original date on which the student started school. Should be the first day of the school year for new students, or a date during the school year for mid-year enrollees. |
| `on_or_before_exit_date` | string |  | Exit Date  The last day the student was in school. Should be either the last day of the school year, or last day the student was in class. |
| `on_or_after_exit_date` | string |  | Exit Date  The last day the student was in school. Should be either the last day of the school year, or last day the student was in class. |
| `enrollment_status` | integer |  | Enrollment Status |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `household_id` | integer <small>read-only</small> | yes | Household ID |
| `gender` | integer | yes | Gender |
| `email_1` | string <small>max 100</small> | yes | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `grade_level` | integer | yes | Current Grade |
| `school_level` | integer | yes | School Level  Used for both Students &amp; Staff/Faculty  Definitions:  Students: defined based on the current grade level  Staff/Faculty: based on primary school level field  Note: Not typically used for Parents |
| `graduation_year` | integer | yes | Graduation Year |
| `homeroom` | integer | yes | Homeroom |
| `homeroom_teacher` | object | yes |  |
| `advisor` | object | yes |  |
| `campus` | object | yes |  |
| `username` | string <small>max 128</small> | yes | Username |
| `entry_date` | string | yes | Entry Date  This is the original date on which the student started school. Should be the first day of the school year for new students, or a date during the school year for mid-year enrollees. |
| `exit_date` | string | yes | Exit Date  The last day the student was in school. Should be either the last day of the school year, or last day the student was in class. |
| `birthday` | string | yes | Birthday  If staff/faculty, year is suppressed |
| `roles` | string <small>read-only</small> | yes | Roles  A list of all roles specified for this person.  Roles define this person&#39;s relationship to the school.  Can include &quot;virtual&quot; roles such as &quot;Relative of Alum&quot;. |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `enrollment_status` | integer <small>read-only</small> | yes | Enrollment Status |
| `house` | object <small>read-only</small> | yes |  |
| `student_group` | integer | yes | Student Group |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
