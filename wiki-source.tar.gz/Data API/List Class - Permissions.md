> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Class - Permissions / List Class - Permissions · [source site](https://api-docs.veracross.com/)

---


# List Class - Permissions


## GET `/class_permissions/`


List Class - Permissions


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer |  | Class Permission ID |
| `school_year` | integer |  | School Year |
| `internal_course_id` | integer |  | Internal Course ID |
| `internal_class_id` | integer |  | Internal Class ID |
| `person_id` | integer |  | Person ID |
| `role` | integer |  | Role |
| `update_grades` | boolean |  | Update Grades |
| `view_all_student_grades` | boolean |  | View All Student Grades |
| `view_attendance` | boolean |  | View Attendance  Determines if the teacher can view and take attendance for the students in this class |
| `update_attendance` | boolean |  | Track Attendance  Determines whether attendance records are created for this teacher/coach/etc. |
| `view_behavior` | boolean |  | View Behavior |
| `view_grades` | boolean |  | View Grades |
| `view_progress_report` | boolean |  | View Progress Report |
| `view_report_card` | boolean |  | View Report Card |
| `course_type_exclude` | integer |  | Course Type |
| `course_type_include` | integer |  | Course Type |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Class Permission ID |
| `school_year` | integer | yes | School Year |
| `course_type` | integer | yes | Course Type |
| `internal_course_id` | integer <small>read-only</small> | yes | Internal Course ID |
| `course_id` | string <small>max 15</small> | yes | Course ID |
| `course_description` | string <small>max 100</small> | yes | Course Name |
| `internal_class_id` | integer <small>read-only</small> | yes | Internal Class ID |
| `class_id` | string <small>max 20</small> | yes | Class ID  Class ID associated with this class. School-defined value. Must be unique in the school year. Special characters, punctuation, and spaces are not sufficient for uniqueness.     Example: GYM 1 and GYM: 1 are not unique. GYM 1a and GYM 1b are unique. |
| `class_description` | string <small>max 80</small> | yes | Description |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `role` | integer | yes | Role |
| `title` | string <small>max 255</small> | yes | Title |
| `update_grades` | boolean | yes | Update Grades |
| `view_all_student_grades` | boolean | yes | View All Student Grades |
| `view_attendance` | boolean | yes | View Attendance  Determines if the teacher can view and take attendance for the students in this class |
| `update_attendance` | boolean | yes | Track Attendance  Determines whether attendance records are created for this teacher/coach/etc. |
| `view_behavior` | boolean | yes | View Behavior |
| `view_grades` | boolean | yes | View Grades |
| `view_progress_report` | boolean | yes | View Progress Report |
| `view_report_card` | boolean | yes | View Report Card |
| `teacher_portal_visibility` | integer | yes | Teacher Portal Visibility  Set this to Hide to hide the class from the teacher&#39;s daily schedule in the portal. |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
