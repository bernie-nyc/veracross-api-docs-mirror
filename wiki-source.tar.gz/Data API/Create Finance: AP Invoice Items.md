> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Finance: AP Invoice Items / Create Finance: AP Invoice Items · [source site](https://api-docs.veracross.com/)

---


# Create Finance: AP Invoice Items


## POST `/finance/ap_invoices/{invoice_id}/ap_invoice_items`


Create Finance: AP Invoice Items


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | integer | yes | AP Invoice Header ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_item_id` | integer <small>read-only</small> |  | AP Item ID |
| `ap_invoice_header_id` | integer |  | AP Invoice Header ID |
| `invoice_date` | string |  | Invoice Date  Item date is almost always the same as the invoice date , except in cases of adjustment items. |
| `quantity` | number |  | Quantity |
| `unit_cost` | number |  | Unit Cost |
| `amount` | number |  | Amount |
| `dr_gl_account` | string <small>read-only</small> |  | DR GL Account |
| `project_id` | string <small>read-only</small> |  | Project # |
| `ap_description` | string <small>max 200</small> |  | AP Description |
| `tax_amount` | number |  | Tax Amount |
| `tax_type` | string |  | Tax Rate  By specifying a Tax Type here, GST will be posted to the General Ledger and recorded on the BAS. |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
