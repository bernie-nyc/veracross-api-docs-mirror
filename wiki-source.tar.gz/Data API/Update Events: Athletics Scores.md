> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Events: Athletics Scores / Update Events: Athletics Scores · [source site](https://api-docs.veracross.com/)

---


# Update Events: Athletics Scores


## PATCH `/events/athletics_scores/{id}`


Update Events: Athletics Scores


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Event ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Event ID |
| `event_type_description` | string <small>max 50</small> |  | Description |
| `description` | string <small>max 200</small> |  | Description  A text field that contains a description of the event.    Within the context of parent/teacher conferences, this “Admin Description” can be used for internal workflows like denoting teacher breaks modeled as conference slots. The Admin Description is visible on the conference schedule document for teachers. |
| `date` | string |  | Start Date |
| `game_outcome_id` | integer |  | Game Outcome |
| `game_score_us` | number |  | Score - Us |
| `game_score_opponent` | number |  | Score - Opponent |
| `placement_id` | integer |  | Game Placement |
| `overtime` | boolean |  | Overtime |
| `summary` | string <small>max 1500</small> |  | Summary |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
