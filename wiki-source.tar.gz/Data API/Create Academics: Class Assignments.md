> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Class Assignments / Create Academics: Class Assignments · [source site](https://api-docs.veracross.com/)

---


# Create Academics: Class Assignments


## POST `/academics/classes/{internal_class_id}/assignments`


Create Academics: Class Assignments


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Class Assignment ID |
| `internal_class_id` | integer | yes | Internal Class ID |
| `assignment_type` | integer | yes | Assignment Type  The type of assignment: for ex. Homework, Quiz, Exam, etc. |
| `description` | string <small>max 256</small> |  | Description |
| `assignment_details` | string |  | Notes |
| `max_score` | integer |  | Maximum Score  The maximum possible score for this assignment |
| `weight` | integer |  | Weight (Pts)  The weight for this assignment |
| `not_to_be_graded` | boolean |  | Not to be Graded  If selected, this assignment will not factor into the students&#39; grades.  Any grades that are entered will NOT count towards the final grades. |
| `date_assigned` | string |  | Date Assigned  The date on which this assignment was assigned |
| `date_due` | string |  | Due Date  The date this assignment is due |
| `display_status` | integer |  | Display Status |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
