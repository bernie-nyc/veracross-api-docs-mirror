> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Athletics: Team Practice Schedules / List Athletics: Team Practice Schedules · [source site](https://api-docs.veracross.com/)

---


# List Athletics: Team Practice Schedules


## GET `/athletics/team/{id}/practice_schedules`


List Athletics: Team Practice Schedules


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Internal Class ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `on_or_before_start_date` | string |  | Start Date |
| `on_or_after_start_date` | string |  | Start Date |
| `on_or_before_end_date` | string |  | End Date |
| `on_or_after_end_date` | string |  | End Date |
| `on_or_before_start_time` | string |  | Start Time |
| `on_or_after_start_time` | string |  | Start Time |
| `on_or_before_end_time` | string |  | End Time |
| `on_or_after_end_time` | string |  | End Time |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Internal Class ID |
| `event_id` | integer | yes | Event ID |
| `description` | string <small>max 500</small> | yes | Description |
| `event_type` | integer | yes | Event Type |
| `resource_id` | integer | yes | Resource ID |
| `location` | string <small>max 255</small> | yes | Location |
| `start_date` | string | yes | Start Date |
| `end_date` | string | yes | End Date |
| `start_time` | string | yes | Start Time |
| `end_time` | string | yes | End Time |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
