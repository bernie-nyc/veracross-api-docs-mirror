> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Households / Update Admission: Households · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Households


## PATCH `/admission/households/{id}`


Update Admission: Households


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Household ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Household ID |
| `name` | string <small>max 50</small> |  | Name |
| `address_1` | string <small>max 200</small> |  | Address 1 A |
| `address_2` | string <small>max 200</small> |  | Address 2 A |
| `address_3` | string <small>max 200</small> |  | Address 3 A |
| `city` | string <small>max 50</small> |  | City A |
| `county` | string <small>max 50</small> |  | County |
| `subdivision` | string <small>max 50</small> |  | Subdivision |
| `state` | string <small>max 50</small> |  | State A |
| `postal_code` | string <small>max 20</small> |  | Postal Code A |
| `country` | integer |  | Country A |
| `phone` | string <small>max 30</small> |  | Phone  Will be copied to the household members&#39; Home Phone fields overnight if (a) the member is a student or (b) the member&#39;s Home Phone is not already populated. |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
