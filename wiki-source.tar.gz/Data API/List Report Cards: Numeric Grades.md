> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Report Cards: Numeric Grades / List Report Cards: Numeric Grades · [source site](https://api-docs.veracross.com/)

---


# List Report Cards: Numeric Grades


## GET `/report_card/enrollments/{enrollment_id}/numeric_grades`


List Report Cards: Numeric Grades


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `enrollment_id` | integer | yes | Enrollment ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Grade ID |
| `grading_period` | object | yes |  |
| `assignment_posted_grade` | number | yes | Assignment Posted Grade |
| `assignment_posted_letter_grade` | string <small>read-only</small> | yes | Assignment Posted Grade (Letter) |
| `exam_grade` | number | yes | Exam Grade |
| `posted_grade` | number | yes | Grade: Posted  The official posted grade that appears on the report card |
| `posted_letter_grade` | string <small>read-only</small> | yes | Letter Grade  The letter grade equivalent of the posted numeric grade (Grade: P); if grades have not been posted, this will be the letter grade equivalent of the calculated grade (Grade: C) |
| `status` | integer | yes | Status  The status for this report-card record |
| `other_grade_1` | object | yes |  |
| `other_grade_2` | object | yes |  |
| `comments` | string | yes | Comments |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
