> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Report Cards: Class Attendance / List Report Cards: Class Attendance · [source site](https://api-docs.veracross.com/)

---


# List Report Cards: Class Attendance


## GET `/report_card/enrollments/{enrollment_id}/attendance`


List Report Cards: Class Attendance


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `enrollment_id` | integer | yes | Class Person ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_year` | integer |  | School Year |
| `grading_period` | integer |  | Grading Period ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `enrollment_id` | integer <small>read-only</small> | yes | Class Person ID |
| `school_year` | integer | yes | School Year |
| `person_id` | integer | yes | Person ID |
| `class_id` | integer | yes | Class ID |
| `grading_period_id` | integer | yes | Grading Period ID |
| `absences_all` | number | yes | Absences All |
| `absences_excused` | number | yes | Absences Excused |
| `absences_unexcused` | number | yes | Absences Unexcused |
| `tardies_all` | number | yes | Tardies All |
| `tardies_excused` | number | yes | Tardies Excused |
| `tardies_unexcused` | number | yes | Tardies Unexcused |
| `dismissals_all` | number | yes | Dismissals All |
| `dismissals_excused` | number | yes | Dismissals Excused |
| `dismissals_unexcused` | number | yes | Dismissals Unexcused |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
