> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Directory: Household / List Directory: Household · [source site](https://api-docs.veracross.com/)

---


# List Directory: Household


## GET `/directory/household`


List Directory: Household


The List Directory: Household endpoint mirrors the information shown for directory entries in the general Household directory in the portals. Information is automatically refreshed nightly or by manually running the "Refresh Directory Entries" action item on the directory.


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `first_name` | string |  | First Name Filter |
| `last_name` | string |  | Last Name Filter |
| `names` | string |  | Name Filter |
| `household_location` | string |  | Household Location Filter |
| `household_city` | string |  | Household City Filter |
| `household_postal_code` | string |  | Household Postal Code Filter |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer | yes | Household ID |
| `entry_sort_name` | string <small>max 500</small> | yes | Entry Sort Name |
| `name` | string <small>max 50</small> | yes | Household Name |
| `phone` | string <small>max 50</small> | yes | Household Phone |
| `address` | string <small>max 1000</small> | yes | Household Address |
| `household_google_maps_url` | string <small>max 1000</small> | yes | Household Google Maps Url |
| `person_1_id` | integer | yes | Hoh ID |
| `person_1_full_name` | string <small>max 500</small> | yes | Hoh Full Name |
| `person_1_email` | string <small>max 100</small> | yes | Hoh Email |
| `person_1_email_2` | string <small>max 100</small> | yes | Hoh Email 2 |
| `person_1_phone_mobile` | string <small>max 50</small> | yes | Hoh Phone Mobile |
| `person_1_phone_business` | string <small>max 50</small> | yes | Hoh Phone Business |
| `person_2_id` | integer | yes | Spouse ID |
| `person_2_full_name` | string <small>max 500</small> | yes | Spouse Full Name |
| `person_2_email` | string <small>max 100</small> | yes | Spouse Email |
| `person_2_email_2` | string <small>max 100</small> | yes | Spouse Email 2 |
| `person_2_phone_mobile` | string <small>max 50</small> | yes | Spouse Phone Mobile |
| `person_2_phone_business` | string <small>max 50</small> | yes | Spouse Phone Business |
| `related_students` | string <small>max 1500</small> | yes | Related Students |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
