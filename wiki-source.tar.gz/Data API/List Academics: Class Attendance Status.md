> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Class Attendance Status / List Academics: Class Attendance Status · [source site](https://api-docs.veracross.com/)

---


# List Academics: Class Attendance Status


## GET `/academics/class_attendance_statuses`


List Academics: Class Attendance Status


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer |  | Internal Class ID |
| `date` | string |  | Attendance Date  Attendance Date for the class attendance status history record |
| `takes_daily_attendance_today` | boolean |  | Takes Daily Attendance on Date |
| `attendance_status` | integer |  | Attendance Status |
| `campus_id` | integer |  | Campus ID |
| `school_level` | integer |  | School Level |
| `course_type` | integer |  | Course Type |
| `internal_course_id` | integer |  | Internal Course ID |
| `teacher_id` | integer |  | Person ID |
| `course_type_not` | integer |  | Course Type |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Class Attendance Status History ID |
| `internal_class_id` | integer <small>read-only</small> | yes | Internal Class ID |
| `date` | string | yes | Attendance Date  Attendance Date for the class attendance status history record |
| `takes_daily_attendance_today` | boolean <small>read-only</small> | yes | Takes Daily Attendance on Date |
| `attendance_status` | integer | yes | Attendance Status |
| `class` | object | yes |  |
| `teacher_id` | integer <small>read-only</small> | yes | Person ID |
| `teacher_name` | string <small>read-only</small> | yes | Full Name  The full name of an individual in the school-defined format, often &lt;last name&gt;, &lt;first name&gt; |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
