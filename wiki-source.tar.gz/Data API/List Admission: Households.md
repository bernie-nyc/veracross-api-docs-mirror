> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Households / List Admission: Households · [source site](https://api-docs.veracross.com/)

---


# List Admission: Households


## GET `/admission/households`


List Admission: Households


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `name` | string |  | Name |
| `address_1` | string |  | Address 1 A |
| `address_2` | string |  | Address 2 A |
| `address_3` | string |  | Address 3 A |
| `city` | string |  | City A |
| `state` | string |  | State A |
| `postal_code` | string |  | Postal Code A |
| `country` | integer |  | Country A |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Household ID |
| `name` | string <small>max 50</small> | yes | Name |
| `address_1` | string <small>max 200</small> | yes | Address 1 A |
| `address_2` | string <small>max 200</small> | yes | Address 2 A |
| `address_3` | string <small>max 200</small> | yes | Address 3 A |
| `city` | string <small>max 50</small> | yes | City A |
| `county` | string <small>max 50</small> | yes | County |
| `subdivision` | string <small>max 50</small> | yes | Subdivision |
| `state` | string <small>max 50</small> | yes | State A |
| `postal_code` | string <small>max 20</small> | yes | Postal Code A |
| `country` | integer | yes | Country A |
| `phone` | string <small>max 30</small> | yes | Phone  Will be copied to the household members&#39; Home Phone fields overnight if (a) the member is a student or (b) the member&#39;s Home Phone is not already populated. |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
