> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Numeric Grades / List Academics: Numeric Grades · [source site](https://api-docs.veracross.com/)

---


# List Academics: Numeric Grades


## GET `/academics/numeric_grades`


List Academics: Numeric Grades


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `enrollment_id` | integer |  | Enrollment ID |
| `class_id` | integer |  | Internal Class ID |
| `grading_period_id` | integer |  | ID |
| `student_id` | integer |  | Person ID |
| `locked` | boolean |  | Locked  Indicates that the data for this record are locked, and only authorized users can make changes |
| `school_year` | integer |  | School Year |
| `last_modified_date` | string |  | Last Modified Date |
| `on_or_before_last_modified_date` | string |  | Last Modified Date |
| `on_or_after_last_modified_date` | string |  | Last Modified Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Grade ID |
| `enrollment_id` | integer | yes | Enrollment ID |
| `class` | object <small>read-only</small> | yes |  |
| `grading_period` | object | yes |  |
| `student` | object <small>read-only</small> | yes |  |
| `assignment_posted_grade` | number | yes | Assignment Posted Grade |
| `assignment_posted_letter_grade` | string <small>read-only</small> | yes | Assignment Posted Grade (Letter) |
| `exam_grade` | number | yes | Exam Grade |
| `posted_grade` | number | yes | Grade: Posted  The official posted grade that appears on the report card |
| `posted_letter_grade` | string <small>read-only</small> | yes | Letter Grade (P)  The letter grade equivalent of the posted numeric grade (Grade: P) |
| `status` | integer | yes | Status  The status for this report-card record |
| `comment` | string | yes | Comments |
| `locked` | boolean | yes | Locked  Indicates that the data for this record are locked, and only authorized users can make changes |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
