> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Standardized Tests: Scores / Read Standardized Tests: Scores · [source site](https://api-docs.veracross.com/)

---


# Read Standardized Tests: Scores


## GET `/standardized_tests/scores/{id}`


Read Standardized Tests: Scores


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Standardized Test Score ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person Standardized Test Score ID |
| `person_test_id` | integer | yes | Person Standardized Test |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `test_type` | integer | yes | Test Type |
| `test_type_description` | string <small>max 50</small> <small>read-only</small> | yes | Description (read-only) |
| `test_year` | integer | yes | Test Year  The year the test was taken, entered manually if the exact date is not known. |
| `test_date` | string | yes | Test Date  The date the test was taken |
| `score_type` | integer | yes | Score Type  E.g. English, Math, Writing |
| `score_type_description` | string <small>max 50</small> | yes | Description |
| `score` | string <small>max 20</small> | yes | Score |
| `is_primary_score` | boolean | yes | Primary Score |
| `is_secondary_score` | boolean | yes | Secondary Score |
| `is_tertiary_score` | boolean | yes | Tertiary Score |
| `created_date` | string | yes | Input Date |
| `last_modified_date` | string | yes | Update Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
