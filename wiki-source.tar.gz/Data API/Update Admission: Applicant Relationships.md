> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Applicant Relationships / Update Admission: Applicant Relationships · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Applicant Relationships


## PATCH `/admission/applicants/{applicant_id}/relationships/{id}`


Update Admission: Applicant Relationships


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Person ID |
| `applicant_id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Person ID |
| `related_person_id` | integer |  | Related Person ID |
| `relationship` | integer |  | Relationship  When background shading is available:  Orange: Immediate family, e.g. Husband, Wife, Father, Mother, Brother, Sister, Sibling, Domestic Partner  Yellow: Secondary family, e.g. Grandparents, Aunt/Uncle, Cousin  Manilla: In-Laws, Exes, Step-child, Step-parent, deceased spouse  Gray-Blue: &quot;Unspecified&quot; and &quot;Other&quot;  White: All others |
| `legal_custody` | boolean |  | Legal Custody  Indicates that the parent has legal custody of the child |
| `admissions_access` | boolean |  | Admissions Access  Gives this person admission portal access, regardless of legal custody settings |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
