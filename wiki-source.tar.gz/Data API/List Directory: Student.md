> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Directory: Student / List Directory: Student · [source site](https://api-docs.veracross.com/)

---


# List Directory: Student


## GET `/directory/student`


List Directory: Student


The List Directory: Student endpoint mirrors the information shown for directory entries in the general Student directory in the portals. Information is automatically refreshed nightly or by manually running the "Refresh Directory Entries" action item on the directory.


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `grade_level` | string |  | Student Grade Level |
| `student_group` | string |  | Student Group |
| `homeroom` | string |  | Student Homeroom |
| `school_level` | string |  | Student School Level |
| `campus` | string |  | Student Campus |
| `first_name` | string |  | First Name Filter  This filter will search based on first name and/or preferred name displayed for students and parents in the directory entries. How student and parent names are displayed is configured in the Student Directory configuration settings. |
| `last_name` | string |  | Last Name Filter |
| `names` | string |  | Name Filter |
| `household_location` | string |  | Household Location Filter |
| `household_city` | string |  | Household City Filter |
| `household_postal_code` | string |  | Household Postal Code Filter |
| `grade_level_id` | integer |  | Grade Level ID |
| `student_group_id` | integer |  | Student Group ID |
| `homeroom_id` | integer |  | Homeroom ID |
| `campus_id` | integer |  | Campus ID |
| `school_level_id` | integer |  | School Level ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `student_id` | string | yes | Student ID |
| `entry_sort_name` | string <small>max 500</small> | yes | Entry Sort Name |
| `full_name` | string <small>max 500</small> | yes | Student Full Name |
| `grade_level` | string <small>max 4000</small> | yes | Student Grade Level |
| `student_group` | string <small>max 4000</small> | yes | Student Group |
| `homeroom` | string <small>max 4000</small> | yes | Student Homeroom |
| `school_level` | string <small>max 4000</small> | yes | Student School Level |
| `campus` | string <small>max 4000</small> | yes | Student Campus |
| `email` | string <small>max 100</small> | yes | Student Email |
| `phone_mobile` | string <small>max 50</small> | yes | Student Phone Mobile |
| `household_1_id` | string | yes | Household 1 ID |
| `household_1_name` | string <small>max 50</small> | yes | Household 1 Name |
| `household_1_phone` | string <small>max 50</small> | yes | Household 1 Phone |
| `household_1_address` | string <small>max 1000</small> | yes | Household 1 Address |
| `household_1_google_maps_url` | string <small>max 1000</small> | yes | Household 1 Google Maps Url |
| `household_1_person_1_id` | string | yes | Household 1 Hoh ID |
| `household_1_person_1_full_name` | string <small>max 500</small> | yes | Household 1 Hoh Full Name |
| `household_1_person_1_email` | string <small>max 100</small> | yes | Household 1 Hoh Email |
| `household_1_person_1_email_2` | string <small>max 100</small> | yes | Household 1 Hoh Email 2 |
| `household_1_person_1_phone_mobile` | string <small>max 50</small> | yes | Household 1 Hoh Phone Mobile |
| `household_1_person_1_phone_business` | string <small>max 50</small> | yes | Household 1 Hoh Phone Business |
| `household_1_person_2_id` | string | yes | Household 1 Spouse ID |
| `household_1_person_2_full_name` | string <small>max 500</small> | yes | Household 1 Spouse Full Name |
| `household_1_person_2_email` | string <small>max 100</small> | yes | Household 1 Spouse Email |
| `household_1_person_2_email_2` | string <small>max 100</small> | yes | Household 1 Spouse Email 2 |
| `household_1_person_2_phone_mobile` | string <small>max 50</small> | yes | Household 1 Spouse Phone Mobile |
| `household_1_person_2_phone_business` | string <small>max 50</small> | yes | Household 1 Spouse Phone Business |
| `household_2_id` | string | yes | Household 2 ID |
| `household_2_name` | string <small>max 50</small> | yes | Household 2 Name |
| `household_2_phone` | string <small>max 50</small> | yes | Household 2 Phone |
| `household_2_address` | string <small>max 1000</small> | yes | Household 2 Address |
| `household_2_google_maps_url` | string <small>max 1000</small> | yes | Household 2 Google Maps Url |
| `household_2_person_1_id` | string | yes | Household 2 Hoh ID |
| `household_2_person_1_full_name` | string <small>max 500</small> | yes | Household 2 Hoh Full Name |
| `household_2_person_1_email` | string <small>max 100</small> | yes | Household 2 Hoh Email |
| `household_2_person_1_email_2` | string <small>max 100</small> | yes | Household 2 Hoh Email 2 |
| `household_2_person_1_phone_mobile` | string <small>max 50</small> | yes | Household 2 Hoh Phone Mobile |
| `household_2_person_1_phone_business` | string <small>max 50</small> | yes | Household 2 Hoh Phone Business |
| `household_2_person_2_id` | string | yes | Household 2 Spouse ID |
| `household_2_person_2_full_name` | string <small>max 500</small> | yes | Household 2 Spouse Full Name |
| `household_2_person_2_email` | string <small>max 100</small> | yes | Household 2 Spouse Email |
| `household_2_person_2_email_2` | string <small>max 100</small> | yes | Household 2 Spouse Email 2 |
| `household_2_person_2_phone_mobile` | string <small>max 50</small> | yes | Household 2 Spouse Phone Mobile |
| `household_2_person_2_phone_business` | string <small>max 50</small> | yes | Household 2 Spouse Phone Business |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
