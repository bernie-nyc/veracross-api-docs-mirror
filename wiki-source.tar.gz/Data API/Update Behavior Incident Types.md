> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Behavior Incident Types / Update Behavior Incident Types · [source site](https://api-docs.veracross.com/)

---


# Update Behavior Incident Types


## PATCH `/behavior_incident_types/{id}`


Update Behavior Incident Types


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | ID |
| `description` | string <small>max 75</small> |  | Description |
| `category` | integer |  | Category |
| `behavior_points` | number |  | Behavior Points |
| `allow_teacher_input` | boolean |  | Allow Teacher Input |
| `default_status` | integer |  | Default Status  If specified, the Behavior/Comment&#39;s status field will be set to this status after it is inserted. |
| `default_outcome` | integer |  | Default Outcome |
| `default_email_template` | integer |  | Default Email Template  The email template that will be used to notify parents and students.  Staff/Faculty will always get notified via the internal email template. Only email templates that have a Module of &#39;Behavior&#39; and are NOT flagged as System will appear in this list. |
| `default_internal_email_template` | integer |  | Default Internal Email Template  The email template that will be used to notify staff and faculty. Only email templates that have a Module of &#39;Behavior&#39; will appear in this list. |
| `reporting_person_notification` | integer |  | Reporting Person Notification |
| `assigned_to_person_notification` | integer |  | Assigned To Person Notification |
| `student_notification` | integer |  | Student Notification |
| `parent_notification` | integer |  | Parent Notification  Sends notification email to anyone with Legal Custody OR Portal Access |
| `advisor_notification` | integer |  | Advisor Notification |
| `homeroom_teacher_notification` | integer |  | Homeroom Teacher Notification |
| `teacher_notification` | integer |  | Teacher Notification  Student&#39;s teachers in active, Academic-type classes |
| `coach_notification` | integer |  | Coach Notification |
| `program_teacher_notification` | integer |  | Program Teacher Notification |
| `dorm_parent_notification` | integer |  | Dorm Parent Notification |
| `dorm_head_notification` | integer |  | Dorm Head Notification |
| `sort_key` | integer |  | Sort Key |
| `is_obsolete` | boolean |  | Obsolete |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
