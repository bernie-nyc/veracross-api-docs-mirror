> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: Vendors / Create Finance: Vendors · [source site](https://api-docs.veracross.com/)

---


# Create Finance: Vendors


## POST `/finance/vendors`


Create Finance: Vendors


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `vendor_id` | integer | yes | Vendor ID |
| `vendor_name` | string <small>max 200</small> |  | Vendor Name |
| `address_1` | string <small>max 200</small> |  | Address 1 |
| `address_2` | string <small>max 200</small> |  | Address 2 |
| `address_3` | string <small>max 200</small> |  | Address 3 |
| `city` | string <small>max 50</small> |  | City |
| `state_province` | string <small>max 50</small> |  | State Province |
| `postal_code` | string <small>max 20</small> |  | Postal Code |
| `country` | integer | yes | Country |
| `email` | string <small>max 100</small> |  | Email |
| `direct_deposit_account` | string <small>max 20</small> |  | Direct Deposit Account |
| `direct_deposit_bank` | string <small>max 20</small> |  | Direct Deposit Bank |
| `account_number` | string <small>max 75</small> |  | Account Number |
| `standard_days_to_pay` | integer |  | Standard Days To Pay |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |
| `inactive` | boolean | yes | Inactive |
| `vendor_tax_info` | string <small>read-only</small> |  | Vendor Tax Info |
| `federal_tax_id` | string <small>max 20</small> |  | Tax ID  Tax ID that is necessary for government reporting purposes. |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
