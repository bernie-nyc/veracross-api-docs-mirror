> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Attendance Status Codes / List Attendance Status Codes · [source site](https://api-docs.veracross.com/)

---


# List Attendance Status Codes


## GET `/attendance_status_codes`


List Attendance Status Codes


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `attendance_category` | integer |  | Attendance Category |
| `excused` | boolean |  | Excused |
| `allow_teacher_entry` | boolean |  | Allow Teacher Entry  Adjusts visibility of the status in the dropdown on the class attendance tab in the teacher portals. |
| `include_on_reports` | boolean |  | Include On Reports |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `description` | string <small>max 50</small> | yes | Description |
| `attendance_category` | integer | yes | Attendance Category |
| `excused` | boolean | yes | Excused |
| `allow_teacher_entry` | boolean | yes | Allow Teacher Entry  Adjusts visibility of the status in the dropdown on the class attendance tab in the teacher portals. |
| `include_on_reports` | boolean | yes | Include On Reports |
| `sort_key` | integer | yes | Sort Key |
| `keyboard_shortcut` | string <small>max 1</small> | yes | Keyboard Shortcut |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
