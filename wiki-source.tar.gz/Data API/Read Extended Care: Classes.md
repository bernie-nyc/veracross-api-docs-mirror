> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Extended Care: Classes / Read Extended Care: Classes · [source site](https://api-docs.veracross.com/)

---


# Read Extended Care: Classes


## GET `/extended_care/classes/{id}`


Read Extended Care: Classes


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Internal Class ID |
| `internal_course_id` | integer | yes | Course ID (Internal) |
| `class_id` | string <small>max 20</small> | yes | Class ID  Class ID associated with this class. School-defined value. Must be unique in the school year. Special characters, punctuation, and spaces are not sufficient for uniqueness.     Example: GYM 1 and GYM: 1 are not unique. GYM 1a and GYM 1b are unique. |
| `description` | string <small>max 80</small> | yes | Description |
| `status` | integer | yes | Status  Status of the class (active, future, etc.) |
| `school_year` | integer | yes | School Year |
| `begin_date` | string | yes | Begin Date |
| `end_date` | string | yes | End Date |
| `primary_grade_level_id` | integer | yes | Primary Grade Level ID |
| `school_level_id` | integer | yes | School Level |
| `primary_teacher_id` | integer | yes | Teacher ID |
| `room_id` | integer | yes | Room ID |
| `virtual_meeting_url` | string <small>max 2000</small> | yes | Virtual Meeting URL  To toggle the display of this field in the daily student/faculty schedule, update the configuration on the Website Configuration tab. |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
