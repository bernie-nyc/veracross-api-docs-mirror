> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Staff/Faculty / Update Staff/Faculty · [source site](https://api-docs.veracross.com/)

---


# Update Staff/Faculty


## PATCH `/staff_faculty/{id}`


Update Staff/Faculty


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person ID |
| `name_prefix` | integer |  | Name Prefix |
| `name_suffix` | integer |  | Name Suffix |
| `first_name` | string <small>max 50</small> |  | First Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> |  | Last Name |
| `preferred_name` | string <small>max 50</small> |  | Preferred Name |
| `household_id` | integer <small>read-only</small> |  | Household ID |
| `gender` | integer |  | Gender |
| `faculty_type` | integer |  | Faculty Type |
| `department` | integer |  | Primary Department |
| `departments` | string <small>read-only</small> |  | Departments (Long)  Shows the full name of each department. Based on person classification data and so can show multiple departments. |
| `school_levels` | string <small>read-only</small> |  | School Levels (Long)  Will pull all active school level person classifications into a comma separated list. (note that active is not the same as Primary, the Active field can be pulled into a person classification query) |
| `job_title` | string <small>max 100</small> |  | Job Title |
| `employee_code` | integer |  | Employee Code |
| `date_hired` | string |  | Date Hired |
| `date_terminated` | string |  | Date Terminated |
| `campus` | integer |  | Campus |
| `roles` | string <small>read-only</small> |  | Staff/Faculty Roles  A list of all staff/faculty roles specified for this person. |
| `email_1` | string <small>max 100</small> |  | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `username` | string <small>max 128</small> |  | Username |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
