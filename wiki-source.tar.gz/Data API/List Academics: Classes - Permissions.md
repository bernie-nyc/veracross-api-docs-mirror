> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Classes - Permissions / List Academics: Classes - Permissions · [source site](https://api-docs.veracross.com/)

---


# List Academics: Classes - Permissions


## GET `/academics/permissions`


List Academics: Classes - Permissions


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_year` | integer |  | School Year |
| `school_level` | integer |  | School Level |
| `course_id` | integer |  | Internal Course ID |
| `course_type` | integer |  | Course Type |
| `class_id` | integer |  | Internal Class ID |
| `person_id` | integer |  | Person ID |
| `course_type_not` | integer |  | Course Type |
| `last_modified_date` | string |  | Last Modified Date |
| `on_or_before_last_modified_date` | string |  | Last Modified Date |
| `on_or_after_last_modified_date` | string |  | Last Modified Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Class Permission ID |
| `school_year` | integer | yes | School Year |
| `school_level` | integer | yes | School Level |
| `course` | object | yes |  |
| `class` | object <small>read-only</small> | yes |  |
| `person` | object <small>read-only</small> | yes |  |
| `role` | integer | yes | Role |
| `title` | string <small>max 255</small> | yes | Title |
| `update_grades` | boolean | yes | Update Grades |
| `view_all_student_grades` | boolean | yes | View All Student Grades |
| `view_attendance` | boolean | yes | View Attendance  Determines if the teacher can view and take attendance for the students in this class |
| `update_attendance` | boolean | yes | Track Attendance  Determines whether attendance records are created for this teacher/coach/etc. |
| `view_behavior` | boolean | yes | View Behavior |
| `view_grades` | boolean | yes | View Grades |
| `view_progress_report` | boolean | yes | View Progress Report |
| `view_report_card` | boolean | yes | View Report Card |
| `show_in_teacher_portal` | boolean <small>read-only</small> | yes | Show In Teacher Portal? |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
