> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Students / Read Students · [source site](https://api-docs.veracross.com/)

---


# Read Students


## GET `/students/{id}`


Read Students


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `name_prefix` | integer | yes | Name Prefix |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `name_suffix` | integer | yes | Name Suffix |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `household_id` | integer <small>read-only</small> | yes | Household ID |
| `email_1` | string <small>max 100</small> | yes | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `birthday` | string | yes | Birthday  Birthday in MMM DD YYYY format |
| `gender` | integer | yes | Gender |
| `school_level` | integer | yes | School Level  Used for both Students &amp; Staff/Faculty  Definitions:  Students: defined based on the current grade level  Staff/Faculty: based on primary school level field  Note: Not typically used for Parents |
| `grade_level` | integer | yes | Current Grade |
| `graduation_year` | integer | yes | Graduation Year |
| `homeroom` | integer | yes | Homeroom |
| `homeroom_teacher` | object | yes |  |
| `advisor` | object | yes |  |
| `current_location` | string <small>read-only</small> | yes | Current Location  Where the student currently is |
| `campus` | integer | yes | Campus |
| `username` | string <small>max 128</small> | yes | Username |
| `entry_date` | string | yes | Entry Date  This is the original date on which the student started school. Should be the first day of the school year for new students, or a date during the school year for mid-year enrollees. |
| `exit_date` | string | yes | Exit Date  The last day the student was in school. Should be either the last day of the school year, or last day the student was in class. |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `enrollment_status` | integer <small>read-only</small> | yes | Enrollment Status |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
