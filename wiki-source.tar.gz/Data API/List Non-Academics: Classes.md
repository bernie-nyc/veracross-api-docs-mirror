> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Non-Academics: Classes / List Non-Academics: Classes · [source site](https://api-docs.veracross.com/)

---


# List Non-Academics: Classes


## GET `/non-academics/classes`


List Non-Academics: Classes


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer |  | Internal Class ID |
| `school_year` | integer |  | School Year |
| `campus_id` | integer |  | Campus ID |
| `school_level` | integer |  | School Level |
| `internal_course_id` | integer |  | Internal Course ID |
| `primary_teacher_id` | integer |  | Teacher ID |
| `room_id` | integer |  | Room ID |
| `internal_group_id` | integer |  | System Group ID |
| `parent_portal_visibility` | integer |  | Parent Portal Visibility  Indicates whether this class will display on the Parent Portal |
| `parent_portal_assignment_display` | integer |  | Parent Portal Assignment Display  Indicates whether assigments and assignment grades display on the Parent Portal |
| `student_portal_visibility` | integer |  | Student Portal Visibility  Indicates whether this class will display on the Student Portal |
| `student_portal_assignment_display` | integer |  | Student Portal Assignment Display  Indicates whether assigments and assignment grades display on the Student Portal |
| `last_modified_date` | string |  | Last Modified Date |
| `on_or_before_last_modified_date` | string |  | Last Modified Date |
| `on_or_after_last_modified_date` | string |  | Last Modified Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Internal Class ID |
| `class_id` | string <small>max 20</small> | yes | Class ID  Class ID associated with this class. School-defined value. Must be unique in the school year. Special characters, punctuation, and spaces are not sufficient for uniqueness.     Example: GYM 1 and GYM: 1 are not unique. GYM 1a and GYM 1b are unique. |
| `description` | string <small>max 80</small> | yes | Description |
| `status` | integer | yes | Status  Status of the class (active, future, etc.) |
| `school_year` | integer | yes | School Year |
| `campus_id` | integer | yes | Campus ID |
| `campus_description` | string <small>max 50</small> | yes | Description |
| `begin_date` | string | yes | Begin Date |
| `end_date` | string | yes | End Date |
| `primary_grade_level_id` | integer | yes | Primary Grade Level ID |
| `school_level` | integer | yes | School Level |
| `course_type` | integer | yes | Course Type |
| `internal_course_id` | integer <small>read-only</small> | yes | Internal Course ID |
| `course_id` | string <small>max 15</small> | yes | Course ID |
| `course_name` | string <small>max 100</small> | yes | Course Name |
| `primary_teacher_id` | integer | yes | Teacher ID |
| `primary_teacher_name` | string <small>read-only</small> | yes | Teacher |
| `room_id` | integer | yes | Room ID |
| `virtual_meeting_url` | string <small>max 2000</small> | yes | Virtual Meeting URL  To toggle the display of this field in the daily student/faculty schedule, update the configuration on the Website Configuration tab. |
| `subject_id` | integer | yes | Subject |
| `subject_description` | string <small>max 50</small> | yes | Description |
| `department_id` | integer <small>read-only</small> | yes | ID |
| `department_description` | string <small>max 100</small> | yes | Description |
| `internal_group_id` | integer | yes | System Group ID |
| `term_credit_hours` | number | yes | Term Credit Hours  The number of credit hours awarded per term.  Used to calculate GPA as well as determine credits earned values. |
| `total_credits` | number <small>read-only</small> | yes | Total Credits |
| `parent_portal_visibility` | integer | yes | Parent Portal Visibility  Indicates whether this class will display on the Parent Portal |
| `parent_portal_assignment_display` | integer | yes | Parent Portal Assignment Display  Indicates whether assigments and assignment grades display on the Parent Portal |
| `student_portal_visibility` | integer | yes | Student Portal Visibility  Indicates whether this class will display on the Student Portal |
| `student_portal_assignment_display` | integer | yes | Student Portal Assignment Display  Indicates whether assigments and assignment grades display on the Student Portal |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
