> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Student Logistics Requests / List Student Logistics Requests · [source site](https://api-docs.veracross.com/)

---


# List Student Logistics Requests


## GET `/student_logistics_requests`


List Student Logistics Requests


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer |  | Drop In Class Internal ID  Internal only for API use |
| `on_or_after_last_modified_date` | string |  | Last Modified Date |
| `on_or_before_last_modified_date` | string |  | Last Modified Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Student Logistics Request ID |
| `student_id` | integer | yes | Student ID |
| `student_name` | string <small>read-only</small> | yes | Student |
| `requestor_id` | integer | yes | Requestor ID |
| `requestor_name` | string <small>read-only</small> | yes | Requestor |
| `date` | string | yes | Request Date |
| `status` | integer | yes | Request Status |
| `category` | string | yes | Request Category |
| `reason` | string | yes | Request Reason |
| `notes` | string <small>max 1000</small> | yes | Request Notes |
| `attendance_start_date` | string | yes | Attendance Start Date |
| `attendance_time` | string | yes | Attendance Time |
| `attendance_end_date` | string | yes | Attendance End Date |
| `attendance_return_time` | string | yes | Attendance Return Time |
| `attendance_type` | integer | yes | Attendance Type |
| `transportation_method` | string | yes | Transportation Method |
| `am_pm` | integer | yes | AM/PM |
| `bus_stop` | integer | yes | Bus Stop |
| `bus_route` | string | yes | Bus Route |
| `response_notes` | string <small>max 1000</small> | yes | Response Notes |
| `internal_notes` | string <small>max 1000</small> | yes | Internal Notes |
| `extended_care_type` | string <small>max 20</small> | yes | Extended Care Type |
| `extended_care_arrival_time` | string | yes | Extended Care Arrival Time |
| `extended_care_leave_time` | string | yes | Extended Care Leave Time |
| `internal_class_id` | integer | yes | Drop In Class Internal ID  Internal only for API use |
| `posted` | boolean | yes | Posted |
| `send_notification` | boolean | yes | Send Notification?  When set, this will send notifications to staff members as configured. |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `last_modified_user` | string <small>read-only</small> | yes | Last Modified User |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
