> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Rubric Criteria / Update Academics: Rubric Criteria · [source site](https://api-docs.veracross.com/)

---


# Update Academics: Rubric Criteria


## PATCH `/academics/rubric_criteria/{id}`


Update Academics: Rubric Criteria


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Rubric Criteria ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Rubric Criteria ID |
| `category_id` | integer |  | Category |
| `rubric_id` | integer |  | Rubric ID |
| `description` | string <small>max 800</small> |  | Description |
| `report_override_description` | string <small>max 1000</small> |  | Report Card Description  Override rubric criteria description for use on report cards |
| `scale_id` | integer |  | Scale ID |
| `type` | integer |  | Type  Used to distinguish rubric criteria scale (normal), text (comments), or integer (numeric) grades entry options. |
| `scale_levels` | string <small>read-only</small> |  | Scale Levels |
| `tag` | string <small>max 300</small> |  | Tag |
| `notes` | string |  | Notes |
| `sort_key` | integer |  | Sort Key |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
