> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Configuration - Checklists / List Admission: Configuration - Checklists · [source site](https://api-docs.veracross.com/)

---


# List Admission: Configuration - Checklists


## GET `/admission/config/years/{school_year}/checklists`


List Admission: Configuration - Checklists


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_year` | integer | yes | School Year |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `category_id` | integer |  | Registration Season Checklist Category ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Registration Season Checklist Item ID |
| `school_year` | integer | yes | School Year |
| `checklist_type` | integer | yes | Widget Type |
| `description` | string <small>max 100</small> | yes | Description |
| `abbreviation` | string <small>max 15</small> | yes | Abbreviation |
| `required` | boolean | yes | Required |
| `filter_by_from_grade` | integer | yes | Filter By From Grade |
| `filter_by_to_grade` | integer | yes | Filter By To Grade |
| `filter_by_campus` | integer | yes | Filter By Campus |
| `filter_by_resident_status` | integer | yes | Filter By Resident Status |
| `filter_by_international` | integer | yes | Filter By International |
| `filter_by_group` | string <small>read-only</small> | yes | Filter By Group |
| `applies_to_prospect` | boolean | yes | Applies To Prospect |
| `required_for_application` | boolean | yes | Required For Application  Completion of all checklist items configured as &quot;Required for Application&quot; will trigger the insert of an application record and the update of the person&#39;s Role to include Applicant. Performs a check to avoid inserting a duplicate application record. |
| `required_for_review` | boolean | yes | Required For Review  Indicates that this checklist item needs to be complete before the application can be processed. |
| `due_date` | string | yes | Due Date |
| `early_due_date` | string | yes | Due Date Early |
| `category` | object | yes |  |
| `sort_key` | integer | yes | Sort Key |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
