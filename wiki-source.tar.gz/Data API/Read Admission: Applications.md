> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Applications / Read Admission: Applications · [source site](https://api-docs.veracross.com/)

---


# Read Admission: Applications


## GET `/admission/applications/{application_id}`


Read Admission: Applications


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `application_id` | integer | yes | Application ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `application_id` | integer <small>read-only</small> | yes | Application ID |
| `applicant_id` | integer | yes | Applicant ID |
| `year_applying_for` | integer | yes | Year Applying For |
| `month_applying_for` | integer | yes | Month Applying For |
| `grade_applying_for` | integer | yes | Grade Applying For |
| `resident_status_applying_for` | integer | yes | Resident Status Applying For |
| `campus_applying_for` | integer | yes | Campus Applying For |
| `student_group_applying_for` | integer | yes | Student Group Applying For |
| `admission_source` | integer | yes | Admission Source |
| `candidate_pool` | integer | yes | Candidate Pool |
| `admission_lead_date` | string | yes | Admission Lead Date |
| `inquiry_date` | string | yes | Inquiry Date |
| `visit_date` | string | yes | Visit Date |
| `application_date` | string | yes | Application Date |
| `requesting_financial_aid` | boolean | yes | Requesting Financial Aid |
| `application_status` | integer | yes | Application Status |
| `application_decision_date` | string | yes | Application Decision Date |
| `application_decision_response` | integer | yes | Application Decision Response |
| `application_decision_response_date` | string | yes | Application Decision Response Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
