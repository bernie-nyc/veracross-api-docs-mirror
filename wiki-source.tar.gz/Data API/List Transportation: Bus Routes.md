> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Transportation: Bus Routes / List Transportation: Bus Routes · [source site](https://api-docs.veracross.com/)

---


# List Transportation: Bus Routes


## GET `/transportation/bus_routes`


List Transportation: Bus Routes


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `am_pm` | integer |  | AM/PM |
| `driver` | string |  | Driver |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `description` | string <small>max 50</small> | yes | Description |
| `am_pm` | integer | yes | AM/PM |
| `start_time` | string | yes | Start Time  The time the bus departs |
| `end_time` | string | yes | End Time  The time the bus arrives at the last stop |
| `number_of_stops` | integer <small>read-only</small> | yes | # Stops |
| `capacity` | integer | yes | Capacity  The number of people the bus can hold |
| `max_scheduled_rider_count` | integer <small>read-only</small> | yes | Maximum Ridership  The maximum number of students scheduled on a given day |
| `organization` | string | yes | Organization |
| `driver` | string <small>read-only</small> | yes | Driver |
| `mobile_phone` | string <small>max 30</small> | yes | Mobile Phone |
| `notes` | string <small>max 500</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
