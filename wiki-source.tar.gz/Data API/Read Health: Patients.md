> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Health: Patients / Read Health: Patients · [source site](https://api-docs.veracross.com/)

---


# Read Health: Patients


## GET `/health/patients/{id}`


Read Health: Patients


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `first_name` | string <small>max 50</small> <small>read-only</small> | yes | First Name - Read Only |
| `preferred_name` | string <small>max 50</small> <small>read-only</small> | yes | Nick Name - Read Only |
| `middle_name` | string <small>max 50</small> <small>read-only</small> | yes | Middle Name - Read Only |
| `last_name` | string <small>max 50</small> <small>read-only</small> | yes | Last Name - Read Only |
| `date_of_birth` | string | yes | Birthday  Birthday in MMM DD YYYY format |
| `blood_type` | integer | yes | Blood Type |
| `height` | string <small>max 10</small> | yes | Height |
| `weight` | string <small>max 10</small> | yes | Weight |
| `gender` | integer <small>read-only</small> | yes | Gender - Read Only |
| `pronouns` | integer <small>read-only</small> | yes | Pronouns (Calculated)  Calculated based on the override pronoun set on this person, or else the pronouns used by their gender selection. |
| `medical_id_number` | string <small>max 100</small> | yes | Medical ID Number |
| `health_insurer` | string <small>max 100</small> | yes | Insurer |
| `health_group_number` | string <small>max 100</small> | yes | Group #  For medical insurance |
| `health_subscriber_number` | string <small>max 100</small> | yes | Subscriber #  For medical insurance |
| `dental_insurer` | string <small>max 50</small> | yes | Dental Insurer |
| `dental_group_number` | string <small>max 20</small> | yes | Dental Group # |
| `dental_subscriber_number` | string <small>max 20</small> | yes | Dental Subscriber # |
| `allergies_symptoms` | string <small>max 5000</small> | yes | Allergies/Symptoms (Memo)  Can be seen by most staff and in teacher portal. |
| `current_medications` | string <small>max 5000</small> | yes | Current Medications (Memo)  Can be seen by most staff and in teacher portal. |
| `medications_allowed` | string <small>read-only</small> | yes | Medications Allowed  See the &quot;Medications Allowed&quot; screen to add/remove medications. Can be seen by most staff and in teacher portal. |
| `general_medical_notes` | string <small>max 5000</small> | yes | General Medical Notes |
| `roles` | string <small>read-only</small> | yes | Roles  A list of all roles specified for this person.  Roles define this person&#39;s relationship to the school.  Can include &quot;virtual&quot; roles such as &quot;Relative of Alum&quot;. |
| `last_modified_date` | string | yes | Medical Info Update Date  The most recent date of update to data in the Person_Med overflow table (containing person-level data). |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
