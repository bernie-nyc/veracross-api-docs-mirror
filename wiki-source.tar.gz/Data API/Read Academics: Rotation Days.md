> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Rotation Days / Read Academics: Rotation Days · [source site](https://api-docs.veracross.com/)

---


# Read Academics: Rotation Days


## GET `/academics/config/rotation_days/{id}`


Read Academics: Rotation Days


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `description` | string <small>max 50</small> <small>read-only</small> | yes | Description |
| `abbreviation` | string <small>max 8</small> | yes | Abbreviation |
| `day_index` | integer | yes | Day Index |
| `active` | boolean | yes | Active  Used to determine whether this day is active today.  Set automatically by the nightly process. |
| `rotation` | object | yes |  |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
