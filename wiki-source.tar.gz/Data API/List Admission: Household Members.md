> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Household Members / List Admission: Household Members · [source site](https://api-docs.veracross.com/)

---


# List Admission: Household Members


## GET `/admission/households/{household_id}/members`


List Admission: Household Members


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer | yes | Household ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `first_name` | string |  | First Name |
| `last_name` | string |  | Last Name |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `name_prefix` | integer | yes | Name Prefix |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `nick_name` | string <small>max 50</small> | yes | Preferred Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `name_suffix` | integer | yes | Name Suffix |
| `gender` | integer | yes | Gender |
| `date_of_birth` | string | yes | Birthday  Birthday in MMM DD YYYY format |
| `email` | string <small>max 100</small> | yes | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
