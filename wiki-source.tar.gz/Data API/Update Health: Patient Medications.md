> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Health: Patient Medications / Update Health: Patient Medications · [source site](https://api-docs.veracross.com/)

---


# Update Health: Patient Medications


## PATCH `/health/patients/{patient_id}/medications/{id}`


Update Health: Patient Medications


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person/Medication ID  The internal Veracross ID number for this record with information on a specific information for a particular person. |
| `patient_id` | integer | yes | Patient ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person/Medication ID  The internal Veracross ID number for this record with information on a specific information for a particular person. |
| `patient_id` | integer |  | Patient ID |
| `medication` | integer |  | Medication GKC |
| `start_date` | string |  | Start Date |
| `end_date` | string |  | End Date |
| `dosage_instruction` | string <small>max 2000</small> |  | Dosage Instruction |
| `notes` | string <small>max 2000</small> |  | Notes |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
