> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Development: Constituents / Read Development: Constituents · [source site](https://api-docs.veracross.com/)

---


# Read Development: Constituents


## GET `/development/constituents/{id}`


Read Development: Constituents


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Constituent ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Constituent ID |
| `record_type` | integer | yes | Record Type |
| `constituent` | string <small>read-only</small> | yes | Description |
| `primary_development_role` | integer | yes | Primary Development Role  Primary development role of the current year annual fund opportunity. |
| `primary_dev_rating` | integer | yes | Primary Dev Rating |
| `constituent_solicitor_1` | string <small>read-only</small> | yes | Constituent Solicitor 1  Default solicitor 1 for opportunities for this constituent. |
| `solicitable` | boolean <small>read-only</small> | yes | Solicitable  Indicates if the related person/organization records are marked as &quot;Do Not Solicit&quot;. This will report as NOT solicitable if the primary person OR spouse is marked as &quot;Do Not Solicit&quot;. |
| `deceased` | boolean <small>read-only</small> | yes | Deceased |
| `notes` | string | yes | Notes |
| `address_1` | string <small>read-only</small> | yes | Address 1 |
| `address_2` | string <small>read-only</small> | yes | Address 2 |
| `address_3` | string <small>read-only</small> | yes | Address 3 |
| `city` | string <small>read-only</small> | yes | City |
| `state` | string <small>read-only</small> | yes | State |
| `postal_code` | string <small>read-only</small> | yes | Postal Code |
| `country` | integer <small>read-only</small> | yes | Country |
| `household` | object <small>read-only</small> | yes |  |
| `person` | object | yes |  |
| `spouse` | object | yes |  |
| `organization` | object | yes |  |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `gift_count` | integer <small>read-only</small> | yes | Gift Count |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
