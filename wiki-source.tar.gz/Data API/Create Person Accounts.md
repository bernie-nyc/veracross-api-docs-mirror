> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Person Accounts / Create Person Accounts · [source site](https://api-docs.veracross.com/)

---


# Create Person Accounts


## POST `/person_accounts`


Create Person Accounts


Known limitations
- The create endpoint will not allow assigning these security roles: SysAdmin_1, SysAdmin_2, User_Account_Admin.
- To update a user account for a person record, first delete the account via the delete endpoint, then recreate it via the create endpoint.


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID  A person record must exist before creating a user account for the person record. |
| `username` | string <small>max 128</small> |  | Username |
| `external_username` | string <small>max 255</small> |  | External Username  The username in your external login provider. If you are not using an external provider, leave blank and the system will generate a username for the user based on username configuration set up in Axiom. |
| `account_status` | integer | yes | Account Status  For Veracross accounts without associated external accounts. |
| `account_type` | integer | yes | Account Type |
| `external_account_status` | integer | yes | External Account Status  Enabled (`1`) or disabled (`0`); defaults to enabled. |
| `security_roles` | integer |  | Security Roles  A comma delimited string of security role IDs. If omitted, default roles are generated based on the person roles. Refer to the List Security Roles endpoint for more details. |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
