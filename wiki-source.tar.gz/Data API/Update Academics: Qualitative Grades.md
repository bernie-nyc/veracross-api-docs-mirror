> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Qualitative Grades / Update Academics: Qualitative Grades · [source site](https://api-docs.veracross.com/)

---


# Update Academics: Qualitative Grades


## PATCH `/academics/qualitative_grades/{id}`


Update Academics: Qualitative Grades


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Grade ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Grade ID |
| `enrollment_id` | integer |  | Enrollment ID |
| `class` | object <small>read-only</small> |  |  |
| `grading_period` | object |  |  |
| `student` | object <small>read-only</small> |  |  |
| `rubric` | object <small>read-only</small> |  |  |
| `rubric_category` | object <small>read-only</small> |  |  |
| `rubric_criteria` | object |  |  |
| `proficiency_level` | string <small>max 35</small> |  | Proficiency Level |
| `comment` | string |  | Comments |
| `locked` | boolean |  | Locked  Indicates that the data for this record are locked, and only authorized users can make changes |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
