> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Invoices / Create Finance: AP Invoices · [source site](https://api-docs.veracross.com/)

---


# Create Finance: AP Invoices


## POST `/finance/ap_invoices`


Create Finance: AP Invoices


The duplicate (non-shown) ID fields without `_id` are only for backwards compatibility, and should eventually be removed.


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | integer <small>read-only</small> |  | AP Header ID |
| `invoice_number` | string <small>max 30</small> | yes | Invoice Number |
| `invoice_date` | string |  | Invoice Date |
| `due_date` | string |  | Due Date |
| `description` | string <small>max 80</small> |  | Description |
| `ap_gl_account_id` | integer |  | AP GL Account ID |
| `approval_person_id` | integer |  | Approval Person ID |
| `vendor_id` | integer |  | Vendor ID |
| `do_not_pay` | boolean |  | Do Not Pay? |
| `external_po_number` | string <small>max 60</small> |  | External PO Number |
| `external_po_url` | string <small>max 500</small> |  | External PO Url |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
