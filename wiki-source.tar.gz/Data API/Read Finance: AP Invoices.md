> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Invoices / Read Finance: AP Invoices · [source site](https://api-docs.veracross.com/)

---


# Read Finance: AP Invoices


## GET `/finance/ap_invoices/{id}`


Read Finance: AP Invoices


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | AP Header ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | integer <small>read-only</small> | yes | AP Header ID |
| `invoice_number` | string <small>max 30</small> | yes | Invoice Number |
| `vendor` | string | yes | Vendor |
| `vendor_id` | integer | yes | Vendor ID |
| `invoice_date` | string | yes | Invoice Date |
| `due_date` | string | yes | Due Date |
| `posting_date` | string <small>read-only</small> | yes | Posting Date - Read Only |
| `description` | string <small>max 80</small> | yes | Description |
| `ap_gl_account` | string <small>read-only</small> | yes | AP GL Account |
| `ap_gl_account_id` | integer | yes | AP GL Account ID |
| `ap_gl_cost_center` | integer <small>read-only</small> | yes | AP GL Cost Center - Read Only |
| `gross_amount` | number <small>read-only</small> | yes | Gross Amount - Read Only |
| `as_posted_amount` | number <small>read-only</small> | yes | As Posted Amount - Read Only |
| `net_amount_paid` | number <small>read-only</small> | yes | Net Amount Paid - Read Only |
| `unpaid_amount` | number <small>read-only</small> | yes | Unpaid Amount |
| `fiscal_year` | integer <small>read-only</small> | yes | Fiscal Year - Read Only |
| `fiscal_period` | integer <small>read-only</small> | yes | Fiscal Period - Read Only |
| `approval_person` | string <small>read-only</small> | yes | Approval Person  Person who must approve this expense prior to its posting and payment |
| `approval_person_id` | integer | yes | Approval Person ID |
| `cancelled` | boolean | yes | Cancel?  This option cancels the entire invoice. |
| `posted` | boolean | yes | Posted? |
| `do_not_pay` | boolean | yes | Do Not Pay? |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `tax_type` | string <small>read-only</small> | yes | Tax Type ID for AP Invoices |
| `inclusive_exclusive` | string <small>read-only</small> | yes | Inclusive/Exclusive for AP Invoices |
| `total_tax` | number | yes | Total Tax |
| `input_date` | string | yes | Input Date |
| `external_po_number` | string <small>max 60</small> | yes | External PO Number |
| `external_po_url` | string <small>max 500</small> | yes | External PO Url |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
