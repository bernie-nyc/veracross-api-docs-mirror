> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Finance: AP Invoice Items / List Finance: AP Invoice Items · [source site](https://api-docs.veracross.com/)

---


# List Finance: AP Invoice Items


## GET `/finance/ap_invoice_items`


List Finance: AP Invoice Items


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `ap_invoice_header_id` | integer |  | AP Header ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_item_id` | integer <small>read-only</small> | yes | AP Item ID |
| `invoice_number` | string <small>max 30</small> | yes | Invoice Number |
| `ap_invoice_header_id` | integer <small>read-only</small> | yes | AP Header ID |
| `vendor` | string <small>read-only</small> | yes | Vendor - Read Only |
| `invoice_date` | string | yes | Invoice Date  Item date is almost always the same as the invoice date , except in cases of adjustment items. |
| `due_date` | string | yes | Due Date |
| `posting_date` | string <small>read-only</small> | yes | Posting Date - Read Only |
| `quantity` | number | yes | Quantity |
| `unit_cost` | number | yes | Unit Cost |
| `amount` | number | yes | Amount |
| `dr_gl_account` | string <small>read-only</small> | yes | DR GL Account |
| `project_id` | string <small>read-only</small> | yes | Project # |
| `ap_description` | string <small>max 200</small> | yes | AP Description |
| `je_ref_id` | string <small>read-only</small> | yes | JE Ref. # - Read Only |
| `posted` | boolean <small>read-only</small> | yes | Posted? - Read Only |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `tax_type` | object | yes |  |
| `tax_amount` | number | yes | Tax Amount |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
