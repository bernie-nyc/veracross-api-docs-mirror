> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Master Attendance / Update Master Attendance · [source site](https://api-docs.veracross.com/)

---


# Update Master Attendance


## PATCH `/master_attendance/{id}`


Update Master Attendance


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Daily Attendance ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Daily Attendance ID |
| `attendance_date` | string |  | Attendance Date |
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `person` | string <small>read-only</small> |  | Person |
| `attendance_category` | integer |  | Attendance Category |
| `student_attendance_status` | integer |  | Status (Students) |
| `faculty_attendance_status` | integer |  | Status (Faculty) |
| `excused` | boolean |  | Excused |
| `late_arrival_time` | string |  | Late Arrival Time  Late Arrival Time |
| `early_dismissal_time` | string |  | Early Dismissal Time  Early Dismissal Time |
| `return_time` | string |  | Return Time  Return Time |
| `school_year` | integer |  | School Year |
| `grading_period` | integer |  | Grading Period |
| `day_of_week` | integer <small>read-only</small> |  | Day of Week |
| `notes` | string <small>max 2000</small> |  | Notes |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
