> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Behavior Incident Types / Read Behavior Incident Types · [source site](https://api-docs.veracross.com/)

---


# Read Behavior Incident Types


## GET `/behavior_incident_types/{id}`


Read Behavior Incident Types


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `description` | string <small>max 75</small> | yes | Description |
| `category` | integer | yes | Category |
| `behavior_points` | number | yes | Behavior Points |
| `allow_teacher_input` | boolean | yes | Allow Teacher Input |
| `default_status` | integer | yes | Default Status  If specified, the Behavior/Comment&#39;s status field will be set to this status after it is inserted. |
| `default_outcome` | integer | yes | Default Outcome |
| `default_email_template` | integer | yes | Default Email Template  The email template that will be used to notify parents and students.  Staff/Faculty will always get notified via the internal email template. Only email templates that have a Module of &#39;Behavior&#39; and are NOT flagged as System will appear in this list. |
| `default_internal_email_template` | integer | yes | Default Internal Email Template  The email template that will be used to notify staff and faculty. Only email templates that have a Module of &#39;Behavior&#39; will appear in this list. |
| `reporting_person_notification` | integer | yes | Reporting Person Notification |
| `assigned_to_person_notification` | integer | yes | Assigned To Person Notification |
| `student_notification` | integer | yes | Student Notification |
| `parent_notification` | integer | yes | Parent Notification  Sends notification email to anyone with Legal Custody OR Portal Access |
| `advisor_notification` | integer | yes | Advisor Notification |
| `homeroom_teacher_notification` | integer | yes | Homeroom Teacher Notification |
| `teacher_notification` | integer | yes | Teacher Notification  Student&#39;s teachers in active, Academic-type classes |
| `coach_notification` | integer | yes | Coach Notification |
| `program_teacher_notification` | integer | yes | Program Teacher Notification |
| `dorm_parent_notification` | integer | yes | Dorm Parent Notification |
| `dorm_head_notification` | integer | yes | Dorm Head Notification |
| `sort_key` | integer | yes | Sort Key |
| `is_obsolete` | boolean | yes | Obsolete |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
