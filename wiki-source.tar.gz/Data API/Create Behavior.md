> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Behavior / Create Behavior · [source site](https://api-docs.veracross.com/)

---


# Create Behavior


## POST `/behavior`


Create Behavior


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Behavior ID |
| `incident_date` | string |  | Incident Date |
| `on_or_before_incident_date` | string |  | Incident Date |
| `on_or_after_incident_date` | string |  | Incident Date |
| `incident_type` | integer |  | Incident Type |
| `student_id` | integer | yes | Student ID |
| `reporting_person_id` | integer |  | Reporting Person ID |
| `assigned_to_person_id` | integer |  | Assigned To Person ID |
| `internal_class_id` | integer |  | Class ID |
| `class_name` | string <small>max 80</small> | yes | Description |
| `incident_notes` | string |  | Incident Notes  Incident notes are for internal use and not visible to parents or students unless included in the email notification template.&#39; Email Template merge variable: {incident_notes} |
| `behavior_points` | integer <small>read-only</small> |  | Behavior Points |
| `status` | integer |  | Status |
| `status_date` | string |  | Status Date |
| `outcome_type` | integer |  | Outcome Type |
| `outcome_date` | string |  | Outcome Date |
| `outcome_notes` | string |  | Outcome Notes  Outcome notes are for internal use and not visible to parents or students unless included in the email notification template. Email Template merge variable: {outcome_notes} |
| `follow_up_status` | integer |  | Follow Up Status |
| `follow_up_status_date` | string |  | Follow Up Status Date |
| `last_modified_date` | string |  | Update Date |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
