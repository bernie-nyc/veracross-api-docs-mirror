> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Boarding: Dorm Students / Update Boarding: Dorm Students · [source site](https://api-docs.veracross.com/)

---


# Update Boarding: Dorm Students


## PATCH `/boarding/dorms/{internal_dorm_id}/students/{id}`


Update Boarding: Dorm Students


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Enrollment ID |
| `internal_dorm_id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Enrollment ID |
| `student_id` | integer <small>read-only</small> |  | Person ID |
| `dorm_id` | integer <small>read-only</small> |  | Internal Class ID |
| `dorm` | string <small>read-only</small> |  | Class |
| `room_number` | string <small>max 10</small> |  | Room Number |
| `floor_number` | integer |  | Floor Number |
| `bed_number` | integer |  | Bed Number |
| `currently_enrolled` | boolean |  | Currently Enrolled  A read-only calculated field, this field indicates whether the student is currently enrolled in the class. It is based on a combination of the &quot;Late Date Enrolled&quot; and &quot;Date Withdrawn&quot; fields.    For Classes with a waitlist, if the student is on the waitlist, this field will also report they are not in the class. |
| `late_date_enrolled` | string |  | Late Date Enrolled  The date the student enrolled in the class |
| `date_withdrawn` | string |  | Date Withdrawn  The date the student withdrew from the class |
| `notes` | string <small>max 1000</small> |  | Notes |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
