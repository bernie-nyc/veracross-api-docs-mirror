> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Staff/Faculty / Create Staff/Faculty · [source site](https://api-docs.veracross.com/)

---


# Create Staff/Faculty


## POST `/staff_faculty`


Create Staff/Faculty


| Role ID | Role                |
|---------|---------------------|
| 20      | Coach               |
| 21      | Staff               |
| 22      | Faculty             |
| 24      | Substitute Staff    |
| 25      | Substitute Teacher  |
| 27      | Future Faculty      |
| 35      | Faculty Summer Only |
| 36      | Staff - Ancillary   |
| 37      | Staff - Other       |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `name_prefix` | integer | yes | Name Prefix |
| `name_suffix` | integer | yes | Name Suffix |
| `first_name` | string <small>max 50</small> |  | First Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `maiden_name` | string <small>max 50</small> |  | Maiden Name |
| `preferred_name` | string <small>max 50</small> |  | Nick Name |
| `household_id` | integer | yes | Household ID |
| `gender` | integer | yes | Gender |
| `pronouns` | integer | yes | Pronouns |
| `birth_date` | string |  | Date of Birth |
| `date_hired` | string |  | Date Hired |
| `date_terminated` | string |  | Date Terminated |
| `employee_roles` | string <small>max 500</small> |  | Employee Roles  A comma-separated list of role IDs. |
| `full_time_percentage` | integer | yes | Full Time Percentage |
| `job_title` | string <small>max 100</small> |  | Job Title |
| `employee_code` | integer | yes | Employee Code |
| `campus` | integer | yes | Campus |
| `primary_department` | integer | yes | Department |
| `additional_departments` | string <small>max 500</small> |  | Additional Departments  A comma-separated list of department IDs. |
| `faculty_type` | integer | yes | Faculty Type |
| `email_1` | string <small>max 100</small> |  | Email 1 |
| `email_2` | string <small>max 100</small> |  | Email 2 |
| `home_phone` | string <small>max 30</small> |  | Phone Home |
| `mobile_phone` | string <small>max 30</small> |  | Phone Mobile |
| `business_phone` | string <small>max 30</small> |  | Phone Business |
| `license_plate` | string <small>max 12</small> |  | License Plate |
| `address_1` | string <small>max 200</small> |  | Address 1 |
| `address_2` | string <small>max 200</small> |  | Address 2 |
| `address_3` | string <small>max 200</small> |  | Address 3 |
| `city` | string <small>max 50</small> |  | City |
| `state` | string <small>max 50</small> |  | State Province |
| `postal_code` | string <small>max 20</small> |  | Postal Code |
| `country` | integer |  | Country |
| `legacy_id` | string <small>max 50</small> |  | Legacy ID |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
