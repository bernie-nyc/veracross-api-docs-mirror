> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Class Assignments / Read Academics: Class Assignments · [source site](https://api-docs.veracross.com/)

---


# Read Academics: Class Assignments


## GET `/academics/classes/{internal_class_id}/assignments/{id}`


Read Academics: Class Assignments


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Class Assignment ID |
| `internal_class_id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Class Assignment ID |
| `internal_class_id` | integer | yes | Internal Class ID |
| `assignment_type` | integer | yes | Assignment Type  The type of assignment: for ex. Homework, Quiz, Exam, etc. |
| `description` | string <small>max 256</small> | yes | Description |
| `assignment_details` | string | yes | Notes |
| `max_score` | integer | yes | Maximum Score  The maximum possible score for this assignment |
| `weight` | integer | yes | Weight (Pts)  The weight for this assignment |
| `not_to_be_graded` | boolean | yes | Not to be Graded  If selected, this assignment will not factor into the students&#39; grades.  Any grades that are entered will NOT count towards the final grades. |
| `date_assigned` | string | yes | Date Assigned  The date on which this assignment was assigned |
| `date_due` | string | yes | Due Date  The date this assignment is due |
| `display_status` | integer | yes | Display Status |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
