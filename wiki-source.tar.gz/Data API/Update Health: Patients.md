> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Health: Patients / Update Health: Patients · [source site](https://api-docs.veracross.com/)

---


# Update Health: Patients


## PATCH `/health/patients/{id}`


Update Health: Patients


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person ID |
| `first_name` | string <small>max 50</small> <small>read-only</small> |  | First Name - Read Only |
| `preferred_name` | string <small>max 50</small> <small>read-only</small> |  | Nick Name - Read Only |
| `middle_name` | string <small>max 50</small> <small>read-only</small> |  | Middle Name - Read Only |
| `last_name` | string <small>max 50</small> <small>read-only</small> |  | Last Name - Read Only |
| `date_of_birth` | string |  | Birthday  Birthday in MMM DD YYYY format |
| `blood_type` | integer |  | Blood Type |
| `height` | string <small>max 10</small> |  | Height |
| `weight` | string <small>max 10</small> |  | Weight |
| `gender` | integer <small>read-only</small> |  | Gender - Read Only |
| `pronouns` | integer <small>read-only</small> |  | Pronouns (Calculated)  Calculated based on the override pronoun set on this person, or else the pronouns used by their gender selection. |
| `medical_id_number` | string <small>max 100</small> |  | Medical ID Number |
| `health_insurer` | string <small>max 100</small> |  | Insurer |
| `health_group_number` | string <small>max 100</small> |  | Group #  For medical insurance |
| `health_subscriber_number` | string <small>max 100</small> |  | Subscriber #  For medical insurance |
| `dental_insurer` | string <small>max 50</small> |  | Dental Insurer |
| `dental_group_number` | string <small>max 20</small> |  | Dental Group # |
| `dental_subscriber_number` | string <small>max 20</small> |  | Dental Subscriber # |
| `allergies_symptoms` | string <small>max 5000</small> |  | Allergies/Symptoms (Memo)  Can be seen by most staff and in teacher portal. |
| `current_medications` | string <small>max 5000</small> |  | Current Medications (Memo)  Can be seen by most staff and in teacher portal. |
| `medications_allowed` | string <small>read-only</small> |  | Medications Allowed  See the &quot;Medications Allowed&quot; screen to add/remove medications. Can be seen by most staff and in teacher portal. |
| `general_medical_notes` | string <small>max 5000</small> |  | General Medical Notes |
| `roles` | string <small>read-only</small> |  | Roles  A list of all roles specified for this person.  Roles define this person&#39;s relationship to the school.  Can include &quot;virtual&quot; roles such as &quot;Relative of Alum&quot;. |
| `last_modified_date` | string |  | Medical Info Update Date  The most recent date of update to data in the Person_Med overflow table (containing person-level data). |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
