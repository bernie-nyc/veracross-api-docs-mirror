> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Application Checklists / List Admission: Application Checklists · [source site](https://api-docs.veracross.com/)

---


# List Admission: Application Checklists


## GET `/admission/applications/{application_id}/checklists`


List Admission: Application Checklists


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `application_id` | integer | yes | Person Admission ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | C/L ID |
| `checklist_item_id` | integer | yes | Registration Season Checklist Item ID |
| `required` | boolean | yes | Checklist Item Required |
| `scheduled_date` | string | yes | Scheduled Date |
| `completed_date` | string | yes | Checklist Item Completed Date |
| `completed` | boolean | yes | Checklist Item Complete |
| `follow_up_complete` | boolean | yes | Follow Up Complete |
| `follow_up_complete_date` | string | yes | Follow Up Date |
| `notes` | string <small>max 5000</small> | yes | Notes |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
