> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Portal Membership / Update Portal Membership · [source site](https://api-docs.veracross.com/)

---


# Update Portal Membership


## PATCH `/portal_membership/{id}`


Update Portal Membership


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Portal ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Portal ID |
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `portal_id` | integer <small>read-only</small> |  | Portal ID |
| `portal_description` | string <small>max 200</small> <small>read-only</small> |  | Description |
| `portal_access_name` | string <small>max 200</small> <small>read-only</small> |  | Access Name |
| `portal_status` | integer |  | Status |
| `primary_portal` | string <small>read-only</small> |  | Primary Portal |
| `portal_strategy_match` | integer <small>read-only</small> |  | Strategy Match  Does this member match the currently configured membership strategy |
| `portal_membership_type` | integer <small>read-only</small> |  | Membership Type |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
