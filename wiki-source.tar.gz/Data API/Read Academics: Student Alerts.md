> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Student Alerts / Read Academics: Student Alerts · [source site](https://api-docs.veracross.com/)

---


# Read Academics: Student Alerts


## GET `/academics/student_alerts/{person_id}`


Read Academics: Student Alerts


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `family_alert` | string <small>max 1000</small> | yes | Family Alert  Important family alert information that will be prominently displayed on the Teacher portal and available to all staff &amp; faculty |
| `medical_alert` | string <small>max 1000</small> | yes | Medical Alert  Important medical alert information that will be prominently displayed on the Teacher portal and available to all staff &amp; faculty |
| `general_alert` | string <small>max 1000</small> | yes | General Alert  Important general alert information that will be prominently displayed on the Teacher portal and available to all staff &amp; faculty |
| `academic_alert` | string <small>max 1000</small> | yes | Academic Alert |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
