> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Relatives / Create Admission: Relatives · [source site](https://api-docs.veracross.com/)

---


# Create Admission: Relatives


## POST `/admission/relatives`


Create Admission: Relatives


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer | yes | Household ID |
| `address_1` | string <small>max 200</small> |  | Address 1 |
| `address_2` | string <small>max 200</small> |  | Address 2 |
| `address_3` | string <small>max 200</small> |  | Address 3 |
| `city` | string <small>max 50</small> |  | City |
| `state` | string <small>max 50</small> |  | State |
| `postal_code` | string <small>max 20</small> |  | Postal Code |
| `country` | integer | yes | Country |
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `name_prefix` | integer | yes | Name Prefix |
| `first_name` | string <small>max 50</small> |  | First Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `name_suffix` | string | yes | Name Suffix |
| `nick_name` | string <small>max 50</small> |  | Nick Name |
| `maiden_name` | string <small>max 50</small> |  | Maiden Name |
| `marital_status` | integer | yes | Marital Status |
| `pronouns` | integer | yes | Pronouns |
| `gender` | integer | yes | Gender |
| `ethnicity` | integer | yes | Ethnicity |
| `date_of_birth` | string |  | Date Of Birth |
| `place_of_birth` | string <small>max 50</small> |  | Place Of Birth |
| `date_of_death` | string |  | Date Of Death |
| `graduation_year` | integer | yes | Graduation Year |
| `email` | string <small>max 100</small> |  | Email |
| `mobile_phone` | string <small>max 30</small> |  | Phone Mobile |
| `work_phone` | string <small>max 30</small> |  | Phone Work |
| `applicant_id` | integer | yes | Applicant ID |
| `relationship` | integer | yes | Relationship |
| `legal_custody` | boolean | yes | Legal Custody |
| `admissions_access` | boolean | yes | Admissions Access |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
