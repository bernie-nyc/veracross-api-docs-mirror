> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Alumni: Demographics / Read Alumni: Demographics · [source site](https://api-docs.veracross.com/)

---


# Read Alumni: Demographics


## GET `/alumni/demographics/{id}`


Read Alumni: Demographics


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `household_id` | integer <small>read-only</small> | yes | Household ID |
| `name_prefix` | string <small>read-only</small> | yes | Description |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `maiden_name` | string <small>max 50</small> | yes | Maiden Name |
| `name_suffix` | string <small>read-only</small> | yes | Description |
| `gender` | integer | yes | Gender |
| `entry_date` | string | yes | Entry Date  This is the original date on which the student started school. Should be the first day of the school year for new students, or a date during the school year for mid-year enrollees. |
| `exit_date` | string | yes | Exit Date  The last day the student was in school. Should be either the last day of the school year, or last day the student was in class. |
| `graduation_year` | integer | yes | Graduation Year |
| `years_enrolled` | number <small>read-only</small> | yes | Years Enrolled  The number of years this student has been enrolled |
| `first_year_enrolled` | integer <small>read-only</small> | yes | First Year Enrolled  This is a calculated value, showing the first school year registered among the Enrollment History records showing  student&#39;s Enr History tab. |
| `first_grade_enrolled_at` | integer <small>read-only</small> | yes | First Grade Enrolled At |
| `last_year_enrolled` | integer <small>read-only</small> | yes | Last Year Enrolled  The school year on the most recent enrollment record that has either the EN: Newly Enrolled or the RE: Re-Enrolled status. |
| `last_grade_enrolled_at` | integer <small>read-only</small> | yes | Last Grade Enrolled At |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
