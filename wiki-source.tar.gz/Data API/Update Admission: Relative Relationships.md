> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Relative Relationships / Update Admission: Relative Relationships · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Relative Relationships


## PATCH `/admission/relatives/{relative_id}/relationships/{id}`


Update Admission: Relative Relationships


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Person ID |
| `relative_id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Person ID |
| `related_person_id` | integer |  | Related Person ID |
| `relationship` | integer |  | Relationship  When background shading is available:  Orange: Immediate family, e.g. Husband, Wife, Father, Mother, Brother, Sister, Sibling, Domestic Partner  Yellow: Secondary family, e.g. Grandparents, Aunt/Uncle, Cousin  Manilla: In-Laws, Exes, Step-child, Step-parent, deceased spouse  Gray-Blue: &quot;Unspecified&quot; and &quot;Other&quot;  White: All others |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
