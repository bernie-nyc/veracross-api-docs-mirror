> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Disbursements / Create Finance: AP Disbursements · [source site](https://api-docs.veracross.com/)

---


# Create Finance: AP Disbursements


## POST `/finance/ap_disbursements`


Create Finance: AP Disbursements


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `disbursement_id` | integer <small>read-only</small> |  | Disbursement Header |
| `check_reference_number` | integer |  | Check/Reference Number |
| `description` | string <small>max 80</small> |  | Description |
| `disbursement_date` | string |  | Disbursement Date |
| `disbursement_category` | integer |  | Disbursement Category |
| `disbursement_type` | integer |  | Disbursement Type |
| `vendor_id` | integer |  | Vendor ID |
| `cash_gl_account_id` | integer |  | Cash GL Account ID |
| `payee_name` | string <small>max 200</small> |  | Payee Name |
| `amount` | number |  | Amount |
| `cleared` | boolean |  | Cleared (H)? |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
