> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Emergency Contacts / Read Emergency Contacts · [source site](https://api-docs.veracross.com/)

---


# Read Emergency Contacts


## GET `/emergency_contacts/{id}`


Read Emergency Contacts


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person Person ID |
| `person_id` | integer | yes | Person ID |
| `student_id` | integer | yes | Student ID |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `nick_name` | string <small>max 50</small> | yes | Nick Name |
| `relationship` | integer | yes | Relationship  The relationship this emergency contact has to the student |
| `legal_custody` | boolean | yes | Legal Custody |
| `pick_up` | boolean | yes | Pick Up |
| `medical_notification` | boolean | yes | Medical Notification |
| `email_1` | string <small>max 100</small> | yes | Email 1 |
| `email_2` | string <small>max 100</small> | yes | Email 2 |
| `home_phone` | string <small>max 30</small> | yes | Home Phone |
| `mobile_phone` | string <small>max 30</small> | yes | Mobile Phone |
| `business_phone` | string <small>max 30</small> | yes | Business Phone |
| `address_1` | string <small>max 200</small> | yes | Address 1 |
| `address_2` | string <small>max 200</small> | yes | Address 2 |
| `city` | string <small>max 50</small> | yes | City |
| `state_province` | string <small>max 50</small> | yes | State Province |
| `postal_code` | string <small>max 20</small> | yes | Postal Code |
| `country` | integer | yes | Country |
| `notes` | string <small>max 1000</small> | yes | Notes |
| `last_modified_date` | string | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
