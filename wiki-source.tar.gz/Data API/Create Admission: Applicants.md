> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Applicants / Create Admission: Applicants · [source site](https://api-docs.veracross.com/)

---


# Create Admission: Applicants


## POST `/admission/applicants`


Create Admission: Applicants


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `household_id` | integer | yes | Household ID |
| `address_1` | string <small>max 200</small> |  | Address 1 |
| `address_2` | string <small>max 200</small> |  | Address 2 |
| `address_3` | string <small>max 200</small> |  | Address 3 |
| `city` | string <small>max 50</small> |  | City |
| `state` | string <small>max 50</small> |  | State |
| `postal_code` | string <small>max 20</small> |  | Postal Code |
| `country` | integer | yes | Country |
| `applicant_id` | integer <small>read-only</small> |  | Applicant ID |
| `name_prefix` | integer | yes | Name Prefix |
| `first_name` | string <small>max 50</small> |  | First Name |
| `middle_name` | string <small>max 50</small> |  | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `name_suffix` | integer | yes | Name Suffix |
| `nick_name` | string <small>max 50</small> |  | Nick Name |
| `gender` | integer | yes | Gender |
| `pronouns` | integer | yes | Pronouns |
| `ethnicity` | integer | yes | Ethnicity |
| `date_of_birth` | string |  | Date Of Birth |
| `place_of_birth` | string <small>max 50</small> |  | Place of Birth |
| `email` | string <small>max 100</small> |  | Email |
| `phone_mobile` | string <small>max 30</small> |  | Phone Mobile |
| `current_grade` | integer | yes | Current Grade |
| `application_id` | integer | yes | Application ID |
| `year_applying_for` | integer | yes | Year Applying For |
| `month_applying_for` | integer |  | Month Applying For |
| `grade_applying_for` | integer | yes | Grade Applying For |
| `resident_status_applying_for` | integer | yes | Resident Status Applying For |
| `campus_applying_for` | integer | yes | Campus Applying For |
| `student_group_applying_for` | integer | yes | Student Group Applying For |
| `admission_source` | integer | yes | Admission Source |
| `candidate_pool` | integer | yes | Candidate Pool |
| `requesting_financial_aid` | boolean |  | Requesting Financial Aid |
| `admission_lead_date` | string |  | Admission Lead Date |
| `inquiry_date` | string |  | Inquiry Date |
| `visit_date` | string |  | Visit Date |
| `application_date` | string |  | Application Date |
| `application_status` | integer |  | Application Status |
| `application_decision_date` | string |  | Application Decision Date |
| `application_decision_response` | integer |  | Application Decision Response |
| `application_decision_response_date` | string |  | Application Decision Response Date |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
