> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Application Checklists / Update Admission: Application Checklists · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Application Checklists


## PATCH `/admission/applications/{application_id}/checklists/{id}`


Update Admission: Application Checklists


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | C/L ID |
| `application_id` | integer | yes | Person Admission ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | C/L ID |
| `checklist_item_id` | integer |  | Registration Season Checklist Item ID |
| `required` | boolean |  | Checklist Item Required |
| `scheduled_date` | string |  | Scheduled Date |
| `completed_date` | string |  | Checklist Item Completed Date |
| `completed` | boolean |  | Checklist Item Complete |
| `follow_up_complete` | boolean |  | Follow Up Complete |
| `follow_up_complete_date` | string |  | Follow Up Date |
| `notes` | string <small>max 5000</small> |  | Notes |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
