> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Disbursement Items / Read Finance: AP Disbursement Items · [source site](https://api-docs.veracross.com/)

---


# Read Finance: AP Disbursement Items


## GET `/finance/ap_disbursement_items/{id}`


Read Finance: AP Disbursement Items


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Disbursement Item ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `disbursement_item_id` | integer <small>read-only</small> | yes | Disbursement Item ID |
| `disbursement_header_id` | integer | yes | Disbursement Header ID |
| `disbursement_header` | string | yes | Disbursement Header |
| `debit_gl_account` | string <small>read-only</small> | yes | DR GL Account |
| `amount` | number | yes | Amount  Amount of this transaction that has been posted to the general ledger. |
| `unapplied_amount` | number <small>read-only</small> | yes | Unapplied Amount |
| `description` | string <small>max 80</small> | yes | Description |
| `je_ref_id` | string <small>read-only</small> | yes | JE Ref # - Read Only |
| `posted` | boolean <small>read-only</small> | yes | Posted? - Read Only |
| `posting_date` | string <small>read-only</small> | yes | Posting Date - Read Only |
| `cleared` | boolean | yes | Cleared? |
| `ap_invoice_header` | string | yes | AP Invoice |
| `ap_invoice_item` | string | yes | AP Item |
| `input_date` | string <small>read-only</small> | yes | Input Date (Local) |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `ap_invoice_id` | integer | yes | AP Invoice ID |
| `ap_invoice_item_id` | integer | yes | AP Item ID |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
