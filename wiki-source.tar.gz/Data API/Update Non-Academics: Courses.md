> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Non-Academics: Courses / Update Non-Academics: Courses · [source site](https://api-docs.veracross.com/)

---


# Update Non-Academics: Courses


## PATCH `/non-academics/courses/{id}`


Update Non-Academics: Courses


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Internal Course ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Internal Course ID |
| `course_id` | string <small>max 15</small> |  | Course ID |
| `name` | string <small>max 100</small> |  | Course Name |
| `subject_id` | integer |  | Subject ID |
| `subject_description` | string <small>max 50</small> |  | Description |
| `department_id` | integer <small>read-only</small> |  | ID |
| `department_description` | string <small>max 100</small> |  | Description |
| `catalog_title` | string <small>max 100</small> |  | Catalog Title |
| `catalog_description` | string <small>max 8000</small> |  | Catalog Description |
| `classification` | integer |  | Classification |
| `course_type` | integer |  | Course Type |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
