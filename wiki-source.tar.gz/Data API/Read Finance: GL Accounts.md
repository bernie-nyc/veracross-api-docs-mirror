> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Finance: GL Accounts / Read Finance: GL Accounts · [source site](https://api-docs.veracross.com/)

---


# Read Finance: GL Accounts


## GET `/finance/gl_accounts/{id}`


Read Finance: GL Accounts


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | GL Account Key |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `gl_account_id` | integer <small>read-only</small> | yes | GL Account Key |
| `gl_number` | string <small>max 15</small> | yes | GL Number |
| `gl_account_name` | string <small>max 200</small> | yes | GL Account Name |
| `gl_account_full_name` | string <small>read-only</small> | yes | GL Account |
| `gl_account_long_description` | string <small>read-only</small> | yes | Long Description |
| `gl_fund` | string <small>read-only</small> | yes | GL Fund |
| `gl_fund_id` | integer | yes | GL Fund ID |
| `gl_base_account_id` | integer | yes | GL Base Acct #  GL Base Account presented as a pure integer value |
| `gl_base_account` | string <small>max 80</small> | yes | GL Base Name |
| `gl_cost_center` | integer | yes | GL CC |
| `gl_sub_account` | integer | yes | GL Sub-Account |
| `account_type_2` | integer | yes | Account Type 2  Secondary classification code for grouping common accounts. |
| `account_type` | integer | yes | Account Type  Classification code for grouping common accounts |
| `account_type_3` | integer | yes | Account Type 3  Classification code for grouping common accounts. |
| `current_fiscal_year` | integer <small>read-only</small> | yes | Current Fiscal Year |
| `accounting_period` | integer <small>read-only</small> | yes | Accounting Period |
| `ytd_budget_num_1` | number <small>read-only</small> | yes | YTD Budget #1  Sum of the period budgets on a year-to-date basis for Budget #1. |
| `annual_budget_num_1` | number <small>read-only</small> | yes | Annual Budget #1  Sum of period budgets for a complete Fiscal Year for Budget #1. |
| `budget_remaining` | number <small>read-only</small> | yes | Budget Remaining  Annual Budget #1 less Current Encumbered Amount (YTD posted + PO Open Commit) |
| `posting_type` | integer | yes | Posting Type |
| `posting_prohibited` | boolean | yes | Posting Prohibited? |
| `billing_subledger` | boolean | yes | Billing Subledger |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
