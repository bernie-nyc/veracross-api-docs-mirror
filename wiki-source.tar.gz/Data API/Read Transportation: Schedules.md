> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Transportation: Schedules / Read Transportation: Schedules · [source site](https://api-docs.veracross.com/)

---


# Read Transportation: Schedules


## GET `/transportation/schedules/{id}`


Read Transportation: Schedules


Default Filters:
1) `school_year` =  {current_school_year}

Default Sorting:
1) `person_name` (asc)
2) `school_year` (asc)
3) `grading_period` (asc)
4) `day` (asc)
5) `am_pm` (asc)


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `person_name` | string <small>read-only</small> | yes | Person |
| `name` | object | yes |  |
| `current_grade` | integer | yes | Current Grade |
| `school_year` | integer | yes | School Year  In most circumstances, the value in this field should be the Current School Year; but this field allows you to set up routes that run during a different &quot;Year,&quot; such as Summer routes. |
| `grading_period` | integer | yes | Grading Period  In most circumstances, the value in this field should be Grading Period ALL. But, if your routes need to change at the end of a grading period, you can set up those routes far in advance by selecting a Grading Period. |
| `day` | integer | yes | Day |
| `am_pm` | integer | yes | AM/PM |
| `pick_up_drop_off_time` | string | yes | PU/Drop-Off Time  Specify an early/late arrival/departure time. Only to be used if the Pick Up / Drop off time for a student should deviate from the time specified on the Stop. |
| `transportation_method` | integer | yes | Transportation Method |
| `bus_route` | integer | yes | Bus Route |
| `bus_stop` | string | yes | Bus Stop |
| `bus_stop_time` | string <small>read-only</small> | yes | Time |
| `bus_zone` | integer | yes | Bus Zone |
| `carpool` | string <small>read-only</small> | yes | Carpool |
| `after_school_class` | string <small>read-only</small> | yes | After School Class |
| `after_school_activity_type` | integer | yes | Activity  Specify any activity the student is involved in which affects transportation |
| `notes` | string <small>max 255</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
