> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Transcripts: Transcript Items / List Transcripts: Transcript Items · [source site](https://api-docs.veracross.com/)

---


# List Transcripts: Transcript Items


## GET `/transcripts/{person_id}/transcript_items`


List Transcripts: Transcript Items


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_year` | integer |  | Year |
| `grading_period` | integer |  | Grading Period  Includes the All grading period, and all grading periods that are marked &#39;Post to Transcript.&#39; Sorted by grading period sort key. |
| `enrollment_level` | integer |  | Enrollment Level |
| `grade_level` | integer |  | Grade Level |
| `honors` | boolean |  | Honors  Indicates that this student is taking a &quot;normal&quot; class as honors |
| `transfer_school_id` | integer |  | Organization ID  Organization ID |
| `transfer_school_legacy_id` | string |  | Legacy ID  System ID for this organization in legacy system |
| `subject_id` | integer |  | Subject ID |
| `transfer` | boolean |  | Transfer |
| `ap` | boolean |  | AP |
| `include_in_gpa` | boolean |  | Include in GPA  Whether the transcript course is marked as &#39;Include In GPA&#39; |
| `class_enrollment_id` | string |  | Class Enrollment |
| `on_or_after_credit_completion_date` | string |  | Credit Completion Date |
| `on_or_before_credit_completion_date` | string |  | Credit Completion Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Transcript Item ID |
| `official_transcript_record_id` | integer | yes | Transcript ID |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `school_year` | integer | yes | Year |
| `grading_period` | integer | yes | Grading Period  Includes the All grading period, and all grading periods that are marked &#39;Post to Transcript.&#39; Sorted by grading period sort key. |
| `enrollment_level` | integer | yes | Enrollment Level |
| `grade_level` | integer | yes | Grade Level |
| `numeric_grade` | number | yes | Numeric Grade  The official posted grade that appears on the transcript. |
| `letter_grade` | string <small>read-only</small> | yes | Grade (alpha) |
| `grade_conversion_scale_id` | integer | yes | Grade Conversion Scale |
| `grade_status` | integer | yes | Status  The status for this transcript record |
| `gpa_points` | string <small>read-only</small> | yes | Grade (gpa points) |
| `credits_attempted` | number | yes | Credits Attempted |
| `credits_earned` | number | yes | Credits Earned |
| `credit_completion_date` | string | yes | Credit Completion Date |
| `honors` | boolean | yes | Honors  Indicates that this student is taking a &quot;normal&quot; class as honors |
| `transfer_school_id` | integer <small>read-only</small> | yes | Organization ID  Organization ID |
| `transfer_school_legacy_id` | string <small>max 50</small> | yes | Legacy ID  System ID for this organization in legacy system |
| `transfer_school` | string | yes | School |
| `subject` | object | yes |  |
| `transcript_course` | object | yes |  |
| `related_class` | object | yes |  |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
