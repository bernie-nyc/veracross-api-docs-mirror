> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Athletics: Rosters / Create Athletics: Rosters · [source site](https://api-docs.veracross.com/)

---


# Create Athletics: Rosters


## POST `/athletics/rosters`


Create Athletics: Rosters


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Enrollment ID |
| `internal_class_id` | integer | yes | Internal Class ID |
| `person_id` | integer | yes | Person ID |
| `first_name` | string <small>max 50</small> |  | First Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `suffix` | integer |  | Name Suffix |
| `grade_level_id` | integer |  | Grade Level |
| `currently_enrolled` | boolean |  | Currently Enrolled  A read-only calculated field, this field indicates whether the student is currently enrolled in the class. It is based on a combination of the &quot;Late Date Enrolled&quot; and &quot;Date Withdrawn&quot; fields.    For Classes with a waitlist, if the student is on the waitlist, this field will also report they are not in the class. |
| `late_date_enrolled` | string |  | Late Date Enrolled  The date the student enrolled in the class |
| `date_withdrawn` | string |  | Date Withdrawn  The date the student withdrew from the class |
| `level` | integer |  | Enrollment Level  The enrollment level is used when some students are taking the class for a different level of credit than other students. If all students are taking the course for the same level of credit, setting the enrollment level is NOT necessary. If the student&#39;s enrollment level should influence GPA, please review &quot;override grade conversion scale&quot; on the student&#39;s class enrollment record. |
| `jersey_size` | integer |  | Jersey Size |
| `jersey_number` | string <small>max 3</small> |  | Jersey # |
| `position` | string <small>max 20</small> |  | Position |
| `height` | string <small>max 8</small> |  | Height |
| `weight` | string <small>max 10</small> |  | Weight |
| `captain` | boolean |  | Captain |
| `lettered` | boolean |  | Lettered |
| `exclude_from_transcript` | boolean |  | Exclude From Transcript  Excludes posted grades for this enrollment from being posted to the transcript.  Selecting this option does NOT impact this student&#39;s GPA. |
| `notes` | string <small>max 1000</small> |  | Notes |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
