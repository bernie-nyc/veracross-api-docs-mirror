> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Extended Care: Class Attendance / Read Extended Care: Class Attendance · [source site](https://api-docs.veracross.com/)

---


# Read Extended Care: Class Attendance


## GET `/extended_care/classes/{internal_class_id}/attendance/{id}`


Read Extended Care: Class Attendance


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | ECA ID |
| `internal_class_id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ECA ID |
| `attendance_date` | string | yes | Attendance Date |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `scheduled` | boolean | yes | Scheduled |
| `expected` | boolean | yes | Expected |
| `registered` | boolean <small>read-only</small> | yes | Registered |
| `present` | boolean | yes | Present |
| `time_in` | string | yes | Time In |
| `time_out` | string | yes | Time Out |
| `out` | boolean | yes | Out |
| `time_spent` | number <small>read-only</small> | yes | Time Spent |
| `notes` | string <small>max 100</small> | yes | Notes |
| `attendance_notes` | string <small>read-only</small> | yes | Attendance Notes |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
