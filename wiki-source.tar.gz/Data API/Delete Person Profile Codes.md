> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Person Profile Codes / Delete Person Profile Codes · [source site](https://api-docs.veracross.com/)

---


# Delete Person Profile Codes


## DELETE `/person_profile_codes/{id}`


Delete Person Profile Codes


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Profile Code ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
