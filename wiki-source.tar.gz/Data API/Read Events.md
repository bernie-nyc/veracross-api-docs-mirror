> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Events / Read Events · [source site](https://api-docs.veracross.com/)

---


# Read Events


## GET `/events/group_events/{event_id}`


Read Events


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `event_id` | integer | yes | Event ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Event ID |
| `description` | string <small>max 200</small> | yes | Description |
| `location` | string <small>max 255</small> | yes | Location |
| `virtual_location_url` | string | yes | Virtual Location URL |
| `depart_from` | string <small>max 50</small> | yes | Depart From |
| `google_map` | string <small>read-only</small> | yes | Map |
| `google_directions_from_school` | string <small>read-only</small> | yes | Directions from School |
| `campus_id` | integer | yes | Campus |
| `campus_description` | string <small>read-only</small> | yes | Campus Description |
| `internal_group_id` | integer | yes | Internal Group ID |
| `group_description` | string <small>read-only</small> | yes | Primary Group Name |
| `groups` | string <small>read-only</small> | yes | Groups Included |
| `student_group_id` | integer | yes | Student Group |
| `student_group_description` | string <small>read-only</small> | yes | Student Group Description |
| `contact_person_id` | integer | yes | Contact Person ID |
| `contact_person_name` | string <small>read-only</small> | yes | First Last |
| `event_type_id` | integer | yes | Event Type |
| `event_type_description` | string <small>read-only</small> | yes | Event Type Description |
| `event_status_id` | integer | yes | Event Status |
| `event_status_description` | string <small>read-only</small> | yes | Event Status Description |
| `grade_level` | integer | yes | Grade Level  The grade level associated with this event.    Within the context of parent/teacher conferences, this field is used in conjunction with the School Level field to determine who is eligible to sign up for a conference. Example: if School Level = Upper School and Grade Level = Grade 8, any parent of a student in Upper School OR Grade 8 is eligible to sign up for the conference slot. |
| `school_level_id` | integer | yes | School Level  The school level associated with this event.    Within the context of parent/teacher conferences, this field is used in conjunction with the Grade Level field to determine who is eligible to sign up for a conference. Example: if School Level = Upper School and Grade Level = Grade 8, any parent of a student in Upper School OR Grade 8 is eligible to sign up for the conference slot. |
| `school_level_description` | string <small>read-only</small> | yes | School Level Description |
| `start_date` | string | yes | Start Date |
| `end_date` | string <small>max 10</small> | yes | End Date |
| `start_time` | string <small>max 8</small> | yes | Start Time |
| `end_time` | string <small>max 8</small> | yes | End Time |
| `update_date` | string | yes | Update Date |
| `url` | string <small>max 100</small> | yes | URL |
| `notes` | string <small>max 1000</small> | yes | Notes |
| `catering_notes` | string <small>max 1000</small> | yes | Catering Notes |
| `av_notes` | string <small>max 1000</small> | yes | Audio/Visual Notes |
| `maintenance_notes` | string <small>max 1000</small> | yes | Maintenance Notes |
| `cleaning_notes` | string <small>max 1000</small> | yes | Cleaning Notes |
| `security_notes` | string <small>max 1000</small> | yes | Security Notes |
| `follow_up_notes` | string <small>max 1000</small> | yes | Follow Up Notes |
| `resource_id` | integer <small>read-only</small> | yes | Resource ID (First Created) |
| `public` | boolean | yes | Display On Public Calendar |
| `series_template` | boolean | yes | Series Master Event  If selected, individual events will be created for each day that the event takes place |
| `attendance_taken` | integer | yes | Attendance Taken |
| `campus_departure_time` | string <small>max 8</small> | yes | Campus Departure Time |
| `campus_return_time` | string <small>max 8</small> | yes | Campus Return Time |
| `class_attendance_status` | integer | yes | Class Attendance Status  The class attendance status that will be used for students who participate in this event. This value will be applied to class attendance for all the classes affected by this event between Class Departure Time and Campus Return Time. |
| `class_departure_time` | string <small>max 8</small> | yes | Class Departure Time |
| `daily_attendance_status` | integer | yes | Daily Attendance Status  The daily attendance status that will be used for students who participate in this event. This value will be applied to daily attendance for all the students affected by this event. Leaving this value set as &quot;none specified&quot; will leave the daily attendance status as &quot;Present&quot; for all the students. |
| `display_on_alumni_calendar` | boolean | yes | Display On Alumni Calendar |
| `display_on_group_members_calendar` | boolean | yes | Display On Group Members Calendar |
| `display_on_parent_calendar` | boolean | yes | Display On Parent Calendar |
| `display_on_staff_faculty_calendar` | boolean | yes | Display On Staff/Faculty Calendar |
| `display_on_student_calendar` | boolean | yes | Display On Student Calendar |
| `internal_location_resource_id` | integer | yes | Internal Location Resource ID |
| `venue_departure_time` | string <small>max 8</small> | yes | Venue Departure Time |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
