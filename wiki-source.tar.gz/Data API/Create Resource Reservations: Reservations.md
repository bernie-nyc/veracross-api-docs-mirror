> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Resource Reservations: Reservations / Create Resource Reservations: Reservations · [source site](https://api-docs.veracross.com/)

---


# Create Resource Reservations: Reservations


## POST `/resource_reservations/reservations`


Create Resource Reservations: Reservations


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `resource_reservation_id` | integer <small>read-only</small> |  | Reservation ID |
| `reservation_description` | string <small>read-only</small> |  | Description |
| `event_id` | integer |  | Event ID |
| `start_date` | string |  | Start Date  (includes the day abbreviation) |
| `end_date` | string |  | End Date |
| `start_time` | string |  | Start Time |
| `end_time` | string |  | End Time |
| `resource_id` | integer | yes | Resource ID |
| `resource_category` | integer |  | Resource Category |
| `requesting_person_id` | string |  | Requesting Person ID |
| `conflict` | boolean <small>read-only</small> |  | Conflict |
| `approval_status` | integer |  | Approval Status |
| `notes` | string <small>max 1000</small> |  | Notes |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
