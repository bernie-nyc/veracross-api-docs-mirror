> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Resource Reservations: Reservations / Read Resource Reservations: Reservations · [source site](https://api-docs.veracross.com/)

---


# Read Resource Reservations: Reservations


## GET `/resource_reservations/reservations/{id}`


Read Resource Reservations: Reservations


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Reservation ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `resource_reservation_id` | integer <small>read-only</small> | yes | Reservation ID |
| `reservation_description` | string <small>read-only</small> | yes | Description |
| `event_id` | integer | yes | Event ID |
| `event_description` | string <small>max 200</small> <small>read-only</small> | yes | Event Description |
| `start_date` | string | yes | Start Date  (includes the day abbreviation) |
| `end_date` | string | yes | End Date |
| `start_time` | string | yes | Start Time |
| `end_time` | string | yes | End Time |
| `resource_id` | integer | yes | Resource ID |
| `resource_description` | string <small>max 100</small> <small>read-only</small> | yes | Resource Description |
| `resource_category` | integer | yes | Resource Category |
| `resource_abbreviation` | string <small>max 20</small> | yes | Abbreviation |
| `requesting_person_id` | string | yes | Requesting Person ID |
| `conflict` | boolean <small>read-only</small> | yes | Conflict |
| `approval_status` | integer | yes | Approval Status |
| `notes` | string <small>max 1000</small> | yes | Notes |
| `event_type` | integer | yes | Event Type |
| `requesting_person_name` | string <small>read-only</small> | yes | Requesting Person |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
