> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Configuration - Grade Levels / List Academics: Configuration - Grade Levels · [source site](https://api-docs.veracross.com/)

---


# List Academics: Configuration - Grade Levels


## GET `/academics/config/grade_levels`


List Academics: Configuration - Grade Levels


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_level` | integer |  | School Level |
| `active` | boolean |  | Active |
| `obsolete` | boolean |  | Obsolete |
| `allow_re_enrollment` | boolean |  | Allow Re Enrollment  Are students allowed to re-enroll IN to this grade level? |
| `student_portal_enabled` | boolean |  | Student Portal Enabled |
| `enable_portal_schedules` | boolean |  | Enable Portal Schedules  If checked, allows parents and students to see the student&#39;s PDF schedule and enrolled classes in their portals.    If unchecked, prevents parents and students from seeing the PDF schedule and enrolled classes in their portals. |
| `enable_portal_schedules_summer` | boolean |  | Enable Portal Schedules (Summer) |
| `enable_portal_attendance_reports` | boolean |  | Enable Portal Attendance Reports |
| `display_course_enrollment_document` | boolean |  | Display Course Enrollment Document |
| `include_in_parent_teacher_conferences` | boolean |  | Include in Parent/Teacher Conferences  Determines whether students who are currently enrolled in this grade level are available in the parent portal for teacher conference signups. |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | ID |
| `school_level` | integer | yes | School Level |
| `grade_level` | string <small>max 40</small> | yes | Grade Level |
| `long_description` | string <small>max 40</small> | yes | Long Description |
| `abbreviation` | string <small>max 10</small> | yes | Abbreviation |
| `grade_index` | integer | yes | Grade Index |
| `years_to_graduation` | integer | yes | Years To Graduation |
| `primary_block_group` | integer | yes | Primary Block Group |
| `active` | boolean | yes | Active |
| `obsolete` | boolean | yes | Obsolete |
| `allow_re_enrollment` | boolean | yes | Allow Re Enrollment  Are students allowed to re-enroll IN to this grade level? |
| `student_portal_enabled` | boolean | yes | Student Portal Enabled |
| `enable_portal_schedules` | boolean | yes | Enable Portal Schedules  If checked, allows parents and students to see the student&#39;s PDF schedule and enrolled classes in their portals.    If unchecked, prevents parents and students from seeing the PDF schedule and enrolled classes in their portals. |
| `enable_portal_schedules_summer` | boolean | yes | Enable Portal Schedules (Summer) |
| `enable_portal_attendance_reports` | boolean | yes | Enable Portal Attendance Reports |
| `display_course_enrollment_document` | boolean | yes | Display Course Enrollment Document |
| `include_in_parent_teacher_conferences` | boolean | yes | Include in Parent/Teacher Conferences  Determines whether students who are currently enrolled in this grade level are available in the parent portal for teacher conference signups. |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
