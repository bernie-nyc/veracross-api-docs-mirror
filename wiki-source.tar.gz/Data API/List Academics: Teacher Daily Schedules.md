> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Academics: Teacher Daily Schedules / List Academics: Teacher Daily Schedules · [source site](https://api-docs.veracross.com/)

---


# List Academics: Teacher Daily Schedules


## GET `/academics/teacher_daily_schedules`


List Academics: Teacher Daily Schedules


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |
| `record_type` | string |  | Record Type |
| `calendar_date` | string |  | Calendar Date |
| `on_or_after_calendar_date` | string |  | Calendar Date |
| `on_or_before_calendar_date` | string |  | Calendar Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |
| `record_id` | integer | yes | Record ID  Record ID of the associated record, based on the &quot;record type&quot; of the schedule item. Record type MUST be used in tandem with the ID value as follows:    Class: The internal class ID of the class represented by the schedule item.    Universal Block: The period ID of the universal block represented by the schedule item.    Personal Event: The group event ID of the group event represented by the schedule item.    Event: The group event ID of the group event represented by the schedule item. |
| `record_type` | string <small>max 15</small> | yes | Record Type |
| `calendar_date` | string | yes | Calendar Date |
| `start_time` | string <small>read-only</small> | yes | Start Time |
| `end_time` | string <small>read-only</small> | yes | End Time |
| `item_type` | string <small>max 50</small> | yes | Item Type |
| `item_description` | string <small>max 200</small> | yes | Item Description |
| `day_description` | string <small>max 103</small> | yes | Day Description |
| `period` | string <small>max 50</small> | yes | Period |
| `period_abbreviation` | string <small>max 6</small> | yes | Period Abbreviation |
| `item_location` | string <small>max 255</small> | yes | Item Location |
| `item_status` | string <small>max 16</small> | yes | Schedule Item Status |
| `virtual_meeting_url` | string <small>max 2000</small> | yes | Virtual Meeting Url |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
