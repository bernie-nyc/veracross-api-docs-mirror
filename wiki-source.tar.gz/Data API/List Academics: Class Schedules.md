> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Class Schedules / List Academics: Class Schedules · [source site](https://api-docs.veracross.com/)

---


# List Academics: Class Schedules


## GET `/academics/class_schedules`


List Academics: Class Schedules


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `school_level` | integer |  | School Level |
| `school_year` | integer |  | School Year |
| `block_group` | integer |  | Block Group |
| `room_id` | integer |  | Room (Class Sched)  Can be used as an override for the class &quot;Room&quot; if the class meets in different rooms depending on the day. |
| `campus_id` | integer |  | Campus ID |
| `grading_period_id` | integer |  | Grading Period |
| `day_id` | integer |  | Day |
| `block_id` | integer |  | Block |
| `primary_teacher_id` | integer |  | Teacher ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Class Schedule ID |
| `internal_class_id` | integer <small>read-only</small> | yes | Internal Class ID |
| `class_id` | string <small>max 20</small> | yes | Class ID  Class ID associated with this class. School-defined value. Must be unique in the school year. Special characters, punctuation, and spaces are not sufficient for uniqueness.     Example: GYM 1 and GYM: 1 are not unique. GYM 1a and GYM 1b are unique. |
| `primary_teacher_id` | integer | yes | Teacher ID |
| `primary_teacher_name` | string <small>read-only</small> | yes | Teacher |
| `campus_id` | integer | yes | Campus ID |
| `campus_description` | string <small>max 50</small> | yes | Description |
| `school_level` | integer | yes | School Level |
| `school_year` | integer | yes | School Year |
| `grading_period` | object | yes |  |
| `day` | object | yes |  |
| `block_group` | integer | yes | Block Group |
| `block` | object | yes |  |
| `room` | object | yes |  |
| `start_time` | string | yes | Start Time |
| `end_time` | string | yes | End Time |
| `override_start_time` | string | yes | Start Time (Override)  An override start time may be entered for classes that are scheduled without Blocks; or an override start time may be entered in order to specify a deviation from the Block&#39;s scheduled time |
| `override_end_time` | string | yes | End Time (Override)  An override end time may be entered for classes that are scheduled without Blocks; or an override end time may be entered in order to specify a deviation from the Block&#39;s scheduled time |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
