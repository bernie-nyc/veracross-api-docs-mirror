> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Calendars: Student Calendars / List Calendars: Student Calendars · [source site](https://api-docs.veracross.com/)

---


# List Calendars: Student Calendars


## GET `/calendars/student_calendars/{person_id}`


List Calendars: Student Calendars


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `event_type` | integer |  | Event Type |
| `on_or_before_update_date` | string |  | Update Date |
| `on_or_after_update_date` | string |  | Update Date |
| `on_or_before_start_date` | string |  | Start Date |
| `on_or_after_start_date` | string |  | Start Date |
| `on_or_before_end_date` | string |  | End Date |
| `on_or_after_end_date` | string |  | End Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |
| `event_id` | integer <small>read-only</small> | yes | Event ID |
| `event_type_id` | integer | yes | Event Type |
| `event_type_description` | string <small>max 50</small> | yes | Event Type Description |
| `start_date` | string <small>read-only</small> | yes | Start Date |
| `end_date` | string <small>read-only</small> | yes | End Date |
| `start_time` | string | yes | Start Time |
| `end_time` | string | yes | End Time |
| `location` | string <small>max 255</small> | yes | Location |
| `description` | string <small>max 200</small> | yes | Description |
| `notes` | string <small>max 1000</small> | yes | Notes |
| `contact_person_id` | integer | yes | Contact Person ID |
| `contact_person_name` | string <small>read-only</small> | yes | First Last  The full name of an individual in &lt;first name&gt; &lt;last name&gt; notation |
| `game_outcome_id` | integer | yes | Game Outcome |
| `game_outcome_description` | string <small>max 40</small> | yes | Game Outcome Description |
| `internal_team_id` | integer | yes | Internal Team ID |
| `team_description` | string <small>max 80</small> | yes | Team Description |
| `update_date` | string | yes | Update Date |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
