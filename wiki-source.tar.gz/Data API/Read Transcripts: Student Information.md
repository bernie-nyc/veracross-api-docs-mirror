> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Transcripts: Student Information / Read Transcripts: Student Information · [source site](https://api-docs.veracross.com/)

---


# Read Transcripts: Student Information


## GET `/transcripts/student_info/{person_id}`


Read Transcripts: Student Information


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Transcript ID |
| `student_id` | integer <small>read-only</small> | yes | Person ID |
| `student_name` | object | yes |  |
| `student_address` | object <small>read-only</small> | yes |  |
| `gender` | integer <small>read-only</small> | yes | Gender |
| `date_of_birth` | string <small>read-only</small> | yes | Birthday (verbose)  a text field for displaying the date in the format of January 5, 2003 |
| `current_grade` | integer <small>read-only</small> | yes | Current Grade |
| `graduation_year` | integer <small>read-only</small> | yes | Graduation Year |
| `entry_date` | string | yes | Entry Date  This is the original date on which the student started school. Should be the first day of the school year for new students, or a date during the school year for mid-year enrollees. |
| `graduation_date` | string | yes | Graduation Date |
| `exit_date` | string | yes | Exit Date  The last day the student was in school. Should be either the last day of the school year, or last day the student was in class. |
| `transfer_student` | boolean <small>read-only</small> | yes | Transfer Student |
| `transcript_notes` | string | yes | Notes |
| `parent_1_id` | integer <small>read-only</small> | yes | Person ID |
| `parent_2_id` | integer <small>read-only</small> | yes | Person ID |
| `parent_3_id` | integer <small>read-only</small> | yes | Person ID |
| `parent_4_id` | integer <small>read-only</small> | yes | Person ID |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
