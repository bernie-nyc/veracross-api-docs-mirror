> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Directory: Staff/Faculty / List Directory: Staff/Faculty · [source site](https://api-docs.veracross.com/)

---


# List Directory: Staff/Faculty


## GET `/directory/staff_faculty`


List Directory: Staff/Faculty


The List Directory: Staff/Faculty endpoint mirrors the information shown for directory entries in the general Staff/Faculty directory in the portals. Information is automatically refreshed nightly or by manually running the "Refresh Directory Entries" action item on the directory.


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer |  | Person ID |
| `first_name` | string |  | Person Entry Filter First Names |
| `last_name` | string |  | Person Entry Filter Last Names |
| `names` | string |  | Person Entry Filter Names |
| `campus` | string |  | Person Campus |
| `department` | string |  | Person Department |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |
| `entry_sort_name` | string <small>max 500</small> | yes | Entry Sort Name |
| `full_name` | string <small>max 500</small> | yes | Person Full Name |
| `first_name` | string <small>max 1000</small> | yes | Person Entry Filter First Names |
| `last_name` | string <small>max 1000</small> | yes | Person Entry Filter Last Names |
| `names` | string <small>read-only</small> | yes | Person Entry Filter Names |
| `photo_url` | string | yes | Person Photo URL |
| `job_title` | string <small>max 200</small> | yes | Person Job Title |
| `room` | string <small>max 100</small> | yes | Person Room |
| `campus` | string <small>max 4000</small> | yes | Person Campus |
| `school_level` | string <small>max 4000</small> | yes | Person School Level |
| `faculty_type` | string <small>max 4000</small> | yes | Person Faculty Type |
| `department` | string <small>max 4000</small> | yes | Person Department |
| `biography` | string <small>max 4000</small> | yes | Person Biography |
| `email` | string <small>max 100</small> | yes | Person Email |
| `email_2` | string <small>max 100</small> | yes | Person Email 2 |
| `phone_business` | string <small>max 50</small> | yes | Person Phone Business |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
