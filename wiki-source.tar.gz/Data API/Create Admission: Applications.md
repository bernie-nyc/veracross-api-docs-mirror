> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Admission: Applications / Create Admission: Applications · [source site](https://api-docs.veracross.com/)

---


# Create Admission: Applications


## POST `/admission/applications`


Create Admission: Applications


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `application_id` | integer <small>read-only</small> |  | Application ID |
| `applicant_id` | integer | yes | Applicant ID |
| `year_applying_for` | integer | yes | Year Applying For |
| `month_applying_for` | integer |  | Month Applying For |
| `grade_applying_for` | integer | yes | Grade Applying For |
| `resident_status_applying_for` | integer | yes | Resident Status Applying For |
| `campus_applying_for` | integer | yes | Campus Applying For |
| `student_group_applying_for` | integer | yes | Student Group Applying For |
| `admission_source` | integer | yes | Admission Source |
| `candidate_pool` | integer | yes | Candidate Pool |
| `admission_lead_date` | string |  | Admission Lead Date |
| `inquiry_date` | string |  | Inquiry Date |
| `visit_date` | string |  | Visit Date |
| `application_date` | string |  | Application Date |
| `requesting_financial_aid` | boolean |  | Requesting Financial Aid |
| `application_status` | integer |  | Application Status |
| `application_decision_date` | string |  | Application Decision Date |
| `application_decision_response` | integer |  | Application Decision Response |
| `application_decision_response_date` | string |  | Application Decision Response Date |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
