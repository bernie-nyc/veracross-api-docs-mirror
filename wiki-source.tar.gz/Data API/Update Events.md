> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Events / Update Events · [source site](https://api-docs.veracross.com/)

---


# Update Events


## PATCH `/events/group_events/{event_id}`


Update Events


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `event_id` | integer | yes | Event ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Event ID |
| `description` | string <small>max 200</small> |  | Description |
| `location` | string <small>max 255</small> |  | Location |
| `virtual_location_url` | string |  | Virtual Location URL |
| `depart_from` | string <small>max 50</small> |  | Depart From |
| `google_map` | string <small>read-only</small> |  | Map |
| `google_directions_from_school` | string <small>read-only</small> |  | Directions from School |
| `campus_id` | integer |  | Campus |
| `campus_description` | string <small>read-only</small> |  | Campus Description |
| `internal_group_id` | integer |  | Internal Group ID |
| `group_description` | string <small>read-only</small> |  | Primary Group Name |
| `groups` | string <small>read-only</small> |  | Groups Included |
| `student_group_id` | integer |  | Student Group |
| `student_group_description` | string <small>read-only</small> |  | Student Group Description |
| `contact_person_id` | integer |  | Contact Person ID |
| `contact_person_name` | string <small>read-only</small> |  | First Last |
| `event_type_id` | integer |  | Event Type |
| `event_type_description` | string <small>read-only</small> |  | Event Type Description |
| `event_status_id` | integer |  | Event Status |
| `event_status_description` | string <small>read-only</small> |  | Event Status Description |
| `grade_level` | integer |  | Grade Level  The grade level associated with this event.    Within the context of parent/teacher conferences, this field is used in conjunction with the School Level field to determine who is eligible to sign up for a conference. Example: if School Level = Upper School and Grade Level = Grade 8, any parent of a student in Upper School OR Grade 8 is eligible to sign up for the conference slot. |
| `school_level_id` | integer |  | School Level  The school level associated with this event.    Within the context of parent/teacher conferences, this field is used in conjunction with the Grade Level field to determine who is eligible to sign up for a conference. Example: if School Level = Upper School and Grade Level = Grade 8, any parent of a student in Upper School OR Grade 8 is eligible to sign up for the conference slot. |
| `school_level_description` | string <small>read-only</small> |  | School Level Description |
| `start_date` | string |  | Start Date |
| `end_date` | string <small>max 10</small> |  | End Date |
| `start_time` | string <small>max 8</small> |  | Start Time |
| `end_time` | string <small>max 8</small> |  | End Time |
| `update_date` | string |  | Update Date |
| `url` | string <small>max 100</small> |  | URL |
| `notes` | string <small>max 1000</small> |  | Notes |
| `catering_notes` | string <small>max 1000</small> |  | Catering Notes |
| `av_notes` | string <small>max 1000</small> |  | Audio/Visual Notes |
| `maintenance_notes` | string <small>max 1000</small> |  | Maintenance Notes |
| `cleaning_notes` | string <small>max 1000</small> |  | Cleaning Notes |
| `security_notes` | string <small>max 1000</small> |  | Security Notes |
| `follow_up_notes` | string <small>max 1000</small> |  | Follow Up Notes |
| `resource_id` | integer <small>read-only</small> |  | Resource ID (First Created) |
| `public` | boolean |  | Display On Public Calendar |
| `series_template` | boolean |  | Series Master Event  If selected, individual events will be created for each day that the event takes place |
| `attendance_taken` | integer |  | Attendance Taken |
| `campus_departure_time` | string <small>max 8</small> |  | Campus Departure Time |
| `campus_return_time` | string <small>max 8</small> |  | Campus Return Time |
| `class_attendance_status` | integer |  | Class Attendance Status  The class attendance status that will be used for students who participate in this event. This value will be applied to class attendance for all the classes affected by this event between Class Departure Time and Campus Return Time. |
| `class_departure_time` | string <small>max 8</small> |  | Class Departure Time |
| `daily_attendance_status` | integer |  | Daily Attendance Status  The daily attendance status that will be used for students who participate in this event. This value will be applied to daily attendance for all the students affected by this event. Leaving this value set as &quot;none specified&quot; will leave the daily attendance status as &quot;Present&quot; for all the students. |
| `display_on_alumni_calendar` | boolean |  | Display On Alumni Calendar |
| `display_on_group_members_calendar` | boolean |  | Display On Group Members Calendar |
| `display_on_parent_calendar` | boolean |  | Display On Parent Calendar |
| `display_on_staff_faculty_calendar` | boolean |  | Display On Staff/Faculty Calendar |
| `display_on_student_calendar` | boolean |  | Display On Student Calendar |
| `internal_location_resource_id` | integer |  | Internal Location Resource ID |
| `venue_departure_time` | string <small>max 8</small> |  | Venue Departure Time |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
