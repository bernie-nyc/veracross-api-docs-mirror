> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Report Cards: Daily Attendance / List Report Cards: Daily Attendance · [source site](https://api-docs.veracross.com/)

---


# List Report Cards: Daily Attendance


## GET `/report_cards/students/{person_id}/attendance`


List Report Cards: Daily Attendance


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `grading_period_id` | integer |  | Grading Period ID |
| `school_year` | integer | yes | School Year |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `grading_period_id` | integer | yes | Grading Period ID |
| `school_year` | integer | yes | School Year |
| `absences_all` | number | yes | Absences All |
| `absences_excused` | number | yes | Absences Excused |
| `absences_unexcused` | number | yes | Absences Unexcused |
| `tardies_all` | number | yes | Tardies All |
| `tardies_excused` | number | yes | Tardies Excused |
| `tardies_unexcused` | number | yes | Tardies Unexcused |
| `dismissals_all` | number | yes | Dismissals All |
| `dismissals_excused` | number | yes | Dismissals Excused |
| `dismissals_unexcused` | number | yes | Dismissals Unexcused |
| `days_enrolled` | number | yes | Days Enrolled |
| `days_attended` | number | yes | Days Attended |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
