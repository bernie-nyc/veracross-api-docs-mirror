> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Programs: Enrollments / List Programs: Enrollments · [source site](https://api-docs.veracross.com/)

---


# List Programs: Enrollments


## GET `/programs/enrollments`


List Programs: Enrollments


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer |  | Internal Class ID |
| `person_id` | integer |  | Person ID |
| `exclude_from_transcript` | boolean |  | Exclude From Transcript  Excludes posted grades for this enrollment from being posted to the transcript.  Selecting this option does NOT impact this student&#39;s GPA. |
| `school_year` | integer |  | School Year |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Enrollment ID |
| `internal_class_id` | integer <small>read-only</small> | yes | Internal Class ID |
| `class_description` | string <small>max 80</small> | yes | Description |
| `primary_teacher` | object <small>read-only</small> | yes |  |
| `person_id` | integer <small>read-only</small> | yes | Person ID |
| `grade_level_id` | integer <small>read-only</small> | yes | ID |
| `currently_enrolled` | boolean | yes | Currently Enrolled  A read-only calculated field, this field indicates whether the student is currently enrolled in the class. It is based on a combination of the &quot;Late Date Enrolled&quot; and &quot;Date Withdrawn&quot; fields.    For Classes with a waitlist, if the student is on the waitlist, this field will also report they are not in the class. |
| `late_date_enrolled` | string | yes | Late Date Enrolled  The date the student enrolled in the class |
| `date_withdrawn` | string | yes | Date Withdrawn  The date the student withdrew from the class |
| `level` | integer | yes | Enrollment Level  The enrollment level is used when some students are taking the class for a different level of credit than other students. If all students are taking the course for the same level of credit, setting the enrollment level is NOT necessary. If the student&#39;s enrollment level should influence GPA, please review &quot;override grade conversion scale&quot; on the student&#39;s class enrollment record. |
| `exclude_from_transcript` | boolean | yes | Exclude From Transcript  Excludes posted grades for this enrollment from being posted to the transcript.  Selecting this option does NOT impact this student&#39;s GPA. |
| `notes` | string <small>max 1000</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
