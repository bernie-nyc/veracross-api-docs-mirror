> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Numeric Grades / Update Academics: Numeric Grades · [source site](https://api-docs.veracross.com/)

---


# Update Academics: Numeric Grades


## PATCH `/academics/numeric_grades/{id}`


Update Academics: Numeric Grades


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Grade ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Grade ID |
| `enrollment_id` | integer <small>read-only</small> |  | Enrollment ID |
| `class` | object <small>read-only</small> |  |  |
| `grading_period` | object |  |  |
| `student` | object <small>read-only</small> |  |  |
| `assignment_posted_grade` | number |  | Assignment Posted Grade |
| `assignment_posted_letter_grade` | string <small>read-only</small> |  | Assignment Posted Grade (Letter) |
| `exam_grade` | number |  | Exam Grade |
| `posted_grade` | number |  | Grade: Posted  The official posted grade that appears on the report card |
| `posted_letter_grade` | string <small>read-only</small> |  | Letter Grade (P)  The letter grade equivalent of the posted numeric grade (Grade: P) |
| `status` | integer |  | Status  The status for this report-card record |
| `comment` | string |  | Comments |
| `locked` | boolean |  | Locked  Indicates that the data for this record are locked, and only authorized users can make changes |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
