> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: AP Disbursements / Update Finance: AP Disbursements · [source site](https://api-docs.veracross.com/)

---


# Update Finance: AP Disbursements


## PATCH `/finance/ap_disbursements/{id}`


Update Finance: AP Disbursements


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Disbursement Header |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `disbursement_id` | integer <small>read-only</small> |  | Disbursement Header |
| `description` | string <small>max 80</small> |  | Description |
| `check_reference_number` | integer |  | Check/Reference Number |
| `disbursement_date` | string |  | Disbursement Date |
| `disbursement_category` | integer |  | Disbursement Category |
| `disbursement_type` | integer |  | Disbursement Type |
| `vendor` | string <small>max 200</small> |  | Organization |
| `vendor_id` | integer |  | Vendor ID |
| `cash_gl_account` | string <small>read-only</small> |  | GL Account |
| `cash_gl_account_id` | integer |  | Cash GL Account ID |
| `payee_name` | string <small>max 200</small> |  | Payee Name |
| `amount` | number <small>read-only</small> |  | Amount - Read Only |
| `posting_date` | string <small>read-only</small> |  | Posting Date - Read Only |
| `je_ref_id` | string <small>read-only</small> |  | JE Ref # - Read Only |
| `cleared` | boolean |  | Cleared (H)? |
| `void` | boolean <small>read-only</small> |  | Void? - Read Only |
| `entered_as_void` | boolean <small>read-only</small> |  | Entered As Void? - Read Only |
| `input_date` | string |  | Input Date |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
