> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Directory Preferences: Person / Update Directory Preferences: Person · [source site](https://api-docs.veracross.com/)

---


# Update Directory Preferences: Person


## PATCH `/directory/preferences/people/{id}`


Update Directory Preferences: Person


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Directory Type Preference ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Directory Type Preference ID |
| `person_id` | integer |  | Person ID |
| `person_name` | string <small>read-only</small> |  | Person Name |
| `directory_type` | integer |  | Directory Type |
| `status` | integer |  | Status |
| `parents_display` | integer |  | Parents Display Setting  “Legal Custody” means that the student displays in the in the household of the directory type for any parents with legal custody.    “All Parents” means that the student displays in the household of all parents irrespective of custody. |
| `photo_display` | integer |  | Photo Display Setting |
| `mobile_phone_display` | integer |  | Mobile Phone Display Setting |
| `email_1_display` | integer |  | Email 1 Display Setting |
| `email_2_display` | integer |  | Email 2 Display Setting |
| `business_phone_display` | integer |  | Business Phone Display Setting |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
