> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Development: Gifts / Read Development: Gifts · [source site](https://api-docs.veracross.com/)

---


# Read Development: Gifts


## GET `/development/gifts/{id}`


Read Development: Gifts


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Gift ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Gift ID |
| `gift_type` | integer | yes | Gift Type |
| `constituent_id` | integer | yes | Constituent ID |
| `constituent_name` | string <small>read-only</small> | yes | Constituent |
| `constituent_record_type` | integer | yes | Record Type |
| `person` | object <small>read-only</small> | yes |  |
| `organization` | object | yes |  |
| `date` | string | yes | Date  The date the gift was given |
| `fiscal_year` | integer | yes | Fiscal Year |
| `amount` | number | yes | Amount  The donation or pledge amount |
| `fundraising_activity` | string | yes | Fundraising Activity |
| `fund` | string <small>max 200</small> | yes | Fund Description  For &quot;Development&quot; funds, not &quot;General Ledger&quot; funds |
| `event` | string <small>read-only</small> | yes | Event |
| `apply_to_pledge` | boolean | yes | Apply To Pledge |
| `associated_pledge_gift_id` | integer <small>read-only</small> | yes | Gift ID (Pledge or Associated) |
| `acknowledgement_letter_template` | string <small>read-only</small> | yes | Acknowledgement Letter Template |
| `acknowledgement_date` | string <small>read-only</small> | yes | Acknowledgement Date  The date the pledge acknowledgement letter was printed |
| `thank_you_letter_date` | string <small>read-only</small> | yes | Thank-You Letter Date  The date the donation thank-you letter was printed |
| `anonymous` | boolean | yes | Anonymous |
| `notes` | string | yes | Notes |
| `in_honor_of` | string <small>max 500</small> | yes | In Honor Of |
| `in_memory_of` | string <small>max 500</small> | yes | In Memory Of |
| `payment_method` | integer | yes | Payment Method |
| `payment_category` | integer | yes | Payment Category |
| `reward_amount` | number | yes | Reward Amount  The reward amount for this gift |
| `in_kind_gift_description` | string <small>read-only</small> | yes | In Kind Gift Description |
| `solicitor` | string <small>read-only</small> | yes | Solicitor |
| `batch_id` | string <small>max 20</small> | yes | Batch ID |
| `profile_codes` | string <small>read-only</small> | yes | All Profile Codes |
| `pledge` | object | yes |  |
| `soft_credit_type` | integer | yes | Soft Credit Type  Applies to Soft Credit records only.  Indicates the type of soft credit.  (Not to be confused with the &quot;Soft Credit Given&quot; field) |
| `hard_credit_gift_id` | integer <small>read-only</small> | yes | Hard Credit Gift ID |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
