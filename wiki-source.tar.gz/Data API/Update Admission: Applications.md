> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Admission: Applications / Update Admission: Applications · [source site](https://api-docs.veracross.com/)

---


# Update Admission: Applications


## PATCH `/admission/applications/{application_id}`


Update Admission: Applications


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `application_id` | integer | yes | Application ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `application_id` | integer <small>read-only</small> |  | Application ID |
| `applicant_id` | integer |  | Applicant ID |
| `year_applying_for` | integer |  | Year Applying For |
| `month_applying_for` | integer |  | Month Applying For |
| `grade_applying_for` | integer |  | Grade Applying For |
| `resident_status_applying_for` | integer |  | Resident Status Applying For |
| `campus_applying_for` | integer |  | Campus Applying For |
| `student_group_applying_for` | integer |  | Student Group Applying For |
| `admission_source` | integer |  | Admission Source |
| `candidate_pool` | integer |  | Candidate Pool |
| `admission_lead_date` | string |  | Admission Lead Date |
| `inquiry_date` | string |  | Inquiry Date |
| `visit_date` | string |  | Visit Date |
| `application_date` | string |  | Application Date |
| `requesting_financial_aid` | boolean |  | Requesting Financial Aid |
| `application_status` | integer |  | Application Status |
| `application_decision_date` | string |  | Application Decision Date |
| `application_decision_response` | integer |  | Application Decision Response |
| `application_decision_response_date` | string |  | Application Decision Response Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
