> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Finance: AP Disbursements / Read Finance: AP Disbursements · [source site](https://api-docs.veracross.com/)

---


# Read Finance: AP Disbursements


## GET `/finance/ap_disbursements/{id}`


Read Finance: AP Disbursements


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Disbursement Header |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `disbursement_id` | integer <small>read-only</small> | yes | Disbursement Header |
| `description` | string <small>max 80</small> | yes | Description |
| `check_reference_number` | integer | yes | Check/Reference Number |
| `disbursement_date` | string | yes | Disbursement Date |
| `disbursement_category` | integer | yes | Disbursement Category |
| `disbursement_type` | integer | yes | Disbursement Type |
| `vendor` | string <small>max 200</small> | yes | Organization |
| `vendor_id` | integer | yes | Vendor ID |
| `cash_gl_account` | string <small>read-only</small> | yes | GL Account |
| `cash_gl_account_id` | integer | yes | Cash GL Account ID |
| `payee_name` | string <small>max 200</small> | yes | Payee Name |
| `amount` | number <small>read-only</small> | yes | Amount - Read Only |
| `posting_date` | string <small>read-only</small> | yes | Posting Date - Read Only |
| `je_ref_id` | string <small>read-only</small> | yes | JE Ref # - Read Only |
| `cleared` | boolean | yes | Cleared (H)? |
| `void` | boolean <small>read-only</small> | yes | Void? - Read Only |
| `entered_as_void` | boolean <small>read-only</small> | yes | Entered As Void? - Read Only |
| `input_date` | string | yes | Input Date |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
