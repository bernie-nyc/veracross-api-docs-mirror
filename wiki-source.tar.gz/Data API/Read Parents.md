> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Parents / Read Parents · [source site](https://api-docs.veracross.com/)

---


# Read Parents


## GET `/parents/{id}`


Read Parents


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Person ID |
| `household_id` | integer <small>read-only</small> | yes | Household ID |
| `head_of_household` | boolean | yes | Head of Household  The head-of-household for this individual&#39;s household |
| `name_prefix` | integer | yes | Name Prefix |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `first_nick_name` | string <small>read-only</small> | yes | First Nick Name  The nick-name if present, otherwise first name |
| `preferred_name` | string <small>max 50</small> | yes | Preferred Name |
| `middle_name` | string <small>max 50</small> | yes | Middle Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `name_suffix` | integer | yes | Name Suffix |
| `spouse` | object <small>read-only</small> | yes |  |
| `gender` | integer | yes | Gender |
| `roles` | string <small>read-only</small> | yes | Parent Roles |
| `username` | string <small>max 128</small> | yes | Username |
| `email_1` | string <small>max 100</small> | yes | Email 1  This should be used as the &quot;Preferred&quot; email for email blasts and other electronic correspondence. |
| `email_2` | string <small>max 100</small> | yes | Email 2  This should be used when a supplemental email address is available.  Note that Email 1 is the default for email blasts and other electronic correspondence. |
| `home_phone` | string <small>max 30</small> | yes | Home Phone  This field should always be in sync with the Household phone number. |
| `mobile_phone` | string <small>max 30</small> | yes | Mobile Phone |
| `business_phone` | string <small>max 30</small> | yes | Business Phone |
| `address` | object <small>read-only</small> | yes |  |
| `employer` | string <small>max 200</small> | yes | Employer  This field should be updated by updating data on the person_organization table (on the Organizations tab on the person detail screen) |
| `occupation` | integer | yes | Occupation |
| `job_title` | string <small>max 100</small> | yes | Job Title |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
