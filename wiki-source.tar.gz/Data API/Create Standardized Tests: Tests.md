> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Standardized Tests: Tests / Create Standardized Tests: Tests · [source site](https://api-docs.veracross.com/)

---


# Create Standardized Tests: Tests


## POST `/standardized_tests/tests`


Create Standardized Tests: Tests


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Standardized Test ID |
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `test_type` | integer |  | Test Type  E.g., PSAT, SAT, ACT, TOEFL |
| `test_type_description` | string <small>max 50</small> <small>read-only</small> |  | Description (read-only) |
| `test_year` | integer |  | Test Year  The year the test was taken, entered manually if the exact date is not known. |
| `test_date` | string |  | Test Date  The date the test was taken |
| `grade_level` | integer |  | Grade Level  The grade level of the student at the time of taking the test |
| `course` | integer |  | Course ID |
| `class_enrollment` | string |  | Class Enrollment |
| `test_administered_by` | string <small>max 200</small> |  | Test Administered By |
| `notes` | string |  | Notes |
| `include_in_summary` | boolean |  | Include In Summary |
| `created_date` | string |  | Input Date |
| `last_modified_date` | string |  | Update Date |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
