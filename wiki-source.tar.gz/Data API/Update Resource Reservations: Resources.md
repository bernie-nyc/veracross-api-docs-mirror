> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Resource Reservations: Resources / Update Resource Reservations: Resources · [source site](https://api-docs.veracross.com/)

---


# Update Resource Reservations: Resources


## PATCH `/resource_reservations/resources/{resource_id}`


Update Resource Reservations: Resources


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `resource_id` | integer | yes | Resource ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `resource_id` | integer <small>read-only</small> |  | Resource ID |
| `description` | string <small>max 100</small> |  | Description |
| `abbreviation` | string <small>max 20</small> |  | Abbreviation |
| `resource_type` | integer |  | Resource Type |
| `campus_id` | integer |  | Campus |
| `campus_description` | string <small>max 50</small> |  | Description |
| `building_id` | integer |  | Building |
| `building_description` | string <small>max 100</small> |  | Description |
| `school_level_id` | integer |  | School Level |
| `school_level_description` | string <small>max 50</small> |  | Description |
| `responsible_person_id` | string |  | Responsible Person ID |
| `responsible_person_name` | string <small>read-only</small> |  | Full Name  The full name of an individual in the school-defined format, often &lt;last name&gt;, &lt;first name&gt; |
| `allow_simultaneous_reservations` | integer |  | Allow Simultaneous Reservations |
| `capacity` | integer |  | Capacity  The amount of reservations that can occur at the same time. |
| `hourly_cost` | integer |  | Hourly Cost |
| `reservation_approval_required` | boolean |  | Reservation Approval Required |
| `set_up_time_required_in_mins` | integer |  | Set-Up Time Required  The setup time in minutes required for this resource |
| `tear_down_time_required_in_mins` | integer |  | Tear-Down Time Required  The tear-down time in minutes required for this resource |
| `used_by_athletics` | boolean |  | Used By Athletics |
| `include_on_portals` | boolean |  | Include on Portals |
| `notes` | string <small>max 1000</small> |  | Notes |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
