> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Finance: Vendors / List Finance: Vendors · [source site](https://api-docs.veracross.com/)

---


# List Finance: Vendors


## GET `/finance/vendors`


List Finance: Vendors


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `inactive` | boolean |  | Show inactive vendors? |
| `on_or_after_last_modified_date` | string |  | Last Modified Date |
| `on_or_before_last_modified_date` | string |  | Last Modified Date |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `vendor_id` | integer | yes | Vendor ID |
| `vendor_name` | string <small>max 200</small> | yes | Vendor Name |
| `address_1` | string <small>max 200</small> | yes | Address 1 |
| `address_2` | string <small>max 200</small> | yes | Address 2 |
| `address_3` | string <small>max 200</small> | yes | Address 3 |
| `city` | string <small>max 50</small> | yes | City |
| `state_province` | string <small>max 50</small> | yes | State Province |
| `postal_code` | string <small>max 20</small> | yes | Postal Code |
| `country` | integer | yes | Country |
| `email` | string <small>max 100</small> | yes | Email |
| `direct_deposit_account` | string <small>max 20</small> | yes | Direct Deposit Account |
| `direct_deposit_bank` | string <small>max 20</small> | yes | Direct Deposit Bank |
| `account_number` | string <small>max 75</small> | yes | Account Number |
| `standard_days_to_pay` | integer | yes | Standard Days To Pay |
| `last_modified_date` | string <small>read-only</small> | yes | Last Modified Date |
| `inactive` | boolean | yes | Inactive |
| `vendor_tax_info` | string <small>read-only</small> | yes | Vendor Tax Info |
| `federal_tax_id` | string <small>max 20</small> | yes | Tax ID  Tax ID that is necessary for government reporting purposes. |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
