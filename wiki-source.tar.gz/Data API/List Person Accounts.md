> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Person Accounts / List Person Accounts · [source site](https://api-docs.veracross.com/)

---


# List Person Accounts


## GET `/person_accounts`


List Person Accounts


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer |  | Person ID  A person record must exist before creating a user account for the person record. |
| `username` | string |  | Username |
| `external_username` | string |  | External Username  The username in your external login provider. If you are not using an external provider, leave blank and the system will generate a username for the user based on username configuration set up in Axiom. |
| `account_type` | integer |  | Account Type |
| `status` | integer |  | Account Status  For Veracross accounts without associated external accounts. |
| `role` | integer |  | Role |
| `on_or_before_last_login_date` | string |  | Last Login Date  The last time this user successfully logged in to Veracross (excludes impersonated logins). |
| `on_or_after_last_login_date` | string |  | Last Login Date  The last time this user successfully logged in to Veracross (excludes impersonated logins). |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `person_id` | integer | yes | Person ID  A person record must exist before creating a user account for the person record. |
| `username` | string <small>max 128</small> | yes | Username |
| `external_username` | string <small>max 255</small> | yes | External Username  The username in your external login provider. If you are not using an external provider, leave blank and the system will generate a username for the user based on username configuration set up in Axiom. |
| `account_type` | integer | yes | Account Type |
| `primary_portal` | string <small>max 200</small> | yes | Primary Portal |
| `status` | integer | yes | Account Status  For Veracross accounts without associated external accounts. |
| `security_roles` | string <small>read-only</small> | yes | Security Roles |
| `last_login_date` | string <small>read-only</small> | yes | Last Login Date  The last time this user successfully logged in to Veracross (excludes impersonated logins). |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
