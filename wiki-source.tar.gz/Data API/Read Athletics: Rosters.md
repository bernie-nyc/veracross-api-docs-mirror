> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Athletics: Rosters / Read Athletics: Rosters · [source site](https://api-docs.veracross.com/)

---


# Read Athletics: Rosters


## GET `/athletics/rosters/{id}`


Read Athletics: Rosters


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Enrollment ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Enrollment ID |
| `internal_class_id` | integer | yes | Internal Class ID |
| `person_id` | integer | yes | Person ID |
| `first_name` | string <small>max 50</small> | yes | First Name |
| `last_name` | string <small>max 50</small> | yes | Last Name |
| `suffix` | integer | yes | Name Suffix |
| `grade_level_id` | integer | yes | Grade Level |
| `currently_enrolled` | boolean | yes | Currently Enrolled  A read-only calculated field, this field indicates whether the student is currently enrolled in the class. It is based on a combination of the &quot;Late Date Enrolled&quot; and &quot;Date Withdrawn&quot; fields.    For Classes with a waitlist, if the student is on the waitlist, this field will also report they are not in the class. |
| `late_date_enrolled` | string | yes | Late Date Enrolled  The date the student enrolled in the class |
| `date_withdrawn` | string | yes | Date Withdrawn  The date the student withdrew from the class |
| `level` | integer | yes | Enrollment Level  The enrollment level is used when some students are taking the class for a different level of credit than other students. If all students are taking the course for the same level of credit, setting the enrollment level is NOT necessary. If the student&#39;s enrollment level should influence GPA, please review &quot;override grade conversion scale&quot; on the student&#39;s class enrollment record. |
| `jersey_size` | integer | yes | Jersey Size |
| `jersey_number` | string <small>max 3</small> | yes | Jersey # |
| `position` | string <small>max 20</small> | yes | Position |
| `height` | string <small>max 8</small> | yes | Height |
| `weight` | string <small>max 10</small> | yes | Weight |
| `captain` | boolean | yes | Captain |
| `lettered` | boolean | yes | Lettered |
| `exclude_from_transcript` | boolean | yes | Exclude From Transcript  Excludes posted grades for this enrollment from being posted to the transcript.  Selecting this option does NOT impact this student&#39;s GPA. |
| `notes` | string <small>max 1000</small> | yes | Notes |

</details>

<details><summary><code>value_lists</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `fields` | array<string> | yes | An array of field names from `data` that this value list goes with |
| `items` | array<object> | yes | An array of value list items whose `id` field matches the value in the response data |
| `categories` | array<object> | yes | An array of "category" objects, which allow you to partition the value list items according to their category field |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
