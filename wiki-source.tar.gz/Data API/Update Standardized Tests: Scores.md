> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Standardized Tests: Scores / Update Standardized Tests: Scores · [source site](https://api-docs.veracross.com/)

---


# Update Standardized Tests: Scores


## PATCH `/standardized_tests/scores/{id}`


Update Standardized Tests: Scores


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Person Standardized Test Score ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Person Standardized Test Score ID |
| `person_test_id` | integer |  | Person Standardized Test |
| `person_id` | integer <small>read-only</small> |  | Person ID |
| `test_type` | integer |  | Test Type |
| `test_type_description` | string <small>max 50</small> <small>read-only</small> |  | Description (read-only) |
| `test_year` | integer |  | Test Year  The year the test was taken, entered manually if the exact date is not known. |
| `test_date` | string |  | Test Date  The date the test was taken |
| `score_type` | integer |  | Score Type  E.g. English, Math, Writing |
| `score_type_description` | string <small>max 50</small> |  | Description |
| `score` | string <small>max 20</small> |  | Score |
| `is_primary_score` | boolean |  | Primary Score |
| `is_secondary_score` | boolean |  | Secondary Score |
| `is_tertiary_score` | boolean |  | Tertiary Score |
| `created_date` | string |  | Input Date |
| `last_modified_date` | string |  | Update Date |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
