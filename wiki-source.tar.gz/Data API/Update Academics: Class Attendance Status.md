> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Academics: Class Attendance Status / Update Academics: Class Attendance Status · [source site](https://api-docs.veracross.com/)

---


# Update Academics: Class Attendance Status


## PATCH `/academics/class_attendance_statuses/{id}`


Update Academics: Class Attendance Status


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Class Attendance Status History ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> |  | Class Attendance Status History ID |
| `internal_class_id` | integer <small>read-only</small> |  | Internal Class ID |
| `date` | string |  | Attendance Date  Attendance Date for the class attendance status history record |
| `takes_daily_attendance_today` | boolean <small>read-only</small> |  | Takes Daily Attendance on Date |
| `attendance_status` | integer |  | Attendance Status |
| `class` | object |  |  |
| `teacher_id` | integer <small>read-only</small> |  | Person ID |
| `teacher_name` | string <small>read-only</small> |  | Full Name  The full name of an individual in the school-defined format, often &lt;last name&gt;, &lt;first name&gt; |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
