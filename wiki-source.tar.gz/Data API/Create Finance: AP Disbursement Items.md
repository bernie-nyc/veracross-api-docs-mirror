> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Finance: AP Disbursement Items / Create Finance: AP Disbursement Items · [source site](https://api-docs.veracross.com/)

---


# Create Finance: AP Disbursement Items


## POST `/finance/ap_disbursements/{disbursement_id}/ap_disbursement_items`


Create Finance: AP Disbursement Items


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `disbursement_id` | string | yes | Disbursement Header |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `disbursement_item_id` | integer <small>read-only</small> |  | Disbursement Item ID |
| `disbursement_header_id` | string |  | Disbursement Header |
| `amount` | number |  | Amount  Amount of this transaction that has been posted to the general ledger. |
| `description` | string <small>max 80</small> |  | Description |
| `cleared` | boolean |  | Cleared? |
| `debit_gl_account` | string <small>read-only</small> |  | DR GL Account |
| `ap_invoice_header` | string |  | AP Invoice |
| `ap_invoice_item` | string |  | AP Item |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes |  |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
