> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API / Report Cards: Class Curriculum / List Report Cards: Class Curriculum · [source site](https://api-docs.veracross.com/)

---


# List Report Cards: Class Curriculum


## GET `/report_card/classes/{internal_class_id}/curriculum`


List Report Cards: Class Curriculum


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer | yes | Internal Class ID |


**Query parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `rubric_id` | integer |  | Rubric ID |
| `rubric_category_id` | integer |  | ID |
| `enrollment_level_id` | integer |  | ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-Page-Number` | integer |  | Page number |
| `X-Page-Size` | integer |  | Number of records per page (for collection endpoints) |
| `X-API-Value-Lists` | string |  | Include Value Lists in response |
| `X-API-Revision` | string |  | API Revision |


### Responses


**200** — OK


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | array<object> | yes |  |
| `value_lists` | array<object> <small>read-only</small> |  | Present only with header `X-API-Value-Lists = include` |

<details><summary><code>data</code> — array item fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer <small>read-only</small> | yes | Class Curriculum ID |
| `grading_period` | object | yes |  |
| `rubric` | object | yes |  |
| `rubric_category` | object | yes |  |
| `enrollment_level` | object | yes |  |
| `curriculum` | string | yes | Curriculum |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
