> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Athletics: Teams / Update Athletics: Teams · [source site](https://api-docs.veracross.com/)

---


# Update Athletics: Teams


## PATCH `/athletics/teams/{id}`


Update Athletics: Teams


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | Internal Class ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `internal_class_id` | integer <small>read-only</small> |  | Internal Class ID |
| `school_level` | integer |  | School Level |
| `campus_id` | integer |  | Campus |
| `internal_sport_id` | integer |  | Sport ID |
| `team_id` | string <small>max 20</small> |  | Team ID |
| `description` | string <small>max 80</small> |  | Description |
| `sport_id` | integer |  | Sport |
| `head_coach_id` | integer |  | Coach ID |
| `assistant_coach_id` | integer |  | Assistant Coach ID |
| `begin_date` | string |  | Begin Date |
| `end_date` | string |  | End Date |
| `overall_record` | string <small>read-only</small> |  | Overall Record |
| `internal_team_id` | integer |  | System Group ID |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
