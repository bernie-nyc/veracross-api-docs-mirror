> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Data API / Finance: AP Invoice Items / Update Finance: AP Invoice Items · [source site](https://api-docs.veracross.com/)

---


# Update Finance: AP Invoice Items


## PATCH `/finance/ap_invoice_items/{id}`


Update Finance: AP Invoice Items


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | AP Item ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_item_id` | integer <small>read-only</small> |  | AP Item ID |
| `invoice_number` | string <small>max 30</small> |  | Invoice Number |
| `ap_invoice_header_id` | integer <small>read-only</small> |  | AP Header ID |
| `vendor` | string <small>read-only</small> |  | Vendor - Read Only |
| `invoice_date` | string |  | Invoice Date  Item date is almost always the same as the invoice date , except in cases of adjustment items. |
| `due_date` | string |  | Due Date |
| `posting_date` | string <small>read-only</small> |  | Posting Date - Read Only |
| `quantity` | number |  | Quantity |
| `unit_cost` | number |  | Unit Cost |
| `amount` | number |  | Amount |
| `dr_gl_account` | string <small>read-only</small> |  | DR GL Account |
| `project_id` | string <small>read-only</small> |  | Project # |
| `ap_description` | string <small>max 200</small> |  | AP Description |
| `je_ref_id` | string <small>read-only</small> |  | JE Ref. # - Read Only |
| `posted` | boolean <small>read-only</small> |  | Posted? - Read Only |
| `last_modified_date` | string <small>read-only</small> |  | Last Modified Date |
| `tax_type` | object |  |  |
| `tax_amount` | number |  | Tax Amount |

</details>

### Responses


**204** — No Content


- `X-API-Revision`: API Revision

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
