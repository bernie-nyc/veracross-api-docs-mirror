> [Home](Home) · [Concepts](Concepts/General%20Principles) · [Guides](Guides/Making%20a%20Data%20API%20Request) · [Diagrams](Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](Changelog/Data%20API) · [Data API](Data%20API) · [Authorization API](Authorization%20API) · [Files API](Files%20API)
>
> Files API · [source site](https://api-docs.veracross.com/)

---


# Overview: Files API


This service documents **11** operations/schemas across **4** groups.


### Admissions: Applicant Files


- [Create Admissions: Applicant Files](Files%20API/Create%20Admissions:%20Applicant%20Files) `POST`  
- [List Admissions: Applicant Files](Files%20API/List%20Admissions:%20Applicant%20Files) `GET`  
- [Read Admissions: Applicant Files](Files%20API/Read%20Admissions:%20Applicant%20Files) `GET`  


### Finance: AP Invoice Files


- [Create Finance: AP Invoice Files](Files%20API/Create%20Finance:%20AP%20Invoice%20Files) `POST`  
- [List Finance: AP Invoice Files](Files%20API/List%20Finance:%20AP%20Invoice%20Files) `GET`  
- [Delete Finance: AP Invoice Files](Files%20API/Delete%20Finance:%20AP%20Invoice%20Files) `DELETE`  
- [Read Finance: AP Invoice Files](Files%20API/Read%20Finance:%20AP%20Invoice%20Files) `GET`  


### Person Photo


- [Create Person Photo](Files%20API/Create%20Person%20Photo) `POST`  
- [Read Person Photo](Files%20API/Read%20Person%20Photo) `GET`  


### Schemas


- [post](Files%20API/post)  
- [error](Files%20API/error)  


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
