> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Files API · [source site](https://api-docs.veracross.com/)

---


# Overview: Files API


This service documents **11** operations/schemas across **4** groups.


### Admissions: Applicant Files


- [Create Admissions: Applicant Files](Create-Admissions:-Applicant-Files) `POST`  
- [List Admissions: Applicant Files](List-Admissions:-Applicant-Files) `GET`  
- [Read Admissions: Applicant Files](Read-Admissions:-Applicant-Files) `GET`  


### Finance: AP Invoice Files


- [Create Finance: AP Invoice Files](Create-Finance:-AP-Invoice-Files) `POST`  
- [List Finance: AP Invoice Files](List-Finance:-AP-Invoice-Files) `GET`  
- [Delete Finance: AP Invoice Files](Delete-Finance:-AP-Invoice-Files) `DELETE`  
- [Read Finance: AP Invoice Files](Read-Finance:-AP-Invoice-Files) `GET`  


### Person Photo


- [Create Person Photo](Create-Person-Photo) `POST`  
- [Read Person Photo](Read-Person-Photo) `GET`  


### Schemas


- [post](files-api-post)  
- [error](files-api-error)  


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
