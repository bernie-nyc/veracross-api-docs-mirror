> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Data API · [source site](https://api-docs.veracross.com/)

---


# Overview: Data API


This service documents **442** operations/schemas across **169** groups.


### Academics: Assignment Grades


- [List Academics: Assignment Grades](List-Academics:-Assignment-Grades) `GET`  
- [Read Academics: Assignment Grades](Read-Academics:-Assignment-Grades) `GET`  
- [Update Academics: Assignment Grades](Update-Academics:-Assignment-Grades) `PATCH`  


### Academics: Block Groups


- [List Academics: Block Groups](List-Academics:-Block-Groups) `GET`  
- [Read Academics: Block Groups](Read-Academics:-Block-Groups) `GET`  


### Academics: Blocks by Group


- [List Academics: Blocks by Group](List-Academics:-Blocks-by-Group) `GET`  
- [Read Academics: Blocks by Group](Read-Academics:-Blocks-by-Group) `GET`  


### Academics: Calendar Rotation Days


- [List Academics: Calendar Rotation Days](List-Academics:-Calendar-Rotation-Days) `GET`  
- [Read Academics: Calendar Rotation Days](Read-Academics:-Calendar-Rotation-Days) `GET`  


### Academics: Class Assignments


- [Create Academics: Class Assignments](Create-Academics:-Class-Assignments) `POST`  
- [List Academics: Class Assignments](List-Academics:-Class-Assignments) `GET`  
- [Delete Academics: Class Assignments](Delete-Academics:-Class-Assignments) `DELETE`  
- [Read Academics: Class Assignments](Read-Academics:-Class-Assignments) `GET`  
- [Update Academics: Class Assignments](Update-Academics:-Class-Assignments) `PATCH`  


### Academics: Class Attendance Status


- [List Academics: Class Attendance Status](List-Academics:-Class-Attendance-Status) `GET`  
- [Read Academics: Class Attendance Status](Read-Academics:-Class-Attendance-Status) `GET`  
- [Update Academics: Class Attendance Status](Update-Academics:-Class-Attendance-Status) `PATCH`  


### Academics: Class Meeting Times


- [List Academics: Class Meeting Times](List-Academics:-Class-Meeting-Times) `GET`  
- [Read Academics: Class Meeting Times](Read-Academics:-Class-Meeting-Times) `GET`  


### Academics: Class Schedules


- [List Academics: Class Schedules](List-Academics:-Class-Schedules) `GET`  


### Academics: Classes


- [List Academics: Classes](List-Academics:-Classes) `GET`  
- [Create Academics: Classes](Create-Academics:-Classes) `POST`  
- [Read Academics: Classes](Read-Academics:-Classes) `GET`  
- [Update Academics: Classes](Update-Academics:-Classes) `PATCH`  


### Academics: Classes - Permissions


- [List Academics: Classes - Permissions](List-Academics:-Classes---Permissions) `GET`  
- [Read Academics: Classes - Permissions](Read-Academics:-Classes---Permissions) `GET`  


### Academics: Configuration - Block Meeting Times


- [List Academics: Configuration - Block Meeting Times](List-Academics:-Configuration---Block-Meeting-Times) `GET`  
- [Read Academics: Configuration - Block Meeting Times](Read-Academics:-Configuration---Block-Meeting-Times) `GET`  


### Academics: Configuration - Block Schedules


- [List Academics: Configuration - Block Schedules](List-Academics:-Configuration---Block-Schedules) `GET`  
- [Read Academics: Configuration - Block Schedules](Read-Academics:-Configuration---Block-Schedules) `GET`  


### Academics: Configuration - Blocks/Periods


- [List Academics: Configuration - Blocks/Periods](List-Academics:-Configuration---Blocks-Periods) `GET`  
- [Read Academics: Configuration - Blocks/Periods](Read-Academics:-Configuration---Blocks-Periods) `GET`  


### Academics: Configuration - Grade Levels


- [List Academics: Configuration - Grade Levels](List-Academics:-Configuration---Grade-Levels) `GET`  


### Academics: Courses


- [Create Academics: Courses](Create-Academics:-Courses) `POST`  
- [List Academics: Courses](List-Academics:-Courses) `GET`  
- [Read Academics: Courses](Read-Academics:-Courses) `GET`  
- [Update Academics: Courses](Update-Academics:-Courses) `PATCH`  


### Academics: Departments


- [List Academics: Departments](List-Academics:-Departments) `GET`  
- [Read Academics: Departments](Read-Academics:-Departments) `GET`  


### Academics: Enrollments


- [List Academics: Enrollments](List-Academics:-Enrollments) `GET`  
- [Create Academics: Enrollments](Create-Academics:-Enrollments) `POST`  
- [Read Academics: Enrollments](Read-Academics:-Enrollments) `GET`  
- [Update Academics: Enrollments](Update-Academics:-Enrollments) `PATCH`  


### Academics: Grading Periods


- [List Academics: Grading Periods](List-Academics:-Grading-Periods) `GET`  
- [Read Academics: Grading Periods](Read-Academics:-Grading-Periods) `GET`  


### Academics: Numeric Grades


- [Read Academics: Numeric Grades](Read-Academics:-Numeric-Grades) `GET`  
- [Update Academics: Numeric Grades](Update-Academics:-Numeric-Grades) `PATCH`  
- [List Academics: Numeric Grades](List-Academics:-Numeric-Grades) `GET`  


### Academics: Qualitative Grades


- [Read Academics: Qualitative Grades](Read-Academics:-Qualitative-Grades) `GET`  
- [Update Academics: Qualitative Grades](Update-Academics:-Qualitative-Grades) `PATCH`  
- [List Academics: Qualitative Grades](List-Academics:-Qualitative-Grades) `GET`  


### Academics: Rooms


- [List Academics: Rooms](List-Academics:-Rooms) `GET`  
- [Read Academics: Rooms](Read-Academics:-Rooms) `GET`  


### Academics: Rotation Days


- [List Academics: Rotation Days](List-Academics:-Rotation-Days) `GET`  
- [Read Academics: Rotation Days](Read-Academics:-Rotation-Days) `GET`  


### Academics: Rubric Categories


- [Create Academics: Rubric Categories](Create-Academics:-Rubric-Categories) `POST`  
- [List Academics: Rubric Categories](List-Academics:-Rubric-Categories) `GET`  
- [Read Academics: Rubric Categories](Read-Academics:-Rubric-Categories) `GET`  
- [Update Academics: Rubric Categories](Update-Academics:-Rubric-Categories) `PATCH`  


### Academics: Rubric Criteria


- [Create Academics: Rubric Criteria](Create-Academics:-Rubric-Criteria) `POST`  
- [List Academics: Rubric Criteria](List-Academics:-Rubric-Criteria) `GET`  
- [Read Academics: Rubric Criteria](Read-Academics:-Rubric-Criteria) `GET`  
- [Update Academics: Rubric Criteria](Update-Academics:-Rubric-Criteria) `PATCH`  


### Academics: Rubric Scales


- [Create Academics: Rubric Scales](Create-Academics:-Rubric-Scales) `POST`  
- [List Academics: Rubric Scales](List-Academics:-Rubric-Scales) `GET`  
- [Read Academics: Rubric Scales](Read-Academics:-Rubric-Scales) `GET`  
- [Update Academics: Rubric Scales](Update-Academics:-Rubric-Scales) `PATCH`  


### Academics: Rubric Scales - Levels


- [Create Academics: Rubric Scales - Levels](Create-Academics:-Rubric-Scales---Levels) `POST`  
- [List Academics: Rubric Scales - Levels](List-Academics:-Rubric-Scales---Levels) `GET`  
- [Read Academics: Rubric Scales - Levels](Read-Academics:-Rubric-Scales---Levels) `GET`  
- [Update Academics: Rubric Scales - Levels](Update-Academics:-Rubric-Scales---Levels) `PATCH`  


### Academics: Rubrics


- [Create Academics: Rubrics](Create-Academics:-Rubrics) `POST`  
- [List Academics: Rubrics](List-Academics:-Rubrics) `GET`  
- [Read Academics: Rubrics](Read-Academics:-Rubrics) `GET`  
- [Update Academics: Rubrics](Update-Academics:-Rubrics) `PATCH`  


### Academics: Student Alerts


- [List Academics: Student Alerts](List-Academics:-Student-Alerts) `GET`  
- [Read Academics: Student Alerts](Read-Academics:-Student-Alerts) `GET`  
- [Update Academics: Student Alerts](Update-Academics:-Student-Alerts) `PATCH`  


### Academics: Student Assignments


- [List Academics: Student Assignments](List-Academics:-Student-Assignments) `GET`  
- [Read Academics: Student Assignments](Read-Academics:-Student-Assignments) `GET`  


### Academics: Student Daily Schedules


- [List Academics: Student Daily Schedules](List-Academics:-Student-Daily-Schedules) `GET`  


### Academics: Subjects


- [List Academics: Subjects](List-Academics:-Subjects) `GET`  
- [Read Academics: Subjects](Read-Academics:-Subjects) `GET`  


### Academics: Teacher Daily Schedules


- [List Academics: Teacher Daily Schedules](List-Academics:-Teacher-Daily-Schedules) `GET`  


### Admission: Applicant Relationships


- [Create Admission: Applicant Relationships](Create-Admission:-Applicant-Relationships) `POST`  
- [List Admission: Applicant Relationships](List-Admission:-Applicant-Relationships) `GET`  
- [Read Admission: Applicant Relationships](Read-Admission:-Applicant-Relationships) `GET`  
- [Update Admission: Applicant Relationships](Update-Admission:-Applicant-Relationships) `PATCH`  


### Admission: Applicants


- [Create Admission: Applicants](Create-Admission:-Applicants) `POST`  
- [List Admission: Applicants](List-Admission:-Applicants) `GET`  
- [Read Admission: Applicants](Read-Admission:-Applicants) `GET`  
- [Update Admission: Applicants](Update-Admission:-Applicants) `PATCH`  


### Admission: Application Checklists


- [List Admission: Application Checklists](List-Admission:-Application-Checklists) `GET`  
- [Read Admission: Application Checklists](Read-Admission:-Application-Checklists) `GET`  
- [Update Admission: Application Checklists](Update-Admission:-Application-Checklists) `PATCH`  


### Admission: Applications


- [Create Admission: Applications](Create-Admission:-Applications) `POST`  
- [List Admission: Applications](List-Admission:-Applications) `GET`  
- [Read Admission: Applications](Read-Admission:-Applications) `GET`  
- [Update Admission: Applications](Update-Admission:-Applications) `PATCH`  


### Admission: Citizenships


- [Create Admission: Citizenships](Create-Admission:-Citizenships) `POST`  
- [List Admission: Citizenships](List-Admission:-Citizenships) `GET`  
- [Read Admission: Citizenships](Read-Admission:-Citizenships) `GET`  
- [Update Admission: Citizenships](Update-Admission:-Citizenships) `PATCH`  


### Admission: Configuration - Checklists


- [List Admission: Configuration - Checklists](List-Admission:-Configuration---Checklists) `GET`  
- [Read Admission: Configuration - Checklists](Read-Admission:-Configuration---Checklists) `GET`  


### Admission: Configuration - Years


- [List Admission: Configuration - Years](List-Admission:-Configuration---Years) `GET`  
- [Read Admission: Configuration - Years](Read-Admission:-Configuration---Years) `GET`  


### Admission: Household Members


- [List Admission: Household Members](List-Admission:-Household-Members) `GET`  


### Admission: Households


- [List Admission: Households](List-Admission:-Households) `GET`  
- [Read Admission: Households](Read-Admission:-Households) `GET`  
- [Update Admission: Households](Update-Admission:-Households) `PATCH`  


### Admission: Languages


- [Create Admission: Languages](Create-Admission:-Languages) `POST`  
- [List Admission: Languages](List-Admission:-Languages) `GET`  
- [Read Admission: Languages](Read-Admission:-Languages) `GET`  
- [Update Admission: Languages](Update-Admission:-Languages) `PATCH`  


### Admission: Relative Relationships


- [Create Admission: Relative Relationships](Create-Admission:-Relative-Relationships) `POST`  
- [List Admission: Relative Relationships](List-Admission:-Relative-Relationships) `GET`  
- [Read Admission: Relative Relationships](Read-Admission:-Relative-Relationships) `GET`  
- [Update Admission: Relative Relationships](Update-Admission:-Relative-Relationships) `PATCH`  


### Admission: Relatives


- [List Admission: Relatives](List-Admission:-Relatives) `GET`  
- [Create Admission: Relatives](Create-Admission:-Relatives) `POST`  
- [Read Admission: Relatives](Read-Admission:-Relatives) `GET`  
- [Update Admission: Relatives](Update-Admission:-Relatives) `PATCH`  


### Alumni: Demographics


- [List Alumni: Demographics](List-Alumni:-Demographics) `GET`  
- [Read Alumni: Demographics](Read-Alumni:-Demographics) `GET`  


### Athletics: Rosters


- [Create Athletics: Rosters](Create-Athletics:-Rosters) `POST`  
- [List Athletics: Rosters](List-Athletics:-Rosters) `GET`  
- [Read Athletics: Rosters](Read-Athletics:-Rosters) `GET`  
- [Update Athletics: Rosters](Update-Athletics:-Rosters) `PATCH`  


### Athletics: Sports


- [List Athletics: Sports](List-Athletics:-Sports) `GET`  
- [Create Athletics: Sports](Create-Athletics:-Sports) `POST`  
- [Read Athletics: Sports](Read-Athletics:-Sports) `GET`  
- [Update Athletics: Sports](Update-Athletics:-Sports) `PATCH`  


### Athletics: Team - Coaches


- [List Athletics: Team - Coaches](List-Athletics:-Team---Coaches) `GET`  


### Athletics: Team Practice Schedules


- [List Athletics: Team Practice Schedules](List-Athletics:-Team-Practice-Schedules) `GET`  


### Athletics: Teams


- [Create Athletics: Teams](Create-Athletics:-Teams) `POST`  
- [List Athletics: Teams](List-Athletics:-Teams) `GET`  
- [Read Athletics: Teams](Read-Athletics:-Teams) `GET`  
- [Update Athletics: Teams](Update-Athletics:-Teams) `PATCH`  


### Attendance Status Codes


- [List Attendance Status Codes](List-Attendance-Status-Codes) `GET`  


### Behavior


- [Create Behavior](Create-Behavior) `POST`  
- [List Behavior](List-Behavior) `GET`  
- [Read Behavior](Read-Behavior) `GET`  
- [Update Behavior](Update-Behavior) `PATCH`  


### Behavior Incident Types


- [List Behavior Incident Types](List-Behavior-Incident-Types) `GET`  
- [Read Behavior Incident Types](Read-Behavior-Incident-Types) `GET`  
- [Update Behavior Incident Types](Update-Behavior-Incident-Types) `PATCH`  


### Boarding: Dorm Attendance


- [List Boarding: Dorm Attendance](List-Boarding:-Dorm-Attendance) `GET`  
- [Read Boarding: Dorm Attendance](Read-Boarding:-Dorm-Attendance) `GET`  
- [Update Boarding: Dorm Attendance](Update-Boarding:-Dorm-Attendance) `PATCH`  


### Boarding: Dorm Students


- [List Boarding: Dorm Students](List-Boarding:-Dorm-Students) `GET`  
- [Read Boarding: Dorm Students](Read-Boarding:-Dorm-Students) `GET`  
- [Update Boarding: Dorm Students](Update-Boarding:-Dorm-Students) `PATCH`  


### Boarding: Dorms


- [List Boarding: Dorms](List-Boarding:-Dorms) `GET`  
- [Read Boarding: Dorms](Read-Boarding:-Dorms) `GET`  


### Calendars: Parent Calendars


- [List Calendars: Parent Calendars](List-Calendars:-Parent-Calendars) `GET`  


### Calendars: Student Calendars


- [List Calendars: Student Calendars](List-Calendars:-Student-Calendars) `GET`  


### Class - Permissions


- [List Class - Permissions](List-Class---Permissions) `GET`  


### Class Attendance


- [List Class Attendance](List-Class-Attendance) `GET`  
- [Read Class Attendance](Read-Class-Attendance) `GET`  
- [Update Class Attendance](Update-Class-Attendance) `PATCH`  


### Classes


- [List Classes](List-Classes) `GET`  
- [Read Classes](Read-Classes) `GET`  


### Contact Info


- [List Contact Info](List-Contact-Info) `GET`  
- [Read Contact Info](Read-Contact-Info) `GET`  
- [Update Contact Info](Update-Contact-Info) `PATCH`  


### Convert Parent Account to Staff Account


- [Create Convert Parent Account to Staff Account](Create-Convert-Parent-Account-to-Staff-Account) `POST`  


### Courses


- [List Courses](List-Courses) `GET`  
- [Read Courses](Read-Courses) `GET`  
- [Update Courses](Update-Courses) `PATCH`  


### Development: Constituents


- [List Development: Constituents](List-Development:-Constituents) `GET`  
- [Read Development: Constituents](Read-Development:-Constituents) `GET`  


### Development: Gifts


- [List Development: Gifts](List-Development:-Gifts) `GET`  
- [Read Development: Gifts](Read-Development:-Gifts) `GET`  


### Directory Preferences: Household


- [List Directory Preferences: Household](List-Directory-Preferences:-Household) `GET`  
- [Read Directory Preferences: Household](Read-Directory-Preferences:-Household) `GET`  
- [Update Directory Preferences: Household](Update-Directory-Preferences:-Household) `PATCH`  


### Directory Preferences: Person


- [List Directory Preferences: Person](List-Directory-Preferences:-Person) `GET`  
- [Read Directory Preferences: Person](Read-Directory-Preferences:-Person) `GET`  
- [Update Directory Preferences: Person](Update-Directory-Preferences:-Person) `PATCH`  


### Directory Type Configurations


- [List Directory Type Configurations](List-Directory-Type-Configurations) `GET`  


### Directory: Household


- [List Directory: Household](List-Directory:-Household) `GET`  


### Directory: Staff/Faculty


- [List Directory: Staff/Faculty](List-Directory:-Staff-Faculty) `GET`  


### Directory: Student


- [List Directory: Student](List-Directory:-Student) `GET`  


### Emergency Contacts


- [Create Emergency Contacts](Create-Emergency-Contacts) `POST`  
- [List Emergency Contacts](List-Emergency-Contacts) `GET`  
- [Delete Emergency Contacts](Delete-Emergency-Contacts) `DELETE`  
- [Read Emergency Contacts](Read-Emergency-Contacts) `GET`  
- [Update Emergency Contacts](Update-Emergency-Contacts) `PATCH`  


### Ethnicities


- [List Ethnicities](List-Ethnicities) `GET`  


### Event Groups


- [Create Event Groups](Create-Event-Groups) `POST`  
- [List Event Groups](List-Event-Groups) `GET`  
- [Delete Event Groups](Delete-Event-Groups) `DELETE`  
- [Read Event Groups](Read-Event-Groups) `GET`  


### Event Groups Members


- [List Event Groups Members](List-Event-Groups-Members) `GET`  


### Event Representatives


- [List Event Representatives](List-Event-Representatives) `GET`  


### Events


- [Read Events](Read-Events) `GET`  
- [Update Events](Update-Events) `PATCH`  
- [Create Events](Create-Events) `POST`  
- [List Events](List-Events) `GET`  


### Events: Athletics


- [Create Events: Athletics](Create-Events:-Athletics) `POST`  
- [List Events: Athletics](List-Events:-Athletics) `GET`  
- [Read Events: Athletics](Read-Events:-Athletics) `GET`  
- [Update Events: Athletics](Update-Events:-Athletics) `PATCH`  


### Events: Athletics Opponents


- [List Events: Athletics Opponents](List-Events:-Athletics-Opponents) `GET`  
- [Read Events: Athletics Opponents](Read-Events:-Athletics-Opponents) `GET`  


### Events: Athletics Scores


- [Read Events: Athletics Scores](Read-Events:-Athletics-Scores) `GET`  
- [Update Events: Athletics Scores](Update-Events:-Athletics-Scores) `PATCH`  


### Events: Attendance


- [Create Events: Attendance](Create-Events:-Attendance) `POST`  
- [List Events: Attendance](List-Events:-Attendance) `GET`  
- [Delete Events: Attendance](Delete-Events:-Attendance) `DELETE`  
- [Read Events: Attendance](Read-Events:-Attendance) `GET`  
- [Update Events: Attendance](Update-Events:-Attendance) `PATCH`  


### Extended Care: Class Attendance


- [List Extended Care: Class Attendance](List-Extended-Care:-Class-Attendance) `GET`  
- [Read Extended Care: Class Attendance](Read-Extended-Care:-Class-Attendance) `GET`  


### Extended Care: Class Meeting Times


- [List Extended Care: Class Meeting Times](List-Extended-Care:-Class-Meeting-Times) `GET`  
- [Read Extended Care: Class Meeting Times](Read-Extended-Care:-Class-Meeting-Times) `GET`  


### Extended Care: Classes


- [Create Extended Care: Classes](Create-Extended-Care:-Classes) `POST`  
- [List Extended Care: Classes](List-Extended-Care:-Classes) `GET`  
- [Read Extended Care: Classes](Read-Extended-Care:-Classes) `GET`  
- [Update Extended Care: Classes](Update-Extended-Care:-Classes) `PATCH`  


### Extended Care: Courses


- [List Extended Care: Courses](List-Extended-Care:-Courses) `GET`  
- [Create Extended Care: Courses](Create-Extended-Care:-Courses) `POST`  
- [Read Extended Care: Courses](Read-Extended-Care:-Courses) `GET`  
- [Update Extended Care: Courses](Update-Extended-Care:-Courses) `PATCH`  


### Extended Care: Registrations


- [List Extended Care: Registrations](List-Extended-Care:-Registrations) `GET`  
- [Read Extended Care: Registrations](Read-Extended-Care:-Registrations) `GET`  


### External User Accounts


- [List External User Accounts](List-External-User-Accounts) `GET`  
- [Create External User Accounts](Create-External-User-Accounts) `POST`  
- [Read External User Accounts](Read-External-User-Accounts) `GET`  
- [Update External User Accounts](Update-External-User-Accounts) `PATCH`  


### Finance: AP Disbursement Items


- [Create Finance: AP Disbursement Items](Create-Finance:-AP-Disbursement-Items) `POST`  
- [List Finance: AP Disbursement Items](List-Finance:-AP-Disbursement-Items) `GET`  
- [Read Finance: AP Disbursement Items](Read-Finance:-AP-Disbursement-Items) `GET`  
- [Update Finance: AP Disbursement Items](Update-Finance:-AP-Disbursement-Items) `PATCH`  


### Finance: AP Disbursements


- [Create Finance: AP Disbursements](Create-Finance:-AP-Disbursements) `POST`  
- [List Finance: AP Disbursements](List-Finance:-AP-Disbursements) `GET`  
- [Read Finance: AP Disbursements](Read-Finance:-AP-Disbursements) `GET`  
- [Update Finance: AP Disbursements](Update-Finance:-AP-Disbursements) `PATCH`  


### Finance: AP Invoice Items


- [Create Finance: AP Invoice Items](Create-Finance:-AP-Invoice-Items) `POST`  
- [List Finance: AP Invoice Items](List-Finance:-AP-Invoice-Items) `GET`  
- [Read Finance: AP Invoice Items](Read-Finance:-AP-Invoice-Items) `GET`  
- [Update Finance: AP Invoice Items](Update-Finance:-AP-Invoice-Items) `PATCH`  


### Finance: AP Invoices


- [Create Finance: AP Invoices](Create-Finance:-AP-Invoices) `POST`  
- [List Finance: AP Invoices](List-Finance:-AP-Invoices) `GET`  
- [Read Finance: AP Invoices](Read-Finance:-AP-Invoices) `GET`  
- [Update Finance: AP Invoices](Update-Finance:-AP-Invoices) `PATCH`  


### Finance: GL Accounts


- [List Finance: GL Accounts](List-Finance:-GL-Accounts) `GET`  
- [Read Finance: GL Accounts](Read-Finance:-GL-Accounts) `GET`  


### Finance: Post AP Invoices


- [Update Finance: Post AP Invoices](Update-Finance:-Post-AP-Invoices) `PATCH`  


### Finance: Projects


- [List Finance: Projects](List-Finance:-Projects) `GET`  
- [Read Finance: Projects](Read-Finance:-Projects) `GET`  


### Finance: Purchase Request Workflow


- [List Finance: Purchase Request Workflow](List-Finance:-Purchase-Request-Workflow) `GET`  
- [Read Finance: Purchase Request Workflow](Read-Finance:-Purchase-Request-Workflow) `GET`  


### Finance: Purchase Request Workflow GL Accounts


- [List Finance: Purchase Request Workflow GL Accounts](List-Finance:-Purchase-Request-Workflow-GL-Accounts) `GET`  


### Finance: Tax Types


- [List Finance: Tax Types](List-Finance:-Tax-Types) `GET`  
- [Read Finance: Tax Types](Read-Finance:-Tax-Types) `GET`  


### Finance: Vendors


- [Create Finance: Vendors](Create-Finance:-Vendors) `POST`  
- [List Finance: Vendors](List-Finance:-Vendors) `GET`  
- [Read Finance: Vendors](Read-Finance:-Vendors) `GET`  
- [Update Finance: Vendors](Update-Finance:-Vendors) `PATCH`  


### Genders


- [List Genders](List-Genders) `GET`  


### Health: All Patients Conditions


- [List Health: All Patients Conditions](List-Health:-All-Patients-Conditions) `GET`  


### Health: Patient Conditions


- [List Health: Patient Conditions](List-Health:-Patient-Conditions) `GET`  
- [Create Health: Patient Conditions](Create-Health:-Patient-Conditions) `POST`  
- [Read Health: Patient Conditions](Read-Health:-Patient-Conditions) `GET`  
- [Update Health: Patient Conditions](Update-Health:-Patient-Conditions) `PATCH`  


### Health: Patient Medications


- [Create Health: Patient Medications](Create-Health:-Patient-Medications) `POST`  
- [List Health: Patient Medications](List-Health:-Patient-Medications) `GET`  
- [Read Health: Patient Medications](Read-Health:-Patient-Medications) `GET`  
- [Update Health: Patient Medications](Update-Health:-Patient-Medications) `PATCH`  


### Health: Patients


- [List Health: Patients](List-Health:-Patients) `GET`  
- [Read Health: Patients](Read-Health:-Patients) `GET`  
- [Update Health: Patients](Update-Health:-Patients) `PATCH`  


### Household Vehicles


- [List Household Vehicles](List-Household-Vehicles) `GET`  
- [Read Household Vehicles](Read-Household-Vehicles) `GET`  


### Households


- [List Households](List-Households) `GET`  
- [Create Households](Create-Households) `POST`  
- [Read Households](Read-Households) `GET`  
- [Update Households](Update-Households) `PATCH`  


### Master Attendance


- [List Master Attendance](List-Master-Attendance) `GET`  
- [Read Master Attendance](Read-Master-Attendance) `GET`  
- [Update Master Attendance](Update-Master-Attendance) `PATCH`  


### News


- [List News](List-News) `GET`  
- [Read News](Read-News) `GET`  


### Non-Academics: Classes


- [List Non-Academics: Classes](List-Non-Academics:-Classes) `GET`  
- [Create Non-Academics: Classes](Create-Non-Academics:-Classes) `POST`  
- [Read Non-Academics: Classes](Read-Non-Academics:-Classes) `GET`  
- [Update Non-Academics: Classes](Update-Non-Academics:-Classes) `PATCH`  


### Non-Academics: Courses


- [List Non-Academics: Courses](List-Non-Academics:-Courses) `GET`  
- [Create Non-Academics: Courses](Create-Non-Academics:-Courses) `POST`  
- [Read Non-Academics: Courses](Read-Non-Academics:-Courses) `GET`  
- [Update Non-Academics: Courses](Update-Non-Academics:-Courses) `PATCH`  


### Parents


- [List Parents](List-Parents) `GET`  
- [Read Parents](Read-Parents) `GET`  


### Person Accounts


- [Delete Person Accounts](Delete-Person-Accounts) `DELETE`  
- [Read Person Accounts](Read-Person-Accounts) `GET`  
- [List Person Accounts](List-Person-Accounts) `GET`  
- [Create Person Accounts](Create-Person-Accounts) `POST`  


### Person Citizenships


- [List Person Citizenships](List-Person-Citizenships) `GET`  
- [Read Person Citizenships](Read-Person-Citizenships) `GET`  


### Person Enrollment History


- [List Person Enrollment History](List-Person-Enrollment-History) `GET`  
- [Read Person Enrollment History](Read-Person-Enrollment-History) `GET`  


### Person Ethnicities


- [List Person Ethnicities](List-Person-Ethnicities) `GET`  


### Person Photo


- [List Person Photo](List-Person-Photo) `GET`  


### Person Profile Codes


- [Delete Person Profile Codes](Delete-Person-Profile-Codes) `DELETE`  
- [Read Person Profile Codes](Read-Person-Profile-Codes) `GET`  
- [List Person Profile Codes](List-Person-Profile-Codes) `GET`  
- [Create Person Profile Codes](Create-Person-Profile-Codes) `POST`  


### Person Reference Number


- [Create Person Reference Number](Create-Person-Reference-Number) `POST`  
- [List Person Reference Number](List-Person-Reference-Number) `GET`  
- [Delete Person Reference Number](Delete-Person-Reference-Number) `DELETE`  
- [Read Person Reference Number](Read-Person-Reference-Number) `GET`  
- [Update Person Reference Number](Update-Person-Reference-Number) `PATCH`  


### Person Roles


- [Create Person Roles](Create-Person-Roles) `POST`  
- [List Person Roles](List-Person-Roles) `GET`  
- [Delete Person Roles](Delete-Person-Roles) `DELETE`  
- [Read Person Roles](Read-Person-Roles) `GET`  


### Person Visas


- [List Person Visas](List-Person-Visas) `GET`  
- [Read Person Visas](Read-Person-Visas) `GET`  
- [Update Person Visas](Update-Person-Visas) `PATCH`  


### Portal Membership


- [List Portal Membership](List-Portal-Membership) `GET`  
- [Read Portal Membership](Read-Portal-Membership) `GET`  
- [Update Portal Membership](Update-Portal-Membership) `PATCH`  


### Programs: Class Attendance


- [List Programs: Class Attendance](List-Programs:-Class-Attendance) `GET`  
- [Read Programs: Class Attendance](Read-Programs:-Class-Attendance) `GET`  
- [Update Programs: Class Attendance](Update-Programs:-Class-Attendance) `PATCH`  


### Programs: Class Meeting Times


- [List Programs: Class Meeting Times](List-Programs:-Class-Meeting-Times) `GET`  
- [Read Programs: Class Meeting Times](Read-Programs:-Class-Meeting-Times) `GET`  


### Programs: Classes


- [Create Programs: Classes](Create-Programs:-Classes) `POST`  
- [List Programs: Classes](List-Programs:-Classes) `GET`  
- [Read Programs: Classes](Read-Programs:-Classes) `GET`  
- [Update Programs: Classes](Update-Programs:-Classes) `PATCH`  


### Programs: Courses


- [List Programs: Courses](List-Programs:-Courses) `GET`  
- [Create Programs: Courses](Create-Programs:-Courses) `POST`  
- [Read Programs: Courses](Read-Programs:-Courses) `GET`  
- [Update Programs: Courses](Update-Programs:-Courses) `PATCH`  


### Programs: Enrollments


- [List Programs: Enrollments](List-Programs:-Enrollments) `GET`  
- [Create Programs: Enrollments](Create-Programs:-Enrollments) `POST`  
- [Read Programs: Enrollments](Read-Programs:-Enrollments) `GET`  
- [Update Programs: Enrollments](Update-Programs:-Enrollments) `PATCH`  


### Relationships


- [List Relationships](List-Relationships) `GET`  
- [Read Relationships](Read-Relationships) `GET`  


### Relationships: DEPRECATED


- [List Relationships: DEPRECATED](List-Relationships:-DEPRECATED) `GET`  


### Report Cards: Academic Classifications


- [List Report Cards: Academic Classifications](List-Report-Cards:-Academic-Classifications) `GET`  
- [Read Report Cards: Academic Classifications](Read-Report-Cards:-Academic-Classifications) `GET`  


### Report Cards: Class Attendance


- [List Report Cards: Class Attendance](List-Report-Cards:-Class-Attendance) `GET`  


### Report Cards: Class Curriculum


- [List Report Cards: Class Curriculum](List-Report-Cards:-Class-Curriculum) `GET`  
- [Read Report Cards: Class Curriculum](Read-Report-Cards:-Class-Curriculum) `GET`  


### Report Cards: Class Teachers


- [List Report Cards: Class Teachers](List-Report-Cards:-Class-Teachers) `GET`  
- [Read Report Cards: Class Teachers](Read-Report-Cards:-Class-Teachers) `GET`  


### Report Cards: Daily Attendance


- [List Report Cards: Daily Attendance](List-Report-Cards:-Daily-Attendance) `GET`  


### Report Cards: Documents


- [Read Report Cards: Documents](Read-Report-Cards:-Documents) `GET`  
- [List Report Cards: Documents](List-Report-Cards:-Documents) `GET`  


### Report Cards: Enrollments


- [List Report Cards: Enrollments](List-Report-Cards:-Enrollments) `GET`  
- [Read Report Cards: Enrollments](Read-Report-Cards:-Enrollments) `GET`  


### Report Cards: GPAs


- [List Report Cards: GPAs](List-Report-Cards:-GPAs) `GET`  
- [Read Report Cards: GPAs](Read-Report-Cards:-GPAs) `GET`  


### Report Cards: Numeric Grades


- [List Report Cards: Numeric Grades](List-Report-Cards:-Numeric-Grades) `GET`  
- [Read Report Cards: Numeric Grades](Read-Report-Cards:-Numeric-Grades) `GET`  


### Report Cards: Qualitative Grades


- [List Report Cards: Qualitative Grades](List-Report-Cards:-Qualitative-Grades) `GET`  
- [Read Report Cards: Qualitative Grades](Read-Report-Cards:-Qualitative-Grades) `GET`  


### Resident Statuses


- [List Resident Statuses](List-Resident-Statuses) `GET`  


### Resource Reservations: Reservations


- [List Resource Reservations: Reservations](List-Resource-Reservations:-Reservations) `GET`  
- [Create Resource Reservations: Reservations](Create-Resource-Reservations:-Reservations) `POST`  
- [Read Resource Reservations: Reservations](Read-Resource-Reservations:-Reservations) `GET`  
- [Update Resource Reservations: Reservations](Update-Resource-Reservations:-Reservations) `PATCH`  


### Resource Reservations: Resources


- [Create Resource Reservations: Resources](Create-Resource-Reservations:-Resources) `POST`  
- [List Resource Reservations: Resources](List-Resource-Reservations:-Resources) `GET`  
- [Read Resource Reservations: Resources](Read-Resource-Reservations:-Resources) `GET`  
- [Update Resource Reservations: Resources](Update-Resource-Reservations:-Resources) `PATCH`  


### Security Roles


- [Create Security Roles](Create-Security-Roles) `POST`  
- [List Security Roles](List-Security-Roles) `GET`  
- [Delete Security Roles](Delete-Security-Roles) `DELETE`  


### Staff/Faculty


- [Create Staff/Faculty](Create-Staff-Faculty) `POST`  
- [List Staff/Faculty](List-Staff-Faculty) `GET`  
- [Read Staff/Faculty](Read-Staff-Faculty) `GET`  
- [Update Staff/Faculty](Update-Staff-Faculty) `PATCH`  


### Standardized Tests: Score Types


- [Create Standardized Tests: Score Types](Create-Standardized-Tests:-Score-Types) `POST`  
- [List Standardized Tests: Score Types](List-Standardized-Tests:-Score-Types) `GET`  
- [Read Standardized Tests: Score Types](Read-Standardized-Tests:-Score-Types) `GET`  
- [Update Standardized Tests: Score Types](Update-Standardized-Tests:-Score-Types) `PATCH`  


### Standardized Tests: Scores


- [List Standardized Tests: Scores](List-Standardized-Tests:-Scores) `GET`  
- [Read Standardized Tests: Scores](Read-Standardized-Tests:-Scores) `GET`  
- [Update Standardized Tests: Scores](Update-Standardized-Tests:-Scores) `PATCH`  


### Standardized Tests: Test Types


- [Create Standardized Tests: Test Types](Create-Standardized-Tests:-Test-Types) `POST`  
- [List Standardized Tests: Test Types](List-Standardized-Tests:-Test-Types) `GET`  
- [Read Standardized Tests: Test Types](Read-Standardized-Tests:-Test-Types) `GET`  
- [Update Standardized Tests: Test Types](Update-Standardized-Tests:-Test-Types) `PATCH`  


### Standardized Tests: Tests


- [Create Standardized Tests: Tests](Create-Standardized-Tests:-Tests) `POST`  
- [List Standardized Tests: Tests](List-Standardized-Tests:-Tests) `GET`  
- [Read Standardized Tests: Tests](Read-Standardized-Tests:-Tests) `GET`  
- [Update Standardized Tests: Tests](Update-Standardized-Tests:-Tests) `PATCH`  


### Student Logistics Requests


- [Create Student Logistics Requests](Create-Student-Logistics-Requests) `POST`  
- [List Student Logistics Requests](List-Student-Logistics-Requests) `GET`  
- [Delete Student Logistics Requests](Delete-Student-Logistics-Requests) `DELETE`  
- [Read Student Logistics Requests](Read-Student-Logistics-Requests) `GET`  
- [Update Student Logistics Requests](Update-Student-Logistics-Requests) `PATCH`  


### Student Logistics Requests: Categories


- [List Student Logistics Requests: Categories](List-Student-Logistics-Requests:-Categories) `GET`  


### Student Logistics Requests: Drop-Ins


- [List Student Logistics Requests: Drop-Ins](List-Student-Logistics-Requests:-Drop-Ins) `GET`  


### Student Logistics Requests: Reasons


- [List Student Logistics Requests: Reasons](List-Student-Logistics-Requests:-Reasons) `GET`  


### Students


- [List Students](List-Students) `GET`  
- [Read Students](Read-Students) `GET`  


### Summer: Class Attendance


- [List Summer: Class Attendance](List-Summer:-Class-Attendance) `GET`  
- [Read Summer: Class Attendance](Read-Summer:-Class-Attendance) `GET`  
- [Update Summer: Class Attendance](Update-Summer:-Class-Attendance) `PATCH`  


### Summer: Class Meeting Times


- [List Summer: Class Meeting Times](List-Summer:-Class-Meeting-Times) `GET`  
- [Read Summer: Class Meeting Times](Read-Summer:-Class-Meeting-Times) `GET`  


### Summer: Classes


- [Create Summer: Classes](Create-Summer:-Classes) `POST`  
- [List Summer: Classes](List-Summer:-Classes) `GET`  
- [Read Summer: Classes](Read-Summer:-Classes) `GET`  
- [Update Summer: Classes](Update-Summer:-Classes) `PATCH`  


### Summer: Courses


- [List Summer: Courses](List-Summer:-Courses) `GET`  
- [Create Summer: Courses](Create-Summer:-Courses) `POST`  
- [Read Summer: Courses](Read-Summer:-Courses) `GET`  
- [Update Summer: Courses](Update-Summer:-Courses) `PATCH`  


### Summer: Enrollments


- [List Summer: Enrollments](List-Summer:-Enrollments) `GET`  
- [Create Summer: Enrollments](Create-Summer:-Enrollments) `POST`  
- [Read Summer: Enrollments](Read-Summer:-Enrollments) `GET`  
- [Update Summer: Enrollments](Update-Summer:-Enrollments) `PATCH`  


### Transcripts: Academic Classifications


- [List Transcripts: Academic Classifications](List-Transcripts:-Academic-Classifications) `GET`  
- [Read Transcripts: Academic Classifications](Read-Transcripts:-Academic-Classifications) `GET`  


### Transcripts: GPAs


- [List Transcripts: GPAs](List-Transcripts:-GPAs) `GET`  
- [Read Transcripts: GPAs](Read-Transcripts:-GPAs) `GET`  


### Transcripts: Student Information


- [Read Transcripts: Student Information](Read-Transcripts:-Student-Information) `GET`  
- [List Transcripts: Student Information](List-Transcripts:-Student-Information) `GET`  


### Transcripts: Transcript Items


- [List Transcripts: Transcript Items](List-Transcripts:-Transcript-Items) `GET`  


### Transportation: Bus Routes


- [List Transportation: Bus Routes](List-Transportation:-Bus-Routes) `GET`  
- [Read Transportation: Bus Routes](Read-Transportation:-Bus-Routes) `GET`  


### Transportation: Bus Stops


- [List Transportation: Bus Stops](List-Transportation:-Bus-Stops) `GET`  
- [Read Transportation: Bus Stops](Read-Transportation:-Bus-Stops) `GET`  


### Transportation: Bus Trips


- [List Transportation: Bus Trips](List-Transportation:-Bus-Trips) `GET`  
- [Read Transportation: Bus Trips](Read-Transportation:-Bus-Trips) `GET`  


### Transportation: Schedules


- [List Transportation: Schedules](List-Transportation:-Schedules) `GET`  
- [Read Transportation: Schedules](Read-Transportation:-Schedules) `GET`  


### Transportation: Trips


- [Read Transportation: Trips](Read-Transportation:-Trips) `GET`  
- [List Transportation: Trips](List-Transportation:-Trips) `GET`  


### Volunteer Coordinator: Volunteers


- [List Volunteer Coordinator: Volunteers](List-Volunteer-Coordinator:-Volunteers) `GET`  
- [Read Volunteer Coordinator: Volunteers](Read-Volunteer-Coordinator:-Volunteers) `GET`  


### Withdrawal Reasons


- [List Withdrawal Reasons](List-Withdrawal-Reasons) `GET`  


### Schemas


- [post](data-api-post)  
- [error](data-api-error)  


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
