> [Home](Home) · [Concepts](Concepts/General%20Principles) · [Guides](Guides/Making%20a%20Data%20API%20Request) · [Diagrams](Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](Changelog/Data%20API) · [Data API](Data%20API) · [Authorization API](Authorization%20API) · [Files API](Files%20API)
>
> Data API · [source site](https://api-docs.veracross.com/)

---


# Overview: Data API


This service documents **442** operations/schemas across **169** groups.


### Academics: Assignment Grades


- [List Academics: Assignment Grades](Data%20API/List%20Academics:%20Assignment%20Grades) `GET`  
- [Read Academics: Assignment Grades](Data%20API/Read%20Academics:%20Assignment%20Grades) `GET`  
- [Update Academics: Assignment Grades](Data%20API/Update%20Academics:%20Assignment%20Grades) `PATCH`  


### Academics: Block Groups


- [List Academics: Block Groups](Data%20API/List%20Academics:%20Block%20Groups) `GET`  
- [Read Academics: Block Groups](Data%20API/Read%20Academics:%20Block%20Groups) `GET`  


### Academics: Blocks by Group


- [List Academics: Blocks by Group](Data%20API/List%20Academics:%20Blocks%20by%20Group) `GET`  
- [Read Academics: Blocks by Group](Data%20API/Read%20Academics:%20Blocks%20by%20Group) `GET`  


### Academics: Calendar Rotation Days


- [List Academics: Calendar Rotation Days](Data%20API/List%20Academics:%20Calendar%20Rotation%20Days) `GET`  
- [Read Academics: Calendar Rotation Days](Data%20API/Read%20Academics:%20Calendar%20Rotation%20Days) `GET`  


### Academics: Class Assignments


- [Create Academics: Class Assignments](Data%20API/Create%20Academics:%20Class%20Assignments) `POST`  
- [List Academics: Class Assignments](Data%20API/List%20Academics:%20Class%20Assignments) `GET`  
- [Delete Academics: Class Assignments](Data%20API/Delete%20Academics:%20Class%20Assignments) `DELETE`  
- [Read Academics: Class Assignments](Data%20API/Read%20Academics:%20Class%20Assignments) `GET`  
- [Update Academics: Class Assignments](Data%20API/Update%20Academics:%20Class%20Assignments) `PATCH`  


### Academics: Class Attendance Status


- [List Academics: Class Attendance Status](Data%20API/List%20Academics:%20Class%20Attendance%20Status) `GET`  
- [Read Academics: Class Attendance Status](Data%20API/Read%20Academics:%20Class%20Attendance%20Status) `GET`  
- [Update Academics: Class Attendance Status](Data%20API/Update%20Academics:%20Class%20Attendance%20Status) `PATCH`  


### Academics: Class Meeting Times


- [List Academics: Class Meeting Times](Data%20API/List%20Academics:%20Class%20Meeting%20Times) `GET`  
- [Read Academics: Class Meeting Times](Data%20API/Read%20Academics:%20Class%20Meeting%20Times) `GET`  


### Academics: Class Schedules


- [List Academics: Class Schedules](Data%20API/List%20Academics:%20Class%20Schedules) `GET`  


### Academics: Classes


- [List Academics: Classes](Data%20API/List%20Academics:%20Classes) `GET`  
- [Create Academics: Classes](Data%20API/Create%20Academics:%20Classes) `POST`  
- [Read Academics: Classes](Data%20API/Read%20Academics:%20Classes) `GET`  
- [Update Academics: Classes](Data%20API/Update%20Academics:%20Classes) `PATCH`  


### Academics: Classes - Permissions


- [List Academics: Classes - Permissions](Data%20API/List%20Academics:%20Classes%20-%20Permissions) `GET`  
- [Read Academics: Classes - Permissions](Data%20API/Read%20Academics:%20Classes%20-%20Permissions) `GET`  


### Academics: Configuration - Block Meeting Times


- [List Academics: Configuration - Block Meeting Times](Data%20API/List%20Academics:%20Configuration%20-%20Block%20Meeting%20Times) `GET`  
- [Read Academics: Configuration - Block Meeting Times](Data%20API/Read%20Academics:%20Configuration%20-%20Block%20Meeting%20Times) `GET`  


### Academics: Configuration - Block Schedules


- [List Academics: Configuration - Block Schedules](Data%20API/List%20Academics:%20Configuration%20-%20Block%20Schedules) `GET`  
- [Read Academics: Configuration - Block Schedules](Data%20API/Read%20Academics:%20Configuration%20-%20Block%20Schedules) `GET`  


### Academics: Configuration - Blocks/Periods


- [List Academics: Configuration - Blocks/Periods](Data%20API/List%20Academics:%20Configuration%20-%20Blocks-Periods) `GET`  
- [Read Academics: Configuration - Blocks/Periods](Data%20API/Read%20Academics:%20Configuration%20-%20Blocks-Periods) `GET`  


### Academics: Configuration - Grade Levels


- [List Academics: Configuration - Grade Levels](Data%20API/List%20Academics:%20Configuration%20-%20Grade%20Levels) `GET`  


### Academics: Courses


- [Create Academics: Courses](Data%20API/Create%20Academics:%20Courses) `POST`  
- [List Academics: Courses](Data%20API/List%20Academics:%20Courses) `GET`  
- [Read Academics: Courses](Data%20API/Read%20Academics:%20Courses) `GET`  
- [Update Academics: Courses](Data%20API/Update%20Academics:%20Courses) `PATCH`  


### Academics: Departments


- [List Academics: Departments](Data%20API/List%20Academics:%20Departments) `GET`  
- [Read Academics: Departments](Data%20API/Read%20Academics:%20Departments) `GET`  


### Academics: Enrollments


- [List Academics: Enrollments](Data%20API/List%20Academics:%20Enrollments) `GET`  
- [Create Academics: Enrollments](Data%20API/Create%20Academics:%20Enrollments) `POST`  
- [Read Academics: Enrollments](Data%20API/Read%20Academics:%20Enrollments) `GET`  
- [Update Academics: Enrollments](Data%20API/Update%20Academics:%20Enrollments) `PATCH`  


### Academics: Grading Periods


- [List Academics: Grading Periods](Data%20API/List%20Academics:%20Grading%20Periods) `GET`  
- [Read Academics: Grading Periods](Data%20API/Read%20Academics:%20Grading%20Periods) `GET`  


### Academics: Numeric Grades


- [Read Academics: Numeric Grades](Data%20API/Read%20Academics:%20Numeric%20Grades) `GET`  
- [Update Academics: Numeric Grades](Data%20API/Update%20Academics:%20Numeric%20Grades) `PATCH`  
- [List Academics: Numeric Grades](Data%20API/List%20Academics:%20Numeric%20Grades) `GET`  


### Academics: Qualitative Grades


- [Read Academics: Qualitative Grades](Data%20API/Read%20Academics:%20Qualitative%20Grades) `GET`  
- [Update Academics: Qualitative Grades](Data%20API/Update%20Academics:%20Qualitative%20Grades) `PATCH`  
- [List Academics: Qualitative Grades](Data%20API/List%20Academics:%20Qualitative%20Grades) `GET`  


### Academics: Rooms


- [List Academics: Rooms](Data%20API/List%20Academics:%20Rooms) `GET`  
- [Read Academics: Rooms](Data%20API/Read%20Academics:%20Rooms) `GET`  


### Academics: Rotation Days


- [List Academics: Rotation Days](Data%20API/List%20Academics:%20Rotation%20Days) `GET`  
- [Read Academics: Rotation Days](Data%20API/Read%20Academics:%20Rotation%20Days) `GET`  


### Academics: Rubric Categories


- [Create Academics: Rubric Categories](Data%20API/Create%20Academics:%20Rubric%20Categories) `POST`  
- [List Academics: Rubric Categories](Data%20API/List%20Academics:%20Rubric%20Categories) `GET`  
- [Read Academics: Rubric Categories](Data%20API/Read%20Academics:%20Rubric%20Categories) `GET`  
- [Update Academics: Rubric Categories](Data%20API/Update%20Academics:%20Rubric%20Categories) `PATCH`  


### Academics: Rubric Criteria


- [Create Academics: Rubric Criteria](Data%20API/Create%20Academics:%20Rubric%20Criteria) `POST`  
- [List Academics: Rubric Criteria](Data%20API/List%20Academics:%20Rubric%20Criteria) `GET`  
- [Read Academics: Rubric Criteria](Data%20API/Read%20Academics:%20Rubric%20Criteria) `GET`  
- [Update Academics: Rubric Criteria](Data%20API/Update%20Academics:%20Rubric%20Criteria) `PATCH`  


### Academics: Rubric Scales


- [Create Academics: Rubric Scales](Data%20API/Create%20Academics:%20Rubric%20Scales) `POST`  
- [List Academics: Rubric Scales](Data%20API/List%20Academics:%20Rubric%20Scales) `GET`  
- [Read Academics: Rubric Scales](Data%20API/Read%20Academics:%20Rubric%20Scales) `GET`  
- [Update Academics: Rubric Scales](Data%20API/Update%20Academics:%20Rubric%20Scales) `PATCH`  


### Academics: Rubric Scales - Levels


- [Create Academics: Rubric Scales - Levels](Data%20API/Create%20Academics:%20Rubric%20Scales%20-%20Levels) `POST`  
- [List Academics: Rubric Scales - Levels](Data%20API/List%20Academics:%20Rubric%20Scales%20-%20Levels) `GET`  
- [Read Academics: Rubric Scales - Levels](Data%20API/Read%20Academics:%20Rubric%20Scales%20-%20Levels) `GET`  
- [Update Academics: Rubric Scales - Levels](Data%20API/Update%20Academics:%20Rubric%20Scales%20-%20Levels) `PATCH`  


### Academics: Rubrics


- [Create Academics: Rubrics](Data%20API/Create%20Academics:%20Rubrics) `POST`  
- [List Academics: Rubrics](Data%20API/List%20Academics:%20Rubrics) `GET`  
- [Read Academics: Rubrics](Data%20API/Read%20Academics:%20Rubrics) `GET`  
- [Update Academics: Rubrics](Data%20API/Update%20Academics:%20Rubrics) `PATCH`  


### Academics: Student Alerts


- [List Academics: Student Alerts](Data%20API/List%20Academics:%20Student%20Alerts) `GET`  
- [Read Academics: Student Alerts](Data%20API/Read%20Academics:%20Student%20Alerts) `GET`  
- [Update Academics: Student Alerts](Data%20API/Update%20Academics:%20Student%20Alerts) `PATCH`  


### Academics: Student Assignments


- [List Academics: Student Assignments](Data%20API/List%20Academics:%20Student%20Assignments) `GET`  
- [Read Academics: Student Assignments](Data%20API/Read%20Academics:%20Student%20Assignments) `GET`  


### Academics: Student Daily Schedules


- [List Academics: Student Daily Schedules](Data%20API/List%20Academics:%20Student%20Daily%20Schedules) `GET`  


### Academics: Subjects


- [List Academics: Subjects](Data%20API/List%20Academics:%20Subjects) `GET`  
- [Read Academics: Subjects](Data%20API/Read%20Academics:%20Subjects) `GET`  


### Academics: Teacher Daily Schedules


- [List Academics: Teacher Daily Schedules](Data%20API/List%20Academics:%20Teacher%20Daily%20Schedules) `GET`  


### Admission: Applicant Relationships


- [Create Admission: Applicant Relationships](Data%20API/Create%20Admission:%20Applicant%20Relationships) `POST`  
- [List Admission: Applicant Relationships](Data%20API/List%20Admission:%20Applicant%20Relationships) `GET`  
- [Read Admission: Applicant Relationships](Data%20API/Read%20Admission:%20Applicant%20Relationships) `GET`  
- [Update Admission: Applicant Relationships](Data%20API/Update%20Admission:%20Applicant%20Relationships) `PATCH`  


### Admission: Applicants


- [Create Admission: Applicants](Data%20API/Create%20Admission:%20Applicants) `POST`  
- [List Admission: Applicants](Data%20API/List%20Admission:%20Applicants) `GET`  
- [Read Admission: Applicants](Data%20API/Read%20Admission:%20Applicants) `GET`  
- [Update Admission: Applicants](Data%20API/Update%20Admission:%20Applicants) `PATCH`  


### Admission: Application Checklists


- [List Admission: Application Checklists](Data%20API/List%20Admission:%20Application%20Checklists) `GET`  
- [Read Admission: Application Checklists](Data%20API/Read%20Admission:%20Application%20Checklists) `GET`  
- [Update Admission: Application Checklists](Data%20API/Update%20Admission:%20Application%20Checklists) `PATCH`  


### Admission: Applications


- [Create Admission: Applications](Data%20API/Create%20Admission:%20Applications) `POST`  
- [List Admission: Applications](Data%20API/List%20Admission:%20Applications) `GET`  
- [Read Admission: Applications](Data%20API/Read%20Admission:%20Applications) `GET`  
- [Update Admission: Applications](Data%20API/Update%20Admission:%20Applications) `PATCH`  


### Admission: Citizenships


- [Create Admission: Citizenships](Data%20API/Create%20Admission:%20Citizenships) `POST`  
- [List Admission: Citizenships](Data%20API/List%20Admission:%20Citizenships) `GET`  
- [Read Admission: Citizenships](Data%20API/Read%20Admission:%20Citizenships) `GET`  
- [Update Admission: Citizenships](Data%20API/Update%20Admission:%20Citizenships) `PATCH`  


### Admission: Configuration - Checklists


- [List Admission: Configuration - Checklists](Data%20API/List%20Admission:%20Configuration%20-%20Checklists) `GET`  
- [Read Admission: Configuration - Checklists](Data%20API/Read%20Admission:%20Configuration%20-%20Checklists) `GET`  


### Admission: Configuration - Years


- [List Admission: Configuration - Years](Data%20API/List%20Admission:%20Configuration%20-%20Years) `GET`  
- [Read Admission: Configuration - Years](Data%20API/Read%20Admission:%20Configuration%20-%20Years) `GET`  


### Admission: Household Members


- [List Admission: Household Members](Data%20API/List%20Admission:%20Household%20Members) `GET`  


### Admission: Households


- [List Admission: Households](Data%20API/List%20Admission:%20Households) `GET`  
- [Read Admission: Households](Data%20API/Read%20Admission:%20Households) `GET`  
- [Update Admission: Households](Data%20API/Update%20Admission:%20Households) `PATCH`  


### Admission: Languages


- [Create Admission: Languages](Data%20API/Create%20Admission:%20Languages) `POST`  
- [List Admission: Languages](Data%20API/List%20Admission:%20Languages) `GET`  
- [Read Admission: Languages](Data%20API/Read%20Admission:%20Languages) `GET`  
- [Update Admission: Languages](Data%20API/Update%20Admission:%20Languages) `PATCH`  


### Admission: Relative Relationships


- [Create Admission: Relative Relationships](Data%20API/Create%20Admission:%20Relative%20Relationships) `POST`  
- [List Admission: Relative Relationships](Data%20API/List%20Admission:%20Relative%20Relationships) `GET`  
- [Read Admission: Relative Relationships](Data%20API/Read%20Admission:%20Relative%20Relationships) `GET`  
- [Update Admission: Relative Relationships](Data%20API/Update%20Admission:%20Relative%20Relationships) `PATCH`  


### Admission: Relatives


- [List Admission: Relatives](Data%20API/List%20Admission:%20Relatives) `GET`  
- [Create Admission: Relatives](Data%20API/Create%20Admission:%20Relatives) `POST`  
- [Read Admission: Relatives](Data%20API/Read%20Admission:%20Relatives) `GET`  
- [Update Admission: Relatives](Data%20API/Update%20Admission:%20Relatives) `PATCH`  


### Alumni: Demographics


- [List Alumni: Demographics](Data%20API/List%20Alumni:%20Demographics) `GET`  
- [Read Alumni: Demographics](Data%20API/Read%20Alumni:%20Demographics) `GET`  


### Athletics: Rosters


- [Create Athletics: Rosters](Data%20API/Create%20Athletics:%20Rosters) `POST`  
- [List Athletics: Rosters](Data%20API/List%20Athletics:%20Rosters) `GET`  
- [Read Athletics: Rosters](Data%20API/Read%20Athletics:%20Rosters) `GET`  
- [Update Athletics: Rosters](Data%20API/Update%20Athletics:%20Rosters) `PATCH`  


### Athletics: Sports


- [List Athletics: Sports](Data%20API/List%20Athletics:%20Sports) `GET`  
- [Create Athletics: Sports](Data%20API/Create%20Athletics:%20Sports) `POST`  
- [Read Athletics: Sports](Data%20API/Read%20Athletics:%20Sports) `GET`  
- [Update Athletics: Sports](Data%20API/Update%20Athletics:%20Sports) `PATCH`  


### Athletics: Team - Coaches


- [List Athletics: Team - Coaches](Data%20API/List%20Athletics:%20Team%20-%20Coaches) `GET`  


### Athletics: Team Practice Schedules


- [List Athletics: Team Practice Schedules](Data%20API/List%20Athletics:%20Team%20Practice%20Schedules) `GET`  


### Athletics: Teams


- [Create Athletics: Teams](Data%20API/Create%20Athletics:%20Teams) `POST`  
- [List Athletics: Teams](Data%20API/List%20Athletics:%20Teams) `GET`  
- [Read Athletics: Teams](Data%20API/Read%20Athletics:%20Teams) `GET`  
- [Update Athletics: Teams](Data%20API/Update%20Athletics:%20Teams) `PATCH`  


### Attendance Status Codes


- [List Attendance Status Codes](Data%20API/List%20Attendance%20Status%20Codes) `GET`  


### Behavior


- [Create Behavior](Data%20API/Create%20Behavior) `POST`  
- [List Behavior](Data%20API/List%20Behavior) `GET`  
- [Read Behavior](Data%20API/Read%20Behavior) `GET`  
- [Update Behavior](Data%20API/Update%20Behavior) `PATCH`  


### Behavior Incident Types


- [List Behavior Incident Types](Data%20API/List%20Behavior%20Incident%20Types) `GET`  
- [Read Behavior Incident Types](Data%20API/Read%20Behavior%20Incident%20Types) `GET`  
- [Update Behavior Incident Types](Data%20API/Update%20Behavior%20Incident%20Types) `PATCH`  


### Boarding: Dorm Attendance


- [List Boarding: Dorm Attendance](Data%20API/List%20Boarding:%20Dorm%20Attendance) `GET`  
- [Read Boarding: Dorm Attendance](Data%20API/Read%20Boarding:%20Dorm%20Attendance) `GET`  
- [Update Boarding: Dorm Attendance](Data%20API/Update%20Boarding:%20Dorm%20Attendance) `PATCH`  


### Boarding: Dorm Students


- [List Boarding: Dorm Students](Data%20API/List%20Boarding:%20Dorm%20Students) `GET`  
- [Read Boarding: Dorm Students](Data%20API/Read%20Boarding:%20Dorm%20Students) `GET`  
- [Update Boarding: Dorm Students](Data%20API/Update%20Boarding:%20Dorm%20Students) `PATCH`  


### Boarding: Dorms


- [List Boarding: Dorms](Data%20API/List%20Boarding:%20Dorms) `GET`  
- [Read Boarding: Dorms](Data%20API/Read%20Boarding:%20Dorms) `GET`  


### Calendars: Parent Calendars


- [List Calendars: Parent Calendars](Data%20API/List%20Calendars:%20Parent%20Calendars) `GET`  


### Calendars: Student Calendars


- [List Calendars: Student Calendars](Data%20API/List%20Calendars:%20Student%20Calendars) `GET`  


### Class - Permissions


- [List Class - Permissions](Data%20API/List%20Class%20-%20Permissions) `GET`  


### Class Attendance


- [List Class Attendance](Data%20API/List%20Class%20Attendance) `GET`  
- [Read Class Attendance](Data%20API/Read%20Class%20Attendance) `GET`  
- [Update Class Attendance](Data%20API/Update%20Class%20Attendance) `PATCH`  


### Classes


- [List Classes](Data%20API/List%20Classes) `GET`  
- [Read Classes](Data%20API/Read%20Classes) `GET`  


### Contact Info


- [List Contact Info](Data%20API/List%20Contact%20Info) `GET`  
- [Read Contact Info](Data%20API/Read%20Contact%20Info) `GET`  
- [Update Contact Info](Data%20API/Update%20Contact%20Info) `PATCH`  


### Convert Parent Account to Staff Account


- [Create Convert Parent Account to Staff Account](Data%20API/Create%20Convert%20Parent%20Account%20to%20Staff%20Account) `POST`  


### Courses


- [List Courses](Data%20API/List%20Courses) `GET`  
- [Read Courses](Data%20API/Read%20Courses) `GET`  
- [Update Courses](Data%20API/Update%20Courses) `PATCH`  


### Development: Constituents


- [List Development: Constituents](Data%20API/List%20Development:%20Constituents) `GET`  
- [Read Development: Constituents](Data%20API/Read%20Development:%20Constituents) `GET`  


### Development: Gifts


- [List Development: Gifts](Data%20API/List%20Development:%20Gifts) `GET`  
- [Read Development: Gifts](Data%20API/Read%20Development:%20Gifts) `GET`  


### Directory Preferences: Household


- [List Directory Preferences: Household](Data%20API/List%20Directory%20Preferences:%20Household) `GET`  
- [Read Directory Preferences: Household](Data%20API/Read%20Directory%20Preferences:%20Household) `GET`  
- [Update Directory Preferences: Household](Data%20API/Update%20Directory%20Preferences:%20Household) `PATCH`  


### Directory Preferences: Person


- [List Directory Preferences: Person](Data%20API/List%20Directory%20Preferences:%20Person) `GET`  
- [Read Directory Preferences: Person](Data%20API/Read%20Directory%20Preferences:%20Person) `GET`  
- [Update Directory Preferences: Person](Data%20API/Update%20Directory%20Preferences:%20Person) `PATCH`  


### Directory Type Configurations


- [List Directory Type Configurations](Data%20API/List%20Directory%20Type%20Configurations) `GET`  


### Directory: Household


- [List Directory: Household](Data%20API/List%20Directory:%20Household) `GET`  


### Directory: Staff/Faculty


- [List Directory: Staff/Faculty](Data%20API/List%20Directory:%20Staff-Faculty) `GET`  


### Directory: Student


- [List Directory: Student](Data%20API/List%20Directory:%20Student) `GET`  


### Emergency Contacts


- [Create Emergency Contacts](Data%20API/Create%20Emergency%20Contacts) `POST`  
- [List Emergency Contacts](Data%20API/List%20Emergency%20Contacts) `GET`  
- [Delete Emergency Contacts](Data%20API/Delete%20Emergency%20Contacts) `DELETE`  
- [Read Emergency Contacts](Data%20API/Read%20Emergency%20Contacts) `GET`  
- [Update Emergency Contacts](Data%20API/Update%20Emergency%20Contacts) `PATCH`  


### Ethnicities


- [List Ethnicities](Data%20API/List%20Ethnicities) `GET`  


### Event Groups


- [Create Event Groups](Data%20API/Create%20Event%20Groups) `POST`  
- [List Event Groups](Data%20API/List%20Event%20Groups) `GET`  
- [Delete Event Groups](Data%20API/Delete%20Event%20Groups) `DELETE`  
- [Read Event Groups](Data%20API/Read%20Event%20Groups) `GET`  


### Event Groups Members


- [List Event Groups Members](Data%20API/List%20Event%20Groups%20Members) `GET`  


### Event Representatives


- [List Event Representatives](Data%20API/List%20Event%20Representatives) `GET`  


### Events


- [Read Events](Data%20API/Read%20Events) `GET`  
- [Update Events](Data%20API/Update%20Events) `PATCH`  
- [Create Events](Data%20API/Create%20Events) `POST`  
- [List Events](Data%20API/List%20Events) `GET`  


### Events: Athletics


- [Create Events: Athletics](Data%20API/Create%20Events:%20Athletics) `POST`  
- [List Events: Athletics](Data%20API/List%20Events:%20Athletics) `GET`  
- [Read Events: Athletics](Data%20API/Read%20Events:%20Athletics) `GET`  
- [Update Events: Athletics](Data%20API/Update%20Events:%20Athletics) `PATCH`  


### Events: Athletics Opponents


- [List Events: Athletics Opponents](Data%20API/List%20Events:%20Athletics%20Opponents) `GET`  
- [Read Events: Athletics Opponents](Data%20API/Read%20Events:%20Athletics%20Opponents) `GET`  


### Events: Athletics Scores


- [Read Events: Athletics Scores](Data%20API/Read%20Events:%20Athletics%20Scores) `GET`  
- [Update Events: Athletics Scores](Data%20API/Update%20Events:%20Athletics%20Scores) `PATCH`  


### Events: Attendance


- [Create Events: Attendance](Data%20API/Create%20Events:%20Attendance) `POST`  
- [List Events: Attendance](Data%20API/List%20Events:%20Attendance) `GET`  
- [Delete Events: Attendance](Data%20API/Delete%20Events:%20Attendance) `DELETE`  
- [Read Events: Attendance](Data%20API/Read%20Events:%20Attendance) `GET`  
- [Update Events: Attendance](Data%20API/Update%20Events:%20Attendance) `PATCH`  


### Extended Care: Class Attendance


- [List Extended Care: Class Attendance](Data%20API/List%20Extended%20Care:%20Class%20Attendance) `GET`  
- [Read Extended Care: Class Attendance](Data%20API/Read%20Extended%20Care:%20Class%20Attendance) `GET`  


### Extended Care: Class Meeting Times


- [List Extended Care: Class Meeting Times](Data%20API/List%20Extended%20Care:%20Class%20Meeting%20Times) `GET`  
- [Read Extended Care: Class Meeting Times](Data%20API/Read%20Extended%20Care:%20Class%20Meeting%20Times) `GET`  


### Extended Care: Classes


- [Create Extended Care: Classes](Data%20API/Create%20Extended%20Care:%20Classes) `POST`  
- [List Extended Care: Classes](Data%20API/List%20Extended%20Care:%20Classes) `GET`  
- [Read Extended Care: Classes](Data%20API/Read%20Extended%20Care:%20Classes) `GET`  
- [Update Extended Care: Classes](Data%20API/Update%20Extended%20Care:%20Classes) `PATCH`  


### Extended Care: Courses


- [List Extended Care: Courses](Data%20API/List%20Extended%20Care:%20Courses) `GET`  
- [Create Extended Care: Courses](Data%20API/Create%20Extended%20Care:%20Courses) `POST`  
- [Read Extended Care: Courses](Data%20API/Read%20Extended%20Care:%20Courses) `GET`  
- [Update Extended Care: Courses](Data%20API/Update%20Extended%20Care:%20Courses) `PATCH`  


### Extended Care: Registrations


- [List Extended Care: Registrations](Data%20API/List%20Extended%20Care:%20Registrations) `GET`  
- [Read Extended Care: Registrations](Data%20API/Read%20Extended%20Care:%20Registrations) `GET`  


### External User Accounts


- [List External User Accounts](Data%20API/List%20External%20User%20Accounts) `GET`  
- [Create External User Accounts](Data%20API/Create%20External%20User%20Accounts) `POST`  
- [Read External User Accounts](Data%20API/Read%20External%20User%20Accounts) `GET`  
- [Update External User Accounts](Data%20API/Update%20External%20User%20Accounts) `PATCH`  


### Finance: AP Disbursement Items


- [Create Finance: AP Disbursement Items](Data%20API/Create%20Finance:%20AP%20Disbursement%20Items) `POST`  
- [List Finance: AP Disbursement Items](Data%20API/List%20Finance:%20AP%20Disbursement%20Items) `GET`  
- [Read Finance: AP Disbursement Items](Data%20API/Read%20Finance:%20AP%20Disbursement%20Items) `GET`  
- [Update Finance: AP Disbursement Items](Data%20API/Update%20Finance:%20AP%20Disbursement%20Items) `PATCH`  


### Finance: AP Disbursements


- [Create Finance: AP Disbursements](Data%20API/Create%20Finance:%20AP%20Disbursements) `POST`  
- [List Finance: AP Disbursements](Data%20API/List%20Finance:%20AP%20Disbursements) `GET`  
- [Read Finance: AP Disbursements](Data%20API/Read%20Finance:%20AP%20Disbursements) `GET`  
- [Update Finance: AP Disbursements](Data%20API/Update%20Finance:%20AP%20Disbursements) `PATCH`  


### Finance: AP Invoice Items


- [Create Finance: AP Invoice Items](Data%20API/Create%20Finance:%20AP%20Invoice%20Items) `POST`  
- [List Finance: AP Invoice Items](Data%20API/List%20Finance:%20AP%20Invoice%20Items) `GET`  
- [Read Finance: AP Invoice Items](Data%20API/Read%20Finance:%20AP%20Invoice%20Items) `GET`  
- [Update Finance: AP Invoice Items](Data%20API/Update%20Finance:%20AP%20Invoice%20Items) `PATCH`  


### Finance: AP Invoices


- [Create Finance: AP Invoices](Data%20API/Create%20Finance:%20AP%20Invoices) `POST`  
- [List Finance: AP Invoices](Data%20API/List%20Finance:%20AP%20Invoices) `GET`  
- [Read Finance: AP Invoices](Data%20API/Read%20Finance:%20AP%20Invoices) `GET`  
- [Update Finance: AP Invoices](Data%20API/Update%20Finance:%20AP%20Invoices) `PATCH`  


### Finance: GL Accounts


- [List Finance: GL Accounts](Data%20API/List%20Finance:%20GL%20Accounts) `GET`  
- [Read Finance: GL Accounts](Data%20API/Read%20Finance:%20GL%20Accounts) `GET`  


### Finance: Post AP Invoices


- [Update Finance: Post AP Invoices](Data%20API/Update%20Finance:%20Post%20AP%20Invoices) `PATCH`  


### Finance: Projects


- [List Finance: Projects](Data%20API/List%20Finance:%20Projects) `GET`  
- [Read Finance: Projects](Data%20API/Read%20Finance:%20Projects) `GET`  


### Finance: Purchase Request Workflow


- [List Finance: Purchase Request Workflow](Data%20API/List%20Finance:%20Purchase%20Request%20Workflow) `GET`  
- [Read Finance: Purchase Request Workflow](Data%20API/Read%20Finance:%20Purchase%20Request%20Workflow) `GET`  


### Finance: Purchase Request Workflow GL Accounts


- [List Finance: Purchase Request Workflow GL Accounts](Data%20API/List%20Finance:%20Purchase%20Request%20Workflow%20GL%20Accounts) `GET`  


### Finance: Tax Types


- [List Finance: Tax Types](Data%20API/List%20Finance:%20Tax%20Types) `GET`  
- [Read Finance: Tax Types](Data%20API/Read%20Finance:%20Tax%20Types) `GET`  


### Finance: Vendors


- [Create Finance: Vendors](Data%20API/Create%20Finance:%20Vendors) `POST`  
- [List Finance: Vendors](Data%20API/List%20Finance:%20Vendors) `GET`  
- [Read Finance: Vendors](Data%20API/Read%20Finance:%20Vendors) `GET`  
- [Update Finance: Vendors](Data%20API/Update%20Finance:%20Vendors) `PATCH`  


### Genders


- [List Genders](Data%20API/List%20Genders) `GET`  


### Health: All Patients Conditions


- [List Health: All Patients Conditions](Data%20API/List%20Health:%20All%20Patients%20Conditions) `GET`  


### Health: Patient Conditions


- [List Health: Patient Conditions](Data%20API/List%20Health:%20Patient%20Conditions) `GET`  
- [Create Health: Patient Conditions](Data%20API/Create%20Health:%20Patient%20Conditions) `POST`  
- [Read Health: Patient Conditions](Data%20API/Read%20Health:%20Patient%20Conditions) `GET`  
- [Update Health: Patient Conditions](Data%20API/Update%20Health:%20Patient%20Conditions) `PATCH`  


### Health: Patient Medications


- [Create Health: Patient Medications](Data%20API/Create%20Health:%20Patient%20Medications) `POST`  
- [List Health: Patient Medications](Data%20API/List%20Health:%20Patient%20Medications) `GET`  
- [Read Health: Patient Medications](Data%20API/Read%20Health:%20Patient%20Medications) `GET`  
- [Update Health: Patient Medications](Data%20API/Update%20Health:%20Patient%20Medications) `PATCH`  


### Health: Patients


- [List Health: Patients](Data%20API/List%20Health:%20Patients) `GET`  
- [Read Health: Patients](Data%20API/Read%20Health:%20Patients) `GET`  
- [Update Health: Patients](Data%20API/Update%20Health:%20Patients) `PATCH`  


### Household Vehicles


- [List Household Vehicles](Data%20API/List%20Household%20Vehicles) `GET`  
- [Read Household Vehicles](Data%20API/Read%20Household%20Vehicles) `GET`  


### Households


- [List Households](Data%20API/List%20Households) `GET`  
- [Create Households](Data%20API/Create%20Households) `POST`  
- [Read Households](Data%20API/Read%20Households) `GET`  
- [Update Households](Data%20API/Update%20Households) `PATCH`  


### Master Attendance


- [List Master Attendance](Data%20API/List%20Master%20Attendance) `GET`  
- [Read Master Attendance](Data%20API/Read%20Master%20Attendance) `GET`  
- [Update Master Attendance](Data%20API/Update%20Master%20Attendance) `PATCH`  


### News


- [List News](Data%20API/List%20News) `GET`  
- [Read News](Data%20API/Read%20News) `GET`  


### Non-Academics: Classes


- [List Non-Academics: Classes](Data%20API/List%20Non-Academics:%20Classes) `GET`  
- [Create Non-Academics: Classes](Data%20API/Create%20Non-Academics:%20Classes) `POST`  
- [Read Non-Academics: Classes](Data%20API/Read%20Non-Academics:%20Classes) `GET`  
- [Update Non-Academics: Classes](Data%20API/Update%20Non-Academics:%20Classes) `PATCH`  


### Non-Academics: Courses


- [List Non-Academics: Courses](Data%20API/List%20Non-Academics:%20Courses) `GET`  
- [Create Non-Academics: Courses](Data%20API/Create%20Non-Academics:%20Courses) `POST`  
- [Read Non-Academics: Courses](Data%20API/Read%20Non-Academics:%20Courses) `GET`  
- [Update Non-Academics: Courses](Data%20API/Update%20Non-Academics:%20Courses) `PATCH`  


### Parents


- [List Parents](Data%20API/List%20Parents) `GET`  
- [Read Parents](Data%20API/Read%20Parents) `GET`  


### Person Accounts


- [Delete Person Accounts](Data%20API/Delete%20Person%20Accounts) `DELETE`  
- [Read Person Accounts](Data%20API/Read%20Person%20Accounts) `GET`  
- [List Person Accounts](Data%20API/List%20Person%20Accounts) `GET`  
- [Create Person Accounts](Data%20API/Create%20Person%20Accounts) `POST`  


### Person Citizenships


- [List Person Citizenships](Data%20API/List%20Person%20Citizenships) `GET`  
- [Read Person Citizenships](Data%20API/Read%20Person%20Citizenships) `GET`  


### Person Enrollment History


- [List Person Enrollment History](Data%20API/List%20Person%20Enrollment%20History) `GET`  
- [Read Person Enrollment History](Data%20API/Read%20Person%20Enrollment%20History) `GET`  


### Person Ethnicities


- [List Person Ethnicities](Data%20API/List%20Person%20Ethnicities) `GET`  


### Person Photo


- [List Person Photo](Data%20API/List%20Person%20Photo) `GET`  


### Person Profile Codes


- [Delete Person Profile Codes](Data%20API/Delete%20Person%20Profile%20Codes) `DELETE`  
- [Read Person Profile Codes](Data%20API/Read%20Person%20Profile%20Codes) `GET`  
- [List Person Profile Codes](Data%20API/List%20Person%20Profile%20Codes) `GET`  
- [Create Person Profile Codes](Data%20API/Create%20Person%20Profile%20Codes) `POST`  


### Person Reference Number


- [Create Person Reference Number](Data%20API/Create%20Person%20Reference%20Number) `POST`  
- [List Person Reference Number](Data%20API/List%20Person%20Reference%20Number) `GET`  
- [Delete Person Reference Number](Data%20API/Delete%20Person%20Reference%20Number) `DELETE`  
- [Read Person Reference Number](Data%20API/Read%20Person%20Reference%20Number) `GET`  
- [Update Person Reference Number](Data%20API/Update%20Person%20Reference%20Number) `PATCH`  


### Person Roles


- [Create Person Roles](Data%20API/Create%20Person%20Roles) `POST`  
- [List Person Roles](Data%20API/List%20Person%20Roles) `GET`  
- [Delete Person Roles](Data%20API/Delete%20Person%20Roles) `DELETE`  
- [Read Person Roles](Data%20API/Read%20Person%20Roles) `GET`  


### Person Visas


- [List Person Visas](Data%20API/List%20Person%20Visas) `GET`  
- [Read Person Visas](Data%20API/Read%20Person%20Visas) `GET`  
- [Update Person Visas](Data%20API/Update%20Person%20Visas) `PATCH`  


### Portal Membership


- [List Portal Membership](Data%20API/List%20Portal%20Membership) `GET`  
- [Read Portal Membership](Data%20API/Read%20Portal%20Membership) `GET`  
- [Update Portal Membership](Data%20API/Update%20Portal%20Membership) `PATCH`  


### Programs: Class Attendance


- [List Programs: Class Attendance](Data%20API/List%20Programs:%20Class%20Attendance) `GET`  
- [Read Programs: Class Attendance](Data%20API/Read%20Programs:%20Class%20Attendance) `GET`  
- [Update Programs: Class Attendance](Data%20API/Update%20Programs:%20Class%20Attendance) `PATCH`  


### Programs: Class Meeting Times


- [List Programs: Class Meeting Times](Data%20API/List%20Programs:%20Class%20Meeting%20Times) `GET`  
- [Read Programs: Class Meeting Times](Data%20API/Read%20Programs:%20Class%20Meeting%20Times) `GET`  


### Programs: Classes


- [Create Programs: Classes](Data%20API/Create%20Programs:%20Classes) `POST`  
- [List Programs: Classes](Data%20API/List%20Programs:%20Classes) `GET`  
- [Read Programs: Classes](Data%20API/Read%20Programs:%20Classes) `GET`  
- [Update Programs: Classes](Data%20API/Update%20Programs:%20Classes) `PATCH`  


### Programs: Courses


- [List Programs: Courses](Data%20API/List%20Programs:%20Courses) `GET`  
- [Create Programs: Courses](Data%20API/Create%20Programs:%20Courses) `POST`  
- [Read Programs: Courses](Data%20API/Read%20Programs:%20Courses) `GET`  
- [Update Programs: Courses](Data%20API/Update%20Programs:%20Courses) `PATCH`  


### Programs: Enrollments


- [List Programs: Enrollments](Data%20API/List%20Programs:%20Enrollments) `GET`  
- [Create Programs: Enrollments](Data%20API/Create%20Programs:%20Enrollments) `POST`  
- [Read Programs: Enrollments](Data%20API/Read%20Programs:%20Enrollments) `GET`  
- [Update Programs: Enrollments](Data%20API/Update%20Programs:%20Enrollments) `PATCH`  


### Relationships


- [List Relationships](Data%20API/List%20Relationships) `GET`  
- [Read Relationships](Data%20API/Read%20Relationships) `GET`  


### Relationships: DEPRECATED


- [List Relationships: DEPRECATED](Data%20API/List%20Relationships:%20DEPRECATED) `GET`  


### Report Cards: Academic Classifications


- [List Report Cards: Academic Classifications](Data%20API/List%20Report%20Cards:%20Academic%20Classifications) `GET`  
- [Read Report Cards: Academic Classifications](Data%20API/Read%20Report%20Cards:%20Academic%20Classifications) `GET`  


### Report Cards: Class Attendance


- [List Report Cards: Class Attendance](Data%20API/List%20Report%20Cards:%20Class%20Attendance) `GET`  


### Report Cards: Class Curriculum


- [List Report Cards: Class Curriculum](Data%20API/List%20Report%20Cards:%20Class%20Curriculum) `GET`  
- [Read Report Cards: Class Curriculum](Data%20API/Read%20Report%20Cards:%20Class%20Curriculum) `GET`  


### Report Cards: Class Teachers


- [List Report Cards: Class Teachers](Data%20API/List%20Report%20Cards:%20Class%20Teachers) `GET`  
- [Read Report Cards: Class Teachers](Data%20API/Read%20Report%20Cards:%20Class%20Teachers) `GET`  


### Report Cards: Daily Attendance


- [List Report Cards: Daily Attendance](Data%20API/List%20Report%20Cards:%20Daily%20Attendance) `GET`  


### Report Cards: Documents


- [Read Report Cards: Documents](Data%20API/Read%20Report%20Cards:%20Documents) `GET`  
- [List Report Cards: Documents](Data%20API/List%20Report%20Cards:%20Documents) `GET`  


### Report Cards: Enrollments


- [List Report Cards: Enrollments](Data%20API/List%20Report%20Cards:%20Enrollments) `GET`  
- [Read Report Cards: Enrollments](Data%20API/Read%20Report%20Cards:%20Enrollments) `GET`  


### Report Cards: GPAs


- [List Report Cards: GPAs](Data%20API/List%20Report%20Cards:%20GPAs) `GET`  
- [Read Report Cards: GPAs](Data%20API/Read%20Report%20Cards:%20GPAs) `GET`  


### Report Cards: Numeric Grades


- [List Report Cards: Numeric Grades](Data%20API/List%20Report%20Cards:%20Numeric%20Grades) `GET`  
- [Read Report Cards: Numeric Grades](Data%20API/Read%20Report%20Cards:%20Numeric%20Grades) `GET`  


### Report Cards: Qualitative Grades


- [List Report Cards: Qualitative Grades](Data%20API/List%20Report%20Cards:%20Qualitative%20Grades) `GET`  
- [Read Report Cards: Qualitative Grades](Data%20API/Read%20Report%20Cards:%20Qualitative%20Grades) `GET`  


### Resident Statuses


- [List Resident Statuses](Data%20API/List%20Resident%20Statuses) `GET`  


### Resource Reservations: Reservations


- [List Resource Reservations: Reservations](Data%20API/List%20Resource%20Reservations:%20Reservations) `GET`  
- [Create Resource Reservations: Reservations](Data%20API/Create%20Resource%20Reservations:%20Reservations) `POST`  
- [Read Resource Reservations: Reservations](Data%20API/Read%20Resource%20Reservations:%20Reservations) `GET`  
- [Update Resource Reservations: Reservations](Data%20API/Update%20Resource%20Reservations:%20Reservations) `PATCH`  


### Resource Reservations: Resources


- [Create Resource Reservations: Resources](Data%20API/Create%20Resource%20Reservations:%20Resources) `POST`  
- [List Resource Reservations: Resources](Data%20API/List%20Resource%20Reservations:%20Resources) `GET`  
- [Read Resource Reservations: Resources](Data%20API/Read%20Resource%20Reservations:%20Resources) `GET`  
- [Update Resource Reservations: Resources](Data%20API/Update%20Resource%20Reservations:%20Resources) `PATCH`  


### Security Roles


- [Create Security Roles](Data%20API/Create%20Security%20Roles) `POST`  
- [List Security Roles](Data%20API/List%20Security%20Roles) `GET`  
- [Delete Security Roles](Data%20API/Delete%20Security%20Roles) `DELETE`  


### Staff/Faculty


- [Create Staff/Faculty](Data%20API/Create%20Staff-Faculty) `POST`  
- [List Staff/Faculty](Data%20API/List%20Staff-Faculty) `GET`  
- [Read Staff/Faculty](Data%20API/Read%20Staff-Faculty) `GET`  
- [Update Staff/Faculty](Data%20API/Update%20Staff-Faculty) `PATCH`  


### Standardized Tests: Score Types


- [Create Standardized Tests: Score Types](Data%20API/Create%20Standardized%20Tests:%20Score%20Types) `POST`  
- [List Standardized Tests: Score Types](Data%20API/List%20Standardized%20Tests:%20Score%20Types) `GET`  
- [Read Standardized Tests: Score Types](Data%20API/Read%20Standardized%20Tests:%20Score%20Types) `GET`  
- [Update Standardized Tests: Score Types](Data%20API/Update%20Standardized%20Tests:%20Score%20Types) `PATCH`  


### Standardized Tests: Scores


- [List Standardized Tests: Scores](Data%20API/List%20Standardized%20Tests:%20Scores) `GET`  
- [Read Standardized Tests: Scores](Data%20API/Read%20Standardized%20Tests:%20Scores) `GET`  
- [Update Standardized Tests: Scores](Data%20API/Update%20Standardized%20Tests:%20Scores) `PATCH`  


### Standardized Tests: Test Types


- [Create Standardized Tests: Test Types](Data%20API/Create%20Standardized%20Tests:%20Test%20Types) `POST`  
- [List Standardized Tests: Test Types](Data%20API/List%20Standardized%20Tests:%20Test%20Types) `GET`  
- [Read Standardized Tests: Test Types](Data%20API/Read%20Standardized%20Tests:%20Test%20Types) `GET`  
- [Update Standardized Tests: Test Types](Data%20API/Update%20Standardized%20Tests:%20Test%20Types) `PATCH`  


### Standardized Tests: Tests


- [Create Standardized Tests: Tests](Data%20API/Create%20Standardized%20Tests:%20Tests) `POST`  
- [List Standardized Tests: Tests](Data%20API/List%20Standardized%20Tests:%20Tests) `GET`  
- [Read Standardized Tests: Tests](Data%20API/Read%20Standardized%20Tests:%20Tests) `GET`  
- [Update Standardized Tests: Tests](Data%20API/Update%20Standardized%20Tests:%20Tests) `PATCH`  


### Student Logistics Requests


- [Create Student Logistics Requests](Data%20API/Create%20Student%20Logistics%20Requests) `POST`  
- [List Student Logistics Requests](Data%20API/List%20Student%20Logistics%20Requests) `GET`  
- [Delete Student Logistics Requests](Data%20API/Delete%20Student%20Logistics%20Requests) `DELETE`  
- [Read Student Logistics Requests](Data%20API/Read%20Student%20Logistics%20Requests) `GET`  
- [Update Student Logistics Requests](Data%20API/Update%20Student%20Logistics%20Requests) `PATCH`  


### Student Logistics Requests: Categories


- [List Student Logistics Requests: Categories](Data%20API/List%20Student%20Logistics%20Requests:%20Categories) `GET`  


### Student Logistics Requests: Drop-Ins


- [List Student Logistics Requests: Drop-Ins](Data%20API/List%20Student%20Logistics%20Requests:%20Drop-Ins) `GET`  


### Student Logistics Requests: Reasons


- [List Student Logistics Requests: Reasons](Data%20API/List%20Student%20Logistics%20Requests:%20Reasons) `GET`  


### Students


- [List Students](Data%20API/List%20Students) `GET`  
- [Read Students](Data%20API/Read%20Students) `GET`  


### Summer: Class Attendance


- [List Summer: Class Attendance](Data%20API/List%20Summer:%20Class%20Attendance) `GET`  
- [Read Summer: Class Attendance](Data%20API/Read%20Summer:%20Class%20Attendance) `GET`  
- [Update Summer: Class Attendance](Data%20API/Update%20Summer:%20Class%20Attendance) `PATCH`  


### Summer: Class Meeting Times


- [List Summer: Class Meeting Times](Data%20API/List%20Summer:%20Class%20Meeting%20Times) `GET`  
- [Read Summer: Class Meeting Times](Data%20API/Read%20Summer:%20Class%20Meeting%20Times) `GET`  


### Summer: Classes


- [Create Summer: Classes](Data%20API/Create%20Summer:%20Classes) `POST`  
- [List Summer: Classes](Data%20API/List%20Summer:%20Classes) `GET`  
- [Read Summer: Classes](Data%20API/Read%20Summer:%20Classes) `GET`  
- [Update Summer: Classes](Data%20API/Update%20Summer:%20Classes) `PATCH`  


### Summer: Courses


- [List Summer: Courses](Data%20API/List%20Summer:%20Courses) `GET`  
- [Create Summer: Courses](Data%20API/Create%20Summer:%20Courses) `POST`  
- [Read Summer: Courses](Data%20API/Read%20Summer:%20Courses) `GET`  
- [Update Summer: Courses](Data%20API/Update%20Summer:%20Courses) `PATCH`  


### Summer: Enrollments


- [List Summer: Enrollments](Data%20API/List%20Summer:%20Enrollments) `GET`  
- [Create Summer: Enrollments](Data%20API/Create%20Summer:%20Enrollments) `POST`  
- [Read Summer: Enrollments](Data%20API/Read%20Summer:%20Enrollments) `GET`  
- [Update Summer: Enrollments](Data%20API/Update%20Summer:%20Enrollments) `PATCH`  


### Transcripts: Academic Classifications


- [List Transcripts: Academic Classifications](Data%20API/List%20Transcripts:%20Academic%20Classifications) `GET`  
- [Read Transcripts: Academic Classifications](Data%20API/Read%20Transcripts:%20Academic%20Classifications) `GET`  


### Transcripts: GPAs


- [List Transcripts: GPAs](Data%20API/List%20Transcripts:%20GPAs) `GET`  
- [Read Transcripts: GPAs](Data%20API/Read%20Transcripts:%20GPAs) `GET`  


### Transcripts: Student Information


- [Read Transcripts: Student Information](Data%20API/Read%20Transcripts:%20Student%20Information) `GET`  
- [List Transcripts: Student Information](Data%20API/List%20Transcripts:%20Student%20Information) `GET`  


### Transcripts: Transcript Items


- [List Transcripts: Transcript Items](Data%20API/List%20Transcripts:%20Transcript%20Items) `GET`  


### Transportation: Bus Routes


- [List Transportation: Bus Routes](Data%20API/List%20Transportation:%20Bus%20Routes) `GET`  
- [Read Transportation: Bus Routes](Data%20API/Read%20Transportation:%20Bus%20Routes) `GET`  


### Transportation: Bus Stops


- [List Transportation: Bus Stops](Data%20API/List%20Transportation:%20Bus%20Stops) `GET`  
- [Read Transportation: Bus Stops](Data%20API/Read%20Transportation:%20Bus%20Stops) `GET`  


### Transportation: Bus Trips


- [List Transportation: Bus Trips](Data%20API/List%20Transportation:%20Bus%20Trips) `GET`  
- [Read Transportation: Bus Trips](Data%20API/Read%20Transportation:%20Bus%20Trips) `GET`  


### Transportation: Schedules


- [List Transportation: Schedules](Data%20API/List%20Transportation:%20Schedules) `GET`  
- [Read Transportation: Schedules](Data%20API/Read%20Transportation:%20Schedules) `GET`  


### Transportation: Trips


- [Read Transportation: Trips](Data%20API/Read%20Transportation:%20Trips) `GET`  
- [List Transportation: Trips](Data%20API/List%20Transportation:%20Trips) `GET`  


### Volunteer Coordinator: Volunteers


- [List Volunteer Coordinator: Volunteers](Data%20API/List%20Volunteer%20Coordinator:%20Volunteers) `GET`  
- [Read Volunteer Coordinator: Volunteers](Data%20API/Read%20Volunteer%20Coordinator:%20Volunteers) `GET`  


### Withdrawal Reasons


- [List Withdrawal Reasons](Data%20API/List%20Withdrawal%20Reasons) `GET`  


### Schemas


- [post](Data%20API/post)  
- [error](Data%20API/error)  


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
