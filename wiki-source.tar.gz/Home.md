> [Home](Home) · [Concepts](Concepts/General%20Principles) · [Guides](Guides/Making%20a%20Data%20API%20Request) · [Diagrams](Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](Changelog/Data%20API) · [Data API](Data%20API) · [Authorization API](Authorization%20API) · [Files API](Files%20API)
>
> Home · [source site](https://api-docs.veracross.com/)

---


# Veracross API Documentation (mirror)


A static mirror of the [Veracross API docs](https://api-docs.veracross.com/) left menu — every menu node is a page here, nested the same way the sidebar is. The OpenAPI reference (the 5 YAML specs and all 456 operations) lives in the [GitHub repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).


## Concepts


- [General Principles](Concepts/General%20Principles.md)  
- [Breaking Changes Policy](Concepts/Breaking%20Changes%20Policy.md)  
- [Using the Data API](Concepts/Using%20the%20Data%20API.md)  
- [Access Tokens](Concepts/Access%20Tokens.md)  
- [Errors](Concepts/Errors.md)  
- [Pagination](Concepts/Pagination.md)  
- [Rate Limiting](Concepts/Rate%20Limiting.md)  
- [Value Lists](Concepts/Value%20Lists.md)  


## Guides


- [Creating an SSO Integration](Guides/Creating%20an%20SSO%20Integration.md)  
- [Making a Data API Request](Guides/Making%20a%20Data%20API%20Request.md)  
- [Making a Files API Request](Guides/Making%20a%20Files%20API%20Request.md)  
- [Student Logistics Requests](Guides/Student%20Logistics%20Requests.md)  
- [Integrating with Admission Endpoints](Guides/Integrating%20with%20Admission%20Endpoints.md)  


## Diagrams


- [OAuth SSO Login Flow](Diagrams/OAuth%20SSO%20Login%20Flow.md)  
- [Data API Request](Diagrams/Data%20API%20Request.md)  


## Changelog


- [Authorization API](Changelog/Authorization%20API.md)  
- [Data API](Changelog/Data%20API.md)  
- [Files API](Changelog/Files%20API.md)  


## API services


- [Data API](Data%20API)

- [Authorization API](Authorization%20API)

- [Files API](Files%20API)


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
