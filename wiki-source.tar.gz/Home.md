> [Home](Home) · [Concepts](General-Principles) · [Guides](Making-a-Data-API-Request) · [Diagrams](OAuth-SSO-Login-Flow) · [Changelog](Data-API-Changelog) · [Data API](Data-API) · [Authorization API](Authorization-API) · [Files API](Files-API)
>
> Home · [source site](https://api-docs.veracross.com/)

---


# Veracross API Documentation (mirror)


A static mirror of the [Veracross API docs](https://api-docs.veracross.com/) left menu — every menu node is a page here, nested the same way the sidebar is. The OpenAPI reference (the 5 YAML specs and all 456 operations) lives in the [GitHub repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).


## Concepts


- [General Principles](General-Principles)  
- [Breaking Changes Policy](Breaking-Changes-Policy)  
- [Using the Data API](Using-the-Data-API)  
- [Access Tokens](Access-Tokens)  
- [Errors](Errors)  
- [Pagination](Pagination)  
- [Rate Limiting](Rate-Limiting)  
- [Value Lists](Value-Lists)  


## Guides


- [Creating an SSO Integration](Creating-an-SSO-Integration)  
- [Making a Data API Request](Making-a-Data-API-Request)  
- [Making a Files API Request](Making-a-Files-API-Request)  
- [Student Logistics Requests](Student-Logistics-Requests)  
- [Integrating with Admission Endpoints](Integrating-with-Admission-Endpoints)  


## Diagrams


- [OAuth SSO Login Flow](OAuth-SSO-Login-Flow)  
- [Data API Request](Data-API-Request)  


## Changelog


- [Authorization API](Authorization-API-Changelog)  
- [Data API](Data-API-Changelog)  
- [Files API](Files-API-Changelog)  


## API services


- [Data API](Data-API)

- [Authorization API](Authorization-API)

- [Files API](Files-API)


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
