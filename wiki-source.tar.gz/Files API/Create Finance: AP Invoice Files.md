> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Files API / Finance: AP Invoice Files / Create Finance: AP Invoice Files · [source site](https://api-docs.veracross.com/)

---


# Create Finance: AP Invoice Files


## POST `/ap_invoices/{invoice_id}/files`


Create Finance: AP Invoice Files


**Path parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | integer | yes | Record ID |


**Header parameters:**

| Name | Type | Required | Description |
|---|---|---|---|
| `X-API-Revision` | string |  | API Revision |


### Request body


**Content type:** `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `invoice_id` | integer |  | Record ID |
| `invoice_number` | string <small>max 30</small> | yes | Invoice Number |
| `name` | string <small>max 1000</small> |  | Name |
| `id` | integer <small>read-only</small> |  | File ID |
| `description` | string <small>max 1000</small> |  | Description (Text) |
| `notes` | string |  | Notes |
| `download_url` | string <small>read-only</small> |  | File Download |

</details>

### Responses


**201** — Created


- `X-API-Revision`: API Revision

Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `data` | object | yes |  |
| `upload_url` | string | yes | - Make request using PUT method - Provide raw file in request body (not multipart/form-data) - URL accepts one upload only; reusing it is rejected - Expires after 5 minutes - Allowed file types: `text/csv`, `application/msword`, `application/vnd.openxmlformats-officedocument.wordprocessingml.document`, `image/gif`, `image/jpeg`, `application/pdf`, `image/png`, `application/vnd.ms-powerpoint`, `application/vnd.openxmlformats-officedocument.presentationml.presentation`, `text/plain`, `application/vnd.ms-excel`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`, `application/zip` - Max file size: 100 MB  |

<details><summary><code>data</code> — nested object fields</summary>

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | integer | yes | File ID |

</details>

**4XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

**5XX** — > Note: Be sure to check the HTTP response code for these errors as well



Content type: `application/json`


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/). Raw OpenAPI spec: [repo](https://github.com/bernie-nyc/veracross-api-docs-mirror).*
