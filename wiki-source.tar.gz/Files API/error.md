> [Home](../Home) · [Concepts](../Concepts/General%20Principles) · [Guides](../Guides/Making%20a%20Data%20API%20Request) · [Diagrams](../Diagrams/OAuth%20SSO%20Login%20Flow) · [Changelog](../Changelog/Data%20API) · [Data API](../Data%20API) · [Authorization API](../Authorization%20API) · [Files API](../Files%20API)
>
> Files API / Schemas / error · [source site](https://api-docs.veracross.com/)

---


# error


Schema definition:


| Field | Type | Required | Description |
|---|---|---|---|
| `error` | string | yes | The description of the error |
| `error_id` | string | yes | A unique ID for this specific error. Please provide this error id when you ask for help with an error. |

<details><summary>Raw JSON Schema</summary>

```json
{
  "type": "object",
  "description": "HTTP response codes describe the error type. See here for a list of HTTP response codes and their meanings: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status",
  "properties": {
    "error": {
      "type": "string",
      "description": "The description of the error"
    },
    "error_id": {
      "type": "string",
      "description": "A unique ID for this specific error. Please provide this error id when you ask for help with an error."
    }
  },
  "required": [
    "error",
    "error_id"
  ],
  "$schema": "http://json-schema.org/draft-07/schema#"
}
```

</details>


---

*Auto-mirrored from [https://api-docs.veracross.com/](https://api-docs.veracross.com/).*
